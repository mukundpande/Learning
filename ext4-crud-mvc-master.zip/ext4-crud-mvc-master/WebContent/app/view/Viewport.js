Ext.define('BrazilJS.view.Viewport', {
    extend: 'Ext.container.Viewport'
});