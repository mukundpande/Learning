Ext.define('BrazilJS.model.Contact', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'phone', 'email']
});