Ext.define('Sample.notdeadlock.C', {
    uses: 'Sample.notdeadlock.A'
});
