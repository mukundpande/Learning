Ext.define('Sample.deadlock.B', {
    extend: 'Sample.deadlock.C'
});