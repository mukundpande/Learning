Ext.define('Sample.deadlock.A', {
    extend: 'Sample.deadlock.B'
});