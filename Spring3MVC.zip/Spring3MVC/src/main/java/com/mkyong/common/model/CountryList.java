package com.mkyong.common.model;

import java.util.List;

public class CountryList {
	
	private List<Country> allcountryList;

	public List<Country> getCountryList() {
		return allcountryList;
	}

	public void setCountryList(List<Country> countryList) {
		this.allcountryList = countryList;
	}

}
