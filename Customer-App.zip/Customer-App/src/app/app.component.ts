import { Component } from '@angular/core';
import { Customer } from './customer';
import { CustomerService } from './customer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'Customer-App';



  newCustomer(): void {
      this.customer = new Customer();
  }

  customer: Customer = new Customer();

   constructor(private customerService: CustomerService) { }

   save() {
    this.customerService.createCustomer(this.customer)
      .subscribe(data => console.log(data), error => console.log(error));
    //this.customer = new Customer();
  }

  onSubmit() {
    //this.submitted = true;
    alert();
    this.save();
  }
}
