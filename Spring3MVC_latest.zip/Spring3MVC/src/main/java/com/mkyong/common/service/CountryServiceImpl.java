package com.mkyong.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mkyong.common.mapper.CountryMapper;
import com.mkyong.common.model.Country;
import com.mkyong.common.model.CountryList;

@Service
public class CountryServiceImpl implements CountryService {
	@Autowired
	private CountryMapper countryMapper;

	public List<Country> getAllCountries() {
		return this.countryMapper.getAllCountries();
	}

	@Override
	public List<Country> getAllCountriesFromProcedure() {
		
		 CountryList countryList = new CountryList();
		 this.countryMapper.getAllCountriesFromProcedure(countryList);
		 List<Country> newList = countryList.getCountryList();
		 return newList;
	}

}
