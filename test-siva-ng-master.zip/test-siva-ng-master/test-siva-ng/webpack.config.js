// module.exports = {
//     plugins: [
//         new webpack.IgnorePlugin(/regenerator|nodent|js-beautify/, /ajv/)
//     ]
// }