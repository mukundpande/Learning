import {Component} from "@angular/core";
@Component({
    template: `
        <div class="container">
            <h1>Help</h1>
        </div>
    `
})
export class HelpComponent {

}
