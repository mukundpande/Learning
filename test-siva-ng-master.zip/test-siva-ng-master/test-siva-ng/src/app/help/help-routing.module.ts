import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {HelpComponent} from "./help.component";
const helpRoutes: Routes = [
    {
        // canActivate: [ AdminGuard ],
        path: 'help',
        // component: UserListComponent,
        children: [
            { path: '',   component: HelpComponent }
        ]
    },
    // { path: 'user/:id', component: UserDetailComponent }
];
@NgModule({
    imports: [ RouterModule.forChild(helpRoutes) ],
    exports: [ RouterModule ]
})
export class HelpRoutingModule { }
