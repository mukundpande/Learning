import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {PageNotFoundComponent} from './utils/not-found.component';
import {FrontPageComponent} from './front-page.component';
import {LoginDialogComponent} from "./login-dialog/login-dialog.component";
import {AppComponent} from "./app.component";
import {PatientComponent} from "./patient/patient.component";
import {ProtocolComponent} from "./protocol/protocol.component";

import {DebugComponent} from "./utils/debug-component";
import {UserComponent} from "./admin/user.component";
import {ManageUsersComponent} from "./manage-users/manage-users.component";

// import {AuthGuard} from "./auth-guard.service";
const routes: Routes = [

    { path: 'admin/manageusers', component: ManageUsersComponent },
    //{ path: '', component: LoginDialogComponent },
    { path: '', component: FrontPageComponent, pathMatch: 'full' },
    //{ path: '', component: FrontPageComponent, pathMatch: 'full' },
    //{ path: 'app', component: AppComponent},
    { path: 'debug', component: DebugComponent },
    { path: 'protocol', component: ProtocolComponent },
    { path: 'patient/:patientId', component: PatientComponent },
    { path: 'admin/users/:id', component: UserComponent },
    // { path: 'protocol/:id', component: ProtocolComponent },
    // { path: 'utilities', component: ProtocolComponent },
    // { path: 'dashboard.html', redirectTo: '/dashboard', pathMatch: 'full' },
    // { path: 'dashboard',  component: DashboardComponent, canActivate: [AuthGuard] },/**/
    { path: '**', component: PageNotFoundComponent }
];
@NgModule({
    imports: [ RouterModule.forRoot(routes) ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {}
