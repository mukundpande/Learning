import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(patients: any, search: any): any {
    if(search===undefined) return patients;
     return patients.filter(function(patient){
       return patient.LastName.toLowerCase().includes(search.toLowerCase());
     });
  }

}
