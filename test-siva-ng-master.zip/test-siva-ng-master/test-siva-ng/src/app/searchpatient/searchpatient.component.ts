import { Component, OnInit, EventEmitter , Output} from '@angular/core';
import {PatientService} from "../patient/patient.service";
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import {Router} from "@angular/router";
import {MdDialog,MdDialogRef,MdDialogConfig} from '@angular/material';
import { Patient } from '../patient/patient.model';
import { FilterPipe } from './filter.pipe';

@Component({
  selector: 'app-searchpatient',
  templateUrl: './searchpatient.component.html',
  styleUrls: ['./searchpatient.component.css']
})
export class SearchpatientComponent implements OnInit {
  results: Object;

  firstPatientToBePopulated:String='';

@Output() selectedSearchedPatient: EventEmitter<any> = new EventEmitter<any>();

patients: any;

  constructor(private patientService: PatientService,
    private router: Router,
    private dialogRef: MdDialogRef<SearchpatientComponent>) {

       }

  ngOnInit() {
     this.loadPatientsForModalpopup();
  }

  loadPatientsForModalpopup(){
    this.patientService.getPatientsForDropDown().subscribe(patients => {

    this.patients = patients;
   });
  }
  selectSearchedRecord(patientId) {
     console.log(patientId);

     this.firstPatientToBePopulated=patientId;
  
     //this.router.navigate(['/patient/'+patientId]);
     this.selectedSearchedPatient.emit(patientId);

     this.dialogRef.close(patientId);
  }

   close(event: Event) {
    event.preventDefault();
    let dialogRef:MdDialogRef<SearchpatientComponent>;
    dialogRef.close();
  }
}
