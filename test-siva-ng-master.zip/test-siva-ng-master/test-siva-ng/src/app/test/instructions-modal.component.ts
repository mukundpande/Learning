import {Component} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Instructions &hellip;</h4>
            <button type="button" class="close" aria-label="Close" (click)="close()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <ol>
                <li *ngFor="let inst of instructions">{{inst}}</li>
            </ol>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="close()">Done</button>
        </div>
    `
})
export class InstructionsModalComponent {

    instructions = [];

    constructor (
        private activeModal: NgbActiveModal,
        private pouchService: PouchDBService
    ) {

    }

    loadTestInfo(test) {
        let type = test.code;
        let name = test.name;

        this.instructions=[];
        this.pouchService.get('ARC_Inst_'+type).then(doc => {
            for(let j = 0; j < doc.items.length; j++) {
                if (doc.items[j].TestName === name) {
                    let i = 1;
                    while(doc.items[j]['Text'+i] && doc.items[j]['Text'+i].length) {
                        this.instructions.push(doc.items[j]['Text'+i]);
                        i++;
                    }
                    return;
                }
            }
            this.instructions.push('No instructions were found for this test.');
        });

    }

    close () {
        this.activeModal.close(true);
    }

}
