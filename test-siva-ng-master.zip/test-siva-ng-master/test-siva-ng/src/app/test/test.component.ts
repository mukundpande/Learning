import {
    Component, ElementRef, Input, OnInit, ViewChild, Renderer2, HostListener, ApplicationRef,
    OnDestroy
} from "@angular/core";
import {FooterContextService} from "../services/footer-context.service";
import {WpiService} from "../services/wpi.service";
import {ActivatedRoute, Router, Params} from "@angular/router";
import {PouchDBService} from "../services/pouchdb.service";
import {DatePipe} from "@angular/common";
import {Observable} from "rxjs/Observable";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {InstructionsModalComponent} from "./instructions-modal.component";
import {CommentsModalComponent} from "./comments-modal.component";
import {Subscription} from "rxjs/Subscription";
@Component({
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit, OnDestroy {
    testActive = false;
    testComplete = false;
    @ViewChild('testElement') testElement: any;
    testData: any = {};
    viewData: any = {};

    series: any = {};
    sections: any={};
    subscription: Subscription;
    changesMade = false;

    constructor (
        private appRef: ApplicationRef,
        private datePipe: DatePipe,
        private footerContext: FooterContextService,
        private modalService: NgbModal,
        private pouchService: PouchDBService,
        private rd: Renderer2,
        private route: ActivatedRoute,
        private router: Router,
        private wpiService: WpiService,
    ) { }

    ngOnDestroy () {
        if (this.series.testsCompleted && this.changesMade) {
            if(!confirm('Save and quit?')) {
                return;
            }
            this.saveAndQuitSeries();
            return;
        }

        if(this.subscription){
            this.subscription.unsubscribe();
        }
        this.footerContext.clearCustomProtocol();
        this.footerContext.updateProtocols();
    }

    ngOnInit () {


     this.sections={
       DESCRIP:'TEST',
       impairment:'TEST'
     };

        let datetime = new Date();
        this.series = {
            protocol: this.footerContext.protocol,
            datetime: datetime,
            testsCompleted: 0,
            patientId: this.footerContext.patient._id,
            tests: {},
            _id: 'PATSERIES_' + this.footerContext.patient._id
                + '_' + this.datePipe.transform(datetime, 'yyyyMMddHHmmss')
                + '_' + (this.footerContext.protocol ? this.footerContext.protocol.Name : 'NOPROTOCOL')
        };
        this.wpiService.promiseDocuments().then(() => {
            this.wpiService.restartWpi(this.footerContext.patient).then(() => {

                this.loadTestView();

                this.route.params.switchMap((params: Params) => {
                    console.log('LOADING THE PARAMS', params);

                    if (!params['id']) {
                        return new Observable(obs => { obs.next(null) });
                    }

                    return new Observable(obs => {
                        this.pouchService.get(params['id']).then( res => {
                            obs.next(res);
                        });
                    });
                })
                    .subscribe(res => {
                        if(!res) {
                            return;
                        }
                        this.series = res;
                        this.changesMade = false;
                        this.footerContext.loadReviewProtocol(this.series.protocol);
                        console.log('MODIFYING A SERIES, THIS IS NOT A NEW TEST -- ', res);
                        for(let x in this.series.tests) {
                            if (true) {
                                this.wpiService.evaluateResults(this.series.protocol.tests[x], this.series.tests[x].test);
                            }
                        }

                        this.loadTestView();
                    });

                let _id = 'PATSERIES_' + this.footerContext.patient._id
                    + '_' + this.datePipe.transform(this.series.datetime, 'yyyyMMddHHmmss')
                    + '_' + this.series.protocol.Name;
                console.log('ID set', _id, this.footerContext.patient._id);

                console.log('trying to subscribe to testObservable');
                this.subscription = this.footerContext.testObservable.subscribe( test => { this.loadTestView(); });

            });
        });
        this.showInitialTestButtons();
    }

    getFooterContext () {
        return this.footerContext;
    }

    getWpiService () {
        return this.wpiService;
    }

    @HostListener('window:beforeunload')
    confirmExit () {
        if (this.series.testsCompleted) {
            return 'Are you sure? You will lose all test information and need to start again!';
        }
    }

    saveAndQuitSeries () {

        this.pouchService.put(this.series._id, this.series).then( res => {
            console.log('SERIES IS SAVED -- ', res);

            let patient_doc = this.series.patientId;
            this.pouchService.get(patient_doc).then(doc => {
                doc.LastTestDate = new Date();
                this.pouchService.put(patient_doc, doc).then(res => {
                   console.log('Updated Patient for Last Test Date', res);
                });
            });

        });


        this.router.navigate(['/']);
    }

    gotoNextTest () {
        this.footerContext.nextTest();

        if(!this.footerContext.test) {
            this.saveAndQuitSeries();
            return;
        }

        this.loadTestView();
    }

    launchCommentsModal () {
        const win = this.modalService.open(CommentsModalComponent , {backdrop: 'static', size: 'lg'}); //
        win.result.then(res => {
            if (res) {
                this.series.tests[this.footerContext.testIndex].comments = res.data;
                if(res.goForward) {
                    this.gotoNextTest();
                }
            }
        })
        return win;
    }

    showInitialTestButtons() {
        this.footerContext.activateButtons([
            {
                label: 'Start',
                click: () => {
                    this.startTest();
                }
            },
            {
                label: 'Instructions',
                click: () => {
                    const window = this.modalService.open(InstructionsModalComponent , {backdrop: 'static'}); // , {backdrop: 'static'}
                    window.componentInstance.loadTestInfo(this.footerContext.test)
                }
            },
            {
                label: 'Continue',
                click: () => {
                    if (!confirm('Really skip this test?')) {
                        return false;
                    }

                    // skip the test
                    this.gotoNextTest();
                }
            },
            {
                label: 'Quit',
                click: () => {
                    this.router.navigate(['/']);
                }
            }
        ]);
    }

    showPostTestButtons () {
        this.footerContext.activateButtons([{
            label: 'Retest',
            click: () => {
                if (this.testElement.correctTest) {
                    this.testElement.correctTest();

                    this.footerContext.activateButtons([{},{},{
                        label: 'Done',
                        click: () => {
                            this.testElement.doneCorrecting();
                            this.showPostTestButtons();
                        }
                    },{}]);

                    return;
                }



                if (!confirm('Really discard the current test? Results will be permanently lost!')) {
                    return false;
                }

                this.testElement.resetTest();
                this.showInitialTestButtons();
            }
        }, {
            label: 'Comments',
            click: () => {
                this.launchCommentsModal()
            }
        }, {
            label: 'Continue',
            click: () => {
                this.gotoNextTest();
            }
        }, {
            label: 'Quit',
            click: () => {
                if (!confirm('Really discard results?')) {
                    return;
                }
                // this.showInitialTestButtons();
                this.series.testsCompleted--;
                this.series.tests[this.footerContext.testIndex] = null;
                this.loadTestView();

                if(!confirm('Quitting this protocol. Continue?')) {
                    return;
                }

                this.router.navigate(['/']);
            }
        }]);
    }

    loadTestView () {
        if (this.testElement && this.testElement.resetTest) {
            this.testElement.resetTest();
        }
        this.viewData = {};
        this.testData = {};
        if(this.testElement) {
            this.testElement.testComplete = false;
            this.testElement.testActive = false;
        }
        this.showInitialTestButtons();
        this.appRef.tick();

        if (!this.footerContext.test) {
            return;
        }

        if (this.series.tests[this.footerContext.testIndex]) {
            let test = this.series.tests[this.footerContext.testIndex];
            console.log('test.component::loadTestView() -- ', this.footerContext.test, ' Loading Data: ', test);
            this.viewData = test.view;
            this.testData = test.test;

            this.appRef.tick();

            if (this.testElement && this.testElement.loadTestData) {
                this.testElement.loadTestData(this.testData);
            } else if(!this.testElement) {
                console.log('## WARNING -- Could not find Test Element');
            }
            let buttons = [{
                label: 'Retest',
                click: () => {
                    if (!confirm('Really discard the current test? Results will be permanently lost!')) {
                        return false;
                    }

                    this.testElement.resetTest();
                    this.showInitialTestButtons();
                }
            }, {
                label: 'Comments',
                click: () => {
                    let win = this.launchCommentsModal()
                    win.componentInstance.loadComments(this.series.tests[this.footerContext.testIndex].comments)
                }
            }, {
                label: 'Continue',
                click: () => { this.gotoNextTest() }
            }, { label: 'Quit', click: () => { this.router.navigate(['/']); }}];

            if (this.testElement && this.testElement.showStats) {
                buttons.splice(1,0,{
                    label: 'Statistics',
                    click: () => {
                        this.testElement.showStats()
                    }
                });
            }

            this.footerContext.activateButtons(buttons);
            // this.footerContext.activateRetestMode();

            return;
        }

        let promiseTest;

        switch (this.footerContext.test.code) {
            case 'CX':
            case 'HD':
            case 'PG':
            case 'ST':
                promiseTest = this.wpiService.getStaticTest(this.footerContext.test);
                break;
            case 'EG':
            case 'RM':
                promiseTest = this.wpiService.getRomTest(this.footerContext.test);
                break;
            case 'NA':
                this.viewDataUpdated(this.viewData = { test: { code: 'NA' } });
                return;
            default:
                return;
        }

        if (promiseTest) {
            console.log('test.component::loadTestView() -- promiseTest valid');
            promiseTest.then(res => this.viewDataUpdated(this.viewData = res));
        } else {
            console.error('no test being pulled for ', this.footerContext.test);
        }
    }

    viewDataUpdated(data) {
        console.log('test.component::viewDataUpdated() -- updating view data', data);
        if(this.testElement && this.testElement.processViewData) {
            console.log('test.component::viewDataUpdated() -- passing view data to call', data);
            this.testElement.processViewData(data);
        } else {
            console.log('test.component::viewDataUpdated() -- could not process view data, no element or no function');
        }
        return data;
    }

    testCompleted (testData) {
        this.testComplete = true;
        this.changesMade = true;

        this.series.testsCompleted++;

        console.log('saving test data to', this.footerContext.testIndex, testData, this.viewData);

        this.series.tests[this.footerContext.testIndex] = {
            test: testData,
            view: this.viewData
        };

        this.showPostTestButtons();

        console.log('TEST DATA RETURNED IS', testData, this.footerContext.test);

        // generate the WPI if it applies

        this.wpiService.evaluateResults(this.footerContext.test, testData);


    }
    startTest () {
        this.testActive = true;
        this.testComplete = false;

        console.log('RD', this.rd);

        console.log('EL', this.testElement);

        if(this.testElement.startTest) {
            console.log('Starting the sub-element test');
            this.testElement.startTest().then( r => this.testCompleted(r) );
        }

        this.footerContext.activateButtons([{}, {}, {
            label: 'Stop Test',
            click: () => {
                if (!confirm('Really discard results?')) {
                    return false;
                }

                this.loadTestView();

                // this.showInitialTestButtons();
            }
        }, {}]);
    }
}
