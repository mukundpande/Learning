import {Component, Input, ViewChild, OnInit} from "@angular/core";
@Component({
    selector: 'test-na',
    templateUrl: './test-na.component.html',
    styleUrls: ['./test-na.component.css']
})
export class TestNaComponent implements OnInit {
    @ViewChild('canvas') canvas;
    testActive = false;
    testComplete = false;
    @Input() testData: any = {};
    @Input() viewData: any = {};
    resolve;
    reject;

    selectedType = '~';

    points = [];

    ngOnInit () {
        console.log('test-na.component::OnInit() -- processing', this.canvas);
        this.redrawCanvas();
    }

    canvasClick ($event) {
        if(!this.testActive || this.testComplete) {
            return;
        }
        // console.log('EVENT LOG', $event);
        this.points.push({x: $event.layerX, y: $event.layerY, type: this.getSelectedType()})
        this.redrawCanvas();
    }

    getSelectedType () {
        return this.selectedType;
    }

    redrawCanvas () {

        let context: CanvasRenderingContext2D  = this.canvas.nativeElement.getContext('2d');
        let imageObj = new Image();
        imageObj.onload = () => {
            context.drawImage(imageObj, 0, 0);
            context.font = '12px Arial';
            context.fillStyle = 'red';

            for (let i = 0; i < this.points.length; i++) {
                let pt = this.points[i];
                context.font = '12px Arial';
                context.fillStyle = 'red';
                context.fillText(pt.type, pt.x, pt.y);
            }
        };
        imageObj.src = '/assets/images/pain.png';
    }

    testCompleted () {
        this.testData.points = this.points;
        this.testComplete = true;
        this.resolve(this.testData);
    }

    resetTest () {
        this.testActive = false;
        this.testComplete = false;
    }

    loadTestData (data) {
        this.testData = data;
        this.points = data.points;
    }

    undoLast () {
        if(!this.testActive || this.testComplete) {
            return;
        }
        this.points.pop();
        this.redrawCanvas();
    }

    clearAll () {
        if(!this.testActive || this.testComplete) {
            return;
        }
        this.points = [];
        this.redrawCanvas();
    }

    processViewData (data) {
        this.viewData = data;
        this.points = data.points;
    }

    startTest () {
        this.testActive = true;
        let promise = new Promise( (res, rej) => { this.resolve = res; this.reject = rej; });
        return promise;
    }
}