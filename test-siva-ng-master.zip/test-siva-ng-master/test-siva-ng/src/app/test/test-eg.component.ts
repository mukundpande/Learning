import {Component, Input, OnInit, ViewChild, ApplicationRef} from "@angular/core";
import {CalculationsService} from "../services/calculations.service";
@Component({
    selector: 'test-eg',
    templateUrl: './test-eg.component.html',
    styleUrls: ['./test-eg.component.css']
})
export class TestEgComponent implements OnInit {
    chartAL: any = {
        data: [{
            label: 'Trials',
            data: []
        }],
        type: 'bar',
        colors: [{
            backgroundColor: 'rgba(255,255,255,1)',
            borderColor: 'rbga(0,0,0,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3'],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }
    chartAR: any = {
        data: [{
            label: 'Trials',
            data: []
        }],
        type: 'bar',
        colors: [{
            backgroundColor: 'rgba(255,255,255,1)',
            borderColor: 'rbga(0,0,0,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3'],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }
    chartBL: any = {
        data: [{
            label: 'Trials',
            data: []
        }],
        type: 'bar',
        colors: [{
            backgroundColor: 'rgba(255,255,255,1)',
            borderColor: 'rbga(0,0,0,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3'],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }
    chartBR: any = {
        data: [{
            label: 'Trials',
            data: []
        }],
        type: 'bar',
        colors: [{
            backgroundColor: 'rgba(255,255,255,1)',
            borderColor: 'rbga(0,0,0,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3'],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }


    testActive = false;
    testComplete = false;
    @Input() testData: any = {};
    @Input() viewData: any = {};
    trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
    resolve;
    reject;

    @ViewChild('firstInput') firstInput: any;
    @ViewChild('secondInput') secondInput: any;

    constructor (private appRef: ApplicationRef, private calc: CalculationsService) {}

    ngOnInit () {
        console.log('RM LOADING WITH ', this.testData, this.viewData);
        this.resetChartSettings();

        for (let i = 0; i < 2; i++) {
            for (let j = 0; j < 2; j++) {
                this.updateChartValues(i, j);
            }
        }
    }

    resetChartSettings () {
        console.log('test-cs.component::resetChartSettings() -- ', this.viewData);


        for (let i = 0; i < 2 ; i++) {

            let ticks = {
                beginAtZero: true
            };

            ticks[i?'min':'max'] = this.viewData.test ? +this.viewData.test.ScaleMax * (i?-1:1) : null;

            console.log('test-eg.component::resetChartSettings() -- ticks for', i, ticks);

            for (let j = 0; j < 2; j++) {
                this['chart' + ['A','B'][i] + ['L','R'][j]].options = {
                    scales: {
                        yAxes: [{
                            ticks: ticks
                        }]
                    }
                }
            }
        }
    }

    zSideOverride (z) {
        // z is the opposite side of the active results, so 1 would be 0.
        if (z) {
            return 0;
        }
        if (this.viewData.labels.length === 1) {
            return 0;
        }
        return 1;
    }

    updateChartValues (y = 0, z = 0) {
        // this.lineChartData = [];
        let newData = [];
        let side = ['A','B'][y] + ['L','R'][z];

        console.log("test-rm::updateChartValues() -- starting loop", this.testData);
        let data = [];
        for (let i = 0; i < 3; i++) {
            if (this.testData['trials'+side] && this.testData['trials'+side][i]) {
                console.log('test-rm::updateChartValues() -- checking', side, i, this.testData['trials'+side][i]);
                let dat = this.testData['trials'+side][i].value;
                data.push(dat*(y?-1:1));
            } else if(!this.testData['trials'+side]) {
                console.log('test-rm::updateChartValues() -- Missing testData index', 'trials'+side);
            } else {
                console.log('test-rm::updateChartValues() -- could not locate index for', side, i);
            }
        }
        newData.push({
            label: 'Trials',
            data: data
        });
        this['chart'+side].data = newData;

        // console.log(this.testData);
    }

    trialInputDisabled (x, y, z) {
        if (!this.testActive || this.testComplete) {
            return true;
        }

        if (z && !this.testData.secondTask || !z && this.testData.secondTask) {
            return true;
        }

        // if (z) {
        //     if ()
        // }
        //
        // if (z && x + y*3 > this.testData.trialsB.length || !z && x + y*3 > this.testData.trialsA.length) {
        //     return true;
        // }

        return false;
    }

    processTrialInputs ($event, x, y, z) {
        console.log('CAPTURED INPUT for ','Trial' + (x+1),y?'R':'L',z?'B':'A', $event.target.valueAsNumber);
        let trialLetter = ['A','B'][z] + ['L','R'][y]; // (z ? 'B' : 'A') + (y ? 'R' : 'L');
        let trialSide = 'trials' + trialLetter;

        if (!this.testData[trialSide][x]) {
            this.testData[trialSide][x] = { value: null };
        }

        this.testData[trialSide][x].value = $event.target.valueAsNumber;
        this.updateChartValues(z, y);

        let trialCompletion = this.trialDataCompleted(this.testData[trialSide]);
        if (trialCompletion !== false) {
            if(trialCompletion === -1) {
                this.testData['failed' + trialLetter] = true;
            }
            let maxSideB = false;
            //@todo: find the source of this rule, keep it hardcoded for now
            if(this.viewData.test.TestName === "Ankle Dorsi/Plantar Flexion") {
                maxSideB = true;
            }

            // section stopped
            this.testData['rom' + trialLetter] = this['generate' + ['Maximum',maxSideB?'Maximum':'Minimum'][z]](this.testData[trialSide]).toString();

            console.log('RIGHT TEST', this.testData['rom' + ['A','B'][z] + 'R']);
            if (this.testData['rom' + ['A','B'][z] + 'R'] !== undefined && this.testData['rom' + ['A','B'][z] + 'R'] !== null) {
                if(z || this.viewData.labels.length < 2) {
                    this.testCompleted();
                } else {
                    this.testData.secondTask = true;
                    this.appRef.tick();
                    this.secondInput.nativeElement.focus();
                }
            }
        }
    }

    trialDataCompleted (myArray) {
        console.log('EVALUATING TRIAL DATA FOR', myArray);

        if (myArray.length < 3) {
            console.log('Not enough trials, continuing...');
            return false;
        }

        let highest = this.generateMaximum(myArray);
        let mean = this.calc.generateAverage(myArray);
        let stDev = this.calc.generateStandardDeviation(myArray, mean);
        let coVar = this.calc.generateCoefficientOfVariation(stDev, mean);
        console.log('[*Test-EG::trialDataCompleted] Calculated data to see if trials are completed: ', {
            avg: mean,
            std: stDev,
            cv: coVar
        });

        if (myArray.length === 3) {
            console.log('Three trials done. Stopping...');
            return (stDev < 5 && coVar < .1) ? true : -1;
        }

        // @TODO: Max Trials may change, update number to actual test maxTrials
        if (myArray.length === 3) {
            console.log('Could not reconcile trials, marking as failed');
            return -1;
        }

        console.log('Trials are not close enough, continuing...');
        return false;
    }

    testCompleted () {
        this.testComplete = true;
        this.resolve(this.testData);
    }

    generateMaximum (myArray, key = 'value') {
        let max = 0;
        for (let i = 0; i < myArray.length; i++) {
            max = Math.max(max, myArray[i][key]);
        }
        return max;
    }

    generateMinimum (myArray, key = 'value') {
        if (!myArray.length) {
           return;
        }

        let min = myArray[0][key];
        for (let i = 0; i < myArray.length; i++) {
            min = Math.min(min, myArray[i][key]);
        }
        return min;
    }

    resetTest () {
        console.log('### RESETTING TEST --- ');
        this.trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.testData = {
            trialsAL: [],
            trialsAR: [],
            trialsBL: [],
            trialsBR: [],
        };
        //this.viewData = {};
        this.testActive = false;
        this.testComplete = false;
    }

    loadTestData (testData) {
        console.log('LOAD TEST DATA -- loading test data for', testData);

        if (testData.trialsAL) {
            for (let i = 0; i < testData.trialsAL.length; i++) {
                this.trialFields[i] = testData.trialsAL[i].value;
            }
        }

        if (testData.trialsAR) {
            for (let i = 0; i < testData.trialsAR.length; i++) {
                this.trialFields[i+3] = testData.trialsAR[i].value;
            }
        }

        if (testData.trialsBL) {
            for (let i = 0; i < testData.trialsBL.length; i++) {
                this.trialFields[i+6] = testData.trialsBL[i].value;
            }
        }

        if (testData.trialsBR) {
            for (let i = 0; i < testData.trialsBR.length; i++) {
                this.trialFields[i + 9] = testData.trialsBR[i].value;
            }
        }
    }

    startTest () {
        this.testActive = true;
        this.testData.step = 0;
        this.testData.trialsAL = [];
        this.testData.trialsAR = [];
        this.testData.trialsBL = [];
        this.testData.trialsBR = [];

        this.appRef.tick();
        this.firstInput.nativeElement.focus();

        let promise = new Promise( (res, rej) => { this.resolve = res; this.reject = rej; });
        return promise;
    }
}
