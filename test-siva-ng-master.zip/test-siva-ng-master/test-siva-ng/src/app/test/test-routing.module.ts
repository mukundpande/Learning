import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {TestComponent} from "./test.component";
import {AdminGuard} from "../admin/admin-guard.service";
import {ReviewComponent} from "./review.component";
import {ReportsComponent} from "../reports/reports.component";

const routes: Routes = [
    {
        path: 'test',
        canActivate: [

        ],
        children: [
            { path: '', component: TestComponent },
            { path: ':id', component: TestComponent },
            // { path: 'documents', component: DocumentsComponent },
            // { path: 'documents/:id', component: DocumentComponent },
            // { path: 'patients', component: PatientsComponent }
        ]
    },
    {
        path: 'review',
        children: [
            { path: '', component: ReviewComponent }
        ]
    },
    {
        path: 'report',
        children: [
            { path: '', component: ReportsComponent }
        ]
    }

    // { path: '', component: FrontPageComponent, pathMatch: 'full' },
    // { path: 'connect', component: ConnectComponent },
    // { path: 'protocol', component: ProtocolComponent },
    // { path: 'patient', component: ProtocolComponent },
    // { path: 'protocol/:id', component: ProtocolComponent },
    // { path: 'utilities', component: ProtocolComponent },
    // { path: 'dashboard.html', redirectTo: '/dashboard', pathMatch: 'full' },
    // { path: 'dashboard',  component: DashboardComponent, canActivate: [AuthGuard] },/**/
    // { path: '**', component: PageNotFoundComponent }
];
@NgModule({
    imports: [ RouterModule.forChild(routes) ],
    exports: [ RouterModule ]
})
export class TestRoutingModule {}
