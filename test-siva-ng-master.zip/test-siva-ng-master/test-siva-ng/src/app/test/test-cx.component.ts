import {Component, Input, OnInit, ViewChild} from "@angular/core";
import {CalculationsService} from "../services/calculations.service";
@Component({
    selector: 'test-cx',
    templateUrl: './test-cx.component.html',
    styleUrls: ['./test-cx.component.css']
})
export class TestCxComponent implements OnInit {
    chartA: any = {
        data: [{
            label: 'Trial 1',
            data: []
        },{
            label: 'Trial 2',
            data: []
        },{
            label: 'Trial 3',
            data: []
        }],
        type: 'line',
        colors: [{
            backgroundColor: 'rgba(255,0,255,.1)',
            borderColor: 'rbga(255,0,255,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }, {
            backgroundColor: 'rgba(255,255,0,.1)',
            borderColor: 'rbga(255,255,0,1)'
        }, {
            backgroundColor: 'rgba(0,255,255,.1)',
            borderColor: 'rbga(0,255,25,1)'
        }],
        legend: true,
        labels: ['', ''],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }

    chartB: any = {
        data: [{
            label: 'Trial 1',
            data: []
        },{
            label: 'Trial 2',
            data: []
        },{
            label: 'Trial 3',
            data: []
        }],
        type: 'line',
        colors: [{
            backgroundColor: 'rgba(255,0,255,.1)',
            borderColor: 'rbga(255,0,255,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }, {
            backgroundColor: 'rgba(255,255,0,.1)',
            borderColor: 'rbga(255,255,0,1)'
        }, {
            backgroundColor: 'rgba(0,255,255,.1)',
            borderColor: 'rbga(0,255,25,1)'
        }],
        legend: true,
        labels: ['', ''],
        options: {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }

    chartP: any = {
        data: [100, 120],
        type: 'pie',
        // colors: [{
        //     backgroundColor: 'rgba(255,0,255,.1)',
        //     borderColor: 'rbga(255,0,255,1)',
        // }, {
        //     backgroundColor: 'rgba(255,255,0,.1)',
        //     borderColor: 'rbga(255,255,0,1)'
        // }, {
        //     backgroundColor: 'rgba(0,255,255,.1)',
        //     borderColor: 'rbga(0,255,25,1)'
        // }],
        legend: false,
        labels: ['Left','Right'],
        options: {
            rotation: Math.PI / 2
        }
    }
    correctMode = false;
    statsA: any = {};
    statsB: any = {};

    testActive = false;
    testComplete = false;
    @Input() testData: any = {};
    @Input() viewData: any = {};
    trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
    resolve;
    reject;

    heartActive = false;
    redoTrial;
    redoSide;


    @ViewChild('firstInput') firstInput: any;
    @ViewChild('secondInput') secondInput: any;

    constructor (private calc: CalculationsService) {}

    ngOnInit () {
        console.log('test-hd.component::OnInit() -- processing', this.viewData, this.testData);
        this.resetChartSettings();
        this.updateChartValues(0);
        this.updateChartValues(1);
    }

    trialInputDisabled (x, y) {
        if (this.correctMode) {
            return false;
        }
        if (!this.testActive || this.testComplete) {
            return true;
        }
        if (y && !this.testData.secondTask || !y && this.testData.secondTask) {
            return true;
        }
        if (y && x > this.testData.trialsB.length || !y && x > this.testData.trialsA.length) {
            return true;
        }

        return false;
    }

    toggleHeart ($event) {
        console.log($event.source.checked ? 'ON' : 'OFF', $event);
        this.heartActive = $event.source.checked;
    }

    getTabIndex (x, y, z) {
        if(this.heartActive) {
            return ((x+y*3)*3 + z)+1;
        } else {
            return x+(y*3)+1
        }
    }

    processTrialInputs ($event, x, y, z = 0) {
        console.log('CAPTURED INPUT for ','Trial' + (x+1),y?'B':'A', $event.target.valueAsNumber);
        let trialLetter = ['A','B'][y]; // (z ? 'B' : 'A') + (y ? 'R' : 'L');
        let trialSide = 'trials' + trialLetter;

        if (!this.testData[trialSide][x]) {
            this.testData[trialSide][x] = { value: null, pre: null, post: null };
        }

        this.testData[trialSide][x][['value','pre','post'][z]] = $event.target.valueAsNumber;

        this.updateChartValues(y);

        let trialCompletion = this.trialDataCompleted(this.testData[trialSide]);
        if (trialCompletion !== false) {
            // section stopped
            // this.testData['rom' + trialLetter] = this.generateMaximum(this.testData[trialSide]);

            // if (this.testData['rom' + ['A','B'][y]]) {
                if(y || this.viewData.labels.length < 2) {
                    this.testCompleted();
                } else {
                    this.testData.secondTask = true;
                    this.secondInput.nativeElement.focus();
                }
            // }
        }
    }

    correctTest () {
        this.correctMode = true;
    }

    doneCorrecting () {
        this.correctMode = false;
        this.renderSummaryResults();
    }

    showStats () {
        this.testComplete = true;
        this.renderSummaryResults();
    }

    trialDataCompleted (myArray) {
        console.log('EVALUATING TRIAL DATA FOR', myArray);

        if (myArray.length < 3) {
            console.log('Not enough trials, continuing...');
            return false;
        }

        //let highest = this.generateMaximum(myArray);
        // let stDev = this.generateStandardDeviation(myArray, mean);
        // let coVar = this.generateCoefficientOfVariation(stDev, mean);


        if (myArray.length === 3) {
            if (this.heartActive && !myArray[2].post) {
                console.log('Missing POST in last item');
                return false;
            }
            console.log('Trials are within boundaries. Stopping...');
            return true;
        }

        // @TODO: Max Trials may change, update number to actual test maxTrials
        if (myArray.length === 3) {
            console.log('Could not reconcile trials, marking as failed');
            return -1;
        }

        console.log('Trials are not close enough, continuing...');
        return false;
    }

    testCompleted () {
        this.testComplete = true;
        this.renderSummaryResults();
        this.resolve(this.testData);
    }

    renderSummaryResults () {
        this.statsA = {};
        this.statsB = {};

        console.log('RENDERING SUMMARY RESULTS FOR', this.testData);

        this.statsA.mean = this.calc.generateAverage(this.testData.trialsA);
        this.statsA.stdev = this.calc.generateStandardDeviation(this.testData.trialsA, this.statsA.mean);
        this.statsA.coef = this.calc.generateCoefficientOfVariation(this.statsA.stdev, this.statsA.mean);

        this.statsB.mean = this.calc.generateAverage(this.testData.trialsB);
        this.statsB.stdev = this.calc.generateStandardDeviation(this.testData.trialsB, this.statsB.mean);
        this.statsB.coef = this.calc.generateCoefficientOfVariation(this.statsB.stdev, this.statsB.mean);

        if (this.statsA.mean < this.statsB.mean) {
            console.log('[test-cx::renderSummaryResults] RIGHT > LEFT');
            this.statsA.deficiency = '-' + this.calc.roundTenth(100*(1 - this.statsA.mean/this.statsB.mean)) + '%';
            this.statsB.deficiency = 'N/A'
        } else if (this.statsA.mean > this.statsB.mean) {
            console.log('[test-cx::renderSummaryResults] LEFT > RIGHT');
            this.statsB.deficiency = '-' + this.calc.roundTenth(100*(1 - this.statsB.mean/this.statsA.mean)) + '%';
            this.statsA.deficiency = 'N/A'
        } else {
            console.log('[test-cx::renderSummaryResults] EQUAL MATCH');
            this.statsA.deficiency = this.statsB.deficiency = 'N/A';
        }

        this.statsA.mean = this.calc.roundTenth(this.statsA.mean);
        this.statsB.mean = this.calc.roundTenth(this.statsB.mean);
        this.statsA.coef = this.calc.roundTenth(this.statsA.coef*100) + '%';
        this.statsB.coef = this.calc.roundTenth(this.statsB.coef*100) + '%';

        this.chartP.data = [this.statsA.mean, this.statsB.mean];
        console.log('Chart P: ', this.chartP);
    }

    generateMaximum (myArray, key = 'value') {
        let max = 0;
        for (let i = 0; i < myArray.length; i++) {
            max = Math.max(max, myArray[i][key]);
        }
        return max;
    }

    loadTestData (testData) {
        console.log('LOAD TEST DATA -- loading test data for', testData);

        if (testData.trialsA) {
            for (let i = 0; i < testData.trialsA.length; i++) {
                this.trialFields[i] = testData.trialsA[i].value;
            }
        }

        if (testData.trialsB) {
            for (let i = 0; i < testData.trialsB.length; i++) {
                this.trialFields[i+3] = testData.trialsB[i].value;
            }
        }

        this.heartActive = testData.heartActive;

    }

    resetTest () {
        console.log('### RESETTING TEST --- ');
        this.trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.testData = {};
        //this.viewData = {};
        this.testActive = false;
        this.testComplete = false;
        this.heartActive = false;
        this.updateChartValues();
        this.resetChartSettings ()

    }

    resetChartSettings () {
        console.log('test-cs.component::resetChartSettings() -- ', this.viewData);
        this.chartA.options = this.chartB.options = {
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        max: this.viewData.test ? +this.viewData.test.ScaleMax : null,
                        beginAtZero: true
                    }
                }]
            }
        }
    }


    updateChartValues (y = 0) {
        // this.lineChartData = [];
        let newData = [];
        let side = ['A','B'][y];

        console.log("test-cx::updateChartValues() -- starting loop", this.testData);
        for (let i = 0; i < 3; i++) {
            let data = [];
            if(this.testData['trials' + side] && this.testData['trials' + side][i]) {
                console.log('test-cx::updateChartValues() -- checking', i, this.testData['trials' + side][i]);
                let dat = this.testData['trials' + side][i].value;
                data = [dat, dat];
            } else if (!this.testData['trials' + side] ) {
                console.log('test-cx::updateChartValues() -- missing key for ', side);
            } else {
                console.log('test-cx::updateChartValues() -- missing value for', side, i);
            }
            newData.push({
                label: 'Trial ' + (i+1),
                data: data
            });
        }

        this['chart'+side].data = newData;

        // console.log(this.testData);
    }

    startTest () {
        this.testActive = true;
        this.testData.step = 0;
        this.testData.trialsA = [];
        this.testData.trialsB = [];
        this.testData.heartActive = this.heartActive;

        this.firstInput.nativeElement.focus();

        let promise = new Promise( (res, rej) => { this.resolve = res; this.reject = rej; });
        return promise;
    }
}
