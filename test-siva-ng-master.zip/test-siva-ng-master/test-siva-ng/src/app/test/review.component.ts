import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {FooterContextService} from "../services/footer-context.service";
import {Router} from "@angular/router";
@Component({
    template: `
        <div class="container white">
            <h3>Select Test to Review <small>(* indicates incomplete test)</small></h3>

            <ngx-datatable
                    [rows]="series"
                    class="material"
                    [limit]="20"
                    [columnMode]="'force'"
                    [headerHeight]="50"
                    [footerHeight]="50"
                    [rowHeight]="'auto'"
                    [selected]="selected"
                    [selectionType]="'multiClick'"
                    (activate)="onActivate($event)"
                    (select)='onSelect($event)'
                    [reorderable]="false">
                <ngx-datatable-column name="Patient ID #" prop="patientId"></ngx-datatable-column>
                <ngx-datatable-column name="Test Date - Time" prop="datetime">
                    <ng-template ngx-datatable-cell-template let-value="value" let-row="row">
                        {{ value | date : 'MM/dd/yy - HH:mm' }}
                    </ng-template>
                </ngx-datatable-column>
                <ngx-datatable-column name="*">
                    <ng-template ngx-datatable-cell-template let-value="value" let-row="row">
                        <span *ngIf="row.testsAvailable > row.testsCompleted">*</span>
                    </ng-template>
                </ngx-datatable-column>
                <ngx-datatable-column name="Test Name" prop="protocol.Name"></ngx-datatable-column>
                <ngx-datatable-footer>

                    <div class="row">
                        <div class="col-4">
                            Results for Patient:
                        </div>
                        <input type="text" class="form-control col-4" [value]="" readonly />
                        <button class="col-3" (click)="reviewByDate()">
                            Review By Date
                        </button>
                    </div>

                </ngx-datatable-footer>
            </ngx-datatable>
        </div>
    `
})
export class ReviewComponent implements OnInit {
    series = [];
    selected = [];

    constructor (
        private footerContext: FooterContextService,
        private pouchService: PouchDBService,
        private router: Router
    ) {}

    ngOnInit () {
        this.loadSeries();
        this.activateMainButtons();
    }

    getFooterContext() {
        return this.footerContext;
    }

    loadSeries () {
        this.series = [];
        var protocol={
          patientId:'1234',
          datetime:'03/04/2018',
          protocol:{
            Name:'Sample Test'
          }
        }
        this.series.push(protocol);
        // this.pouchService.allDocs({
        //     include_docs: true,
        //     startkey: 'PATSERIES_' + this.footerContext.patient._id + '_',
        //     endkey: 'PATSERIES_' + this.footerContext.patient._id + '_\uFFFF'
        // }).then( res => {
        //     console.log('returned series', res);
        //     for (let i = 0; i < res.rows.length; i++) {
        //         res.rows[i].doc.testsAvailable = Object.keys(res.rows[i].doc.tests).length;
        //         this.series.push(res.rows[i].doc);
        //     }
        // });
    }

    activateMainButtons () {

        let reviewButton = this.selected.length === 1 ? {
            label: 'Review',
            click: () => {
                this.router.navigate(['/test/', this.selected[0]._id]);
            }
        } : {};

        let deleteButton = this.selected.length >= 1 ? {
            label: 'Delete',
            click: () => {

                if (!confirm('Really delete ' + this.selected.length + ' series?')) {
                    return;
                }

                for (let i = 0; i < this.selected.length; i++) {
                    this.pouchService.remove(this.selected[i]).then( () => {
                        console.log('deleted document', this.selected[i]);
                    });
                }

                this.loadSeries();

            }
        } : {};

        this.footerContext.activateButtons([deleteButton, {}, reviewButton, {
            label: 'Quit',
            click: () => {
                this.router.navigate(['/']);
            }
        }]);
    }

    reviewByDate() {
        this.router.navigate(['/reviewdate']);
    }

    onSelect({ selected }) {
        console.log('Select Event', selected, this.selected);

        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);

        this.activateMainButtons();
    }

    onActivate(event) {
        console.log('Activate Event', event);
    }

}
