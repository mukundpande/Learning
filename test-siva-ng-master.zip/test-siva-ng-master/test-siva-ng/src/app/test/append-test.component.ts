import {Component, OnInit} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {FormBuilder} from "@angular/forms";
import {PouchDBService} from "../services/pouchdb.service";
import {ProtocolService} from "../protocol/protocol.service";
import {FooterContextService} from "../services/footer-context.service";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Select Protocol Name &hellip;</h4>
            <button type="button" class="close" aria-label="Close" (click)="cancel()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Code</label>
                <md-select [(ngModel)]="selectedCode" (change)="testTypeChanged($event)">
                    <md-option [value]="testType" *ngFor="let testType of testTypes">{{ testType.Code }}: {{ testType.Description }}</md-option>
                </md-select>
            </div>
            <div class="form-group" *ngIf="selectedCode && tests">
                <label>Test</label>
                <md-select [(ngModel)]="selectedTest" [disabled]="noTests" style="width:100%">
                    <md-option [value]="test" *ngFor="let test of tests">{{ test.TestName }}</md-option>
                </md-select>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="select()">Save</button>
            <button type="submit" class="btn btn-danger" (click)="cancel()"> Cancel</button>
        </div>
    `
})
export class AppendTestComponent implements OnInit {
    selectedCode;
    selectedTest;

    testTypes;
    tests;

    noTests = false;

    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService,
        private protocolService: ProtocolService,
        private footerContext: FooterContextService
    ) { }

    ngOnInit () {
        this.protocolService.getTestTypes().then( res => {
            console.log('TestsComponent TC received', res);
            this.testTypes = res;
        });
    }

    getFooterContext () {
        return this.footerContext;
    }

    testTypeChanged($event) {
        console.log('opening list for', this.selectedCode); //this.testType;
        this.tests = [];
        this.noTests = false;

        if (!this.protocolService.getSourceByCode(this.selectedCode.Code)) {
            this.noTests = true;
            this.tests = [{TestName: this.selectedCode.Description}];
            this.selectedTest = this.tests[0];
            return;
        }

        this.protocolService.promiseTestsByCode(this.selectedCode.Code).then(res => this.tests = res);
    }

    select() {
        this.activeModal.close({code: this.selectedCode, test: this.selectedTest});
    }

    cancel() {
        this.activeModal.close(null);
    }
}
