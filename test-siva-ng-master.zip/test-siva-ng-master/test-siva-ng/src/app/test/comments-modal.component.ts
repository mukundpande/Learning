import {Component} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Comments &hellip;</h4>
            <button type="button" class="close" aria-label="Close" (click)="close()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form [formGroup]="commentForm">

                <div class="row">

                    <div class="col-9">

                        <div class="row">

                            <div class="col-7">

                                <label>Enter Comment Below</label>
                                <textarea class="comment-textarea" formControlName="comment"></textarea>

                                <div class="graybox">
                                    <md-checkbox formControlName="report">Include Comment With Report</md-checkbox>
                                </div>

                            </div>
                            <div class="col-5">
                                <button class="btn btn-secondary" (click)="accept()">OK</button>
                                <button class="btn btn-primary" (click)="accept(true)">OK + Continue</button>
                                <button class="btn btn-danger"  (click)="close()">Cancel</button>
                            </div>

                        </div>
                        <div class="row ">
                            <div class="col-12">
                                <div class="row graybox" style="margin:0px;">
                                    <div class="col-6">
                                        <md-checkbox formControlName="inappropriate">Inappropriate Body Mechanics</md-checkbox>
                                        <md-checkbox formControlName="symptoms">Symptom Complaints or Behaviors</md-checkbox>
                                    </div>
                                    <fieldset class="col-6">
                                        <label>Observed Effort:</label>
                                        <md-select formControlName="effort">
                                            <md-option *ngFor="let eff of efforts" [value]="eff">{{eff}}</md-option>
                                        </md-select>
                                    </fieldset>
                                </div>
                            </div>

                        </div>


                    </div>
                    <div class="col-3 graybox">
                        <label>Perceived Exertion</label>

                        <md-radio-group formControlName="exertion">
                            <md-radio-button class="own-line" *ngFor="let ex of exertions" [value]="ex.value">{{ ex.value }}{{ex.label ? ' - ' + ex.label : ''}}</md-radio-button>
                        </md-radio-group>

                    </div>

                </div>



            </form>
        </div>
        <div class="modal-footer">
            <!--<button type="submit" class="btn btn-primary" (click)="close()">Done</button>-->
        </div>
    `,
    styles: [`
        .graybox {
            background:#ccc;
            border:1px outset #ccc;
        }
        .modal-body {
            font-size:12px;
        }
        .own-line {
            display:block;
        }
        .comment-textarea {
            height:330px; width:100%; display:block;
        }
    `]
})
export class CommentsModalComponent {
    contactType;

    exertions = [
        {value:0, label: 'Nothing at all'},
        {value:0.5, label: 'Extremely weak'},
        {value:1, label: 'Very weak'},
        {value:2, label: 'Weak (light)'},
        {value:3, label: 'Moderate'},
        {value:4,},
        {value:5, label: 'Strong (heavy)'},
        {value:6},
        {value:7, label: 'Very strong'},
        {value:8},
        {value:9},
        {value:10, label: 'Extremely strong'},
        {value:'N/A'},
    ];

    efforts = ['Poor', 'Poor to Fair', 'Fair', 'Average', 'Good', 'Excellent', 'Excessive'];

    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService
    ) { }

    commentForm = this.fb.group({
        exertion: [0],
        effort: ['Average'],
        inappropriate: [false],
        symptoms: [false],
        report: [false],
        datetime: [new Date()],
        comment: ['']
    });

    loadComments(data) {
        if(data) {
            console.log('patching in data', data);
            this.commentForm.patchValue(data);
        }
    }

    accept (goForward = false) {
        console.log('saving comments with data', this.commentForm.value);
        this.activeModal.close({
            data: this.commentForm.value,
            goForward: goForward
        });
    }

    close () {
        this.activeModal.close(false);
    }

}
