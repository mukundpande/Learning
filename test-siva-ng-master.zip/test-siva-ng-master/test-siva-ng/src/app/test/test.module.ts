import {NgModule} from "@angular/core";
import {TestComponent} from "./test.component";
import {TestRoutingModule} from "./test-routing.module";
import {WpiService} from "../services/wpi.service";
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {CommonModule, DatePipe} from "@angular/common";
import {MdButtonToggleModule, MdCheckboxModule, MdIconModule, MdRadioModule, MdSelectModule} from "@angular/material";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {ReviewComponent} from "./review.component";
import {TestRmComponent} from "./test-rm.component";
import {TestEgComponent} from "./test-eg.component";
import {TestCxComponent} from "./test-cx.component";
import {TestStComponent} from "./test-st.component";
import {CalculationsService} from "../services/calculations.service";
import {ReportsComponent} from "../reports/reports.component";
import {ReportExportModalComponent} from "../reports/report-export-modal.component";
import {InstructionsModalComponent} from "./instructions-modal.component";
import {CommentsModalComponent} from "./comments-modal.component";
import {ReportTechComponent} from "../reports/report-tech.component";
import {ReportMainComponent} from "../reports/report-main.component";
import {ReportService} from "../reports/report.service";
import {ChartsModule} from "ng2-charts";
import {TestHdComponent} from "./test-hd.component";
import {ReportFragmentSectionHeadingComponent} from "../reports/report-fragment-section-heading.component";
import {ReportFragmentExplanationStaticStrengthComponent} from "../reports/report-fragment-explanation-static-strength.component";
import {TestService} from "./test.service";
import {ReportGraphPrepComponent} from "../reports/report-graph-prep.component";
import {TestNaComponent} from "./test-na.component";


@NgModule({
    imports: [
        CommonModule,
        TestRoutingModule,
        MdRadioModule,
        MdCheckboxModule,
        MdSelectModule,
        MdButtonToggleModule,
        MdIconModule,
        ChartsModule,
        FormsModule,
        ReactiveFormsModule,
        NgxDatatableModule
    ],
    declarations: [
        CommentsModalComponent,
        InstructionsModalComponent,
        TestComponent,
        TestCxComponent,
        TestEgComponent,
        TestHdComponent,
        TestNaComponent,
        TestRmComponent,
        TestStComponent,
        ReportExportModalComponent,
        ReportFragmentSectionHeadingComponent,
        ReportFragmentExplanationStaticStrengthComponent,
        ReportGraphPrepComponent,
        ReportMainComponent,
        ReportTechComponent,
        ReportsComponent,
        ReviewComponent
    ],
    entryComponents: [
        CommentsModalComponent,
        InstructionsModalComponent,
        ReportExportModalComponent,
        ReportGraphPrepComponent,
    ],
    providers: [
        DatePipe,
        CalculationsService,
        ReportService,
        TestService,
        WpiService
    ]
})
export class TestModule { }
