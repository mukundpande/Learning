import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {ProtocolService} from "../protocol/protocol.service";
import {Router} from "@angular/router";
import {FooterContextService} from "../services/footer-context.service";
import {TestEditorModalComponent} from "../test/test-editor-modal.component";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
@Component({
    template: `
        <div class="container white" *ngIf="testType">
            <div class="row" *ngIf="!createMode">
                <div class="col-6">
                    <b>Current Test Type &hellip;</b>
                </div>
                <md-select class="col-6" #testTypeSelect name="selectTestType" [(ngModel)]="testType" (change)="updateList()">
                    <md-option *ngFor="let testType of testTypes" [value]="testType">
                        <b>{{ testType.Code }}</b><span style="color:#888;"> - {{ testType.Description }}</span>
                    </md-option>
                </md-select>
            </div>

            <div class="row" *ngIf="createMode">
                <div class="col-6"><label>Enter New Name: </label></div>
                <div class="col-6"><input type="text" class="form-control" [(ngModel)]="enterNewName"></div>
            </div>

            <b>{{this.testType.Code}} - {{ this.testType.Description }}</b>
            <ul style="height:300px; overflow-y: scroll">
                <li *ngFor="let test of tests" (dblclick)="editTest(test)">
                    {{ test.TestName }}
                    <button *ngIf="!createMode" class="btn btn-danger btn-sm" (click)="deleteTest(test)">Delete</button>
                </li>
            </ul>

            <div class="row">
                <div class="col-6">
                    <b>Test Editor Active:</b>
                </div>
                <button class="col-5 btn btn-secondary" (click)="editProtocols()">To Edit Protocols, Click Here</button>
            </div>

        </div>
    `
})
export class TestsComponent implements OnInit {
    testTypes = [];
    testType;
    private lastTestTypeKey = 'lastTestType';
    private tests = [];

    createMode = false;
    enterNewName = '';

    private source;
    private sources = {
        'AirsTest': ['AI'],
        'NadepTest': ['NA', 'MT', 'PE'],
        'RomTest': ['EG', 'RM'],
        'StaticTest': ['ST', 'CX', 'HD', 'PG'],
    };

    constructor (
        private footerContext: FooterContextService,
        private modalService: NgbModal,
        private protocolService: ProtocolService,
        private pouchService: PouchDBService,
        private router: Router
    ) {}

    activateMainButtons () {

        let buttons = [{
            label: 'Quit',
            click: () => {
                this.router.navigate(['/']);
            }
        }];

        if (this.protocolService.getSourceByCode(this.testType.Code)) {
            buttons.unshift({
                label: 'New',
                click: () => {

                    if (!this.protocolService.getSourceByCode(this.testType.Code)) {
                        alert('Cannot create a new test');
                        return;
                    }

                    this.createMode = true;
                    this.enterNewName = '';

                    this.footerContext.activateButtons([{
                        label: 'OK',
                        click: () => {
                            if(!this.enterNewName.length) {
                                alert('Please enter a name for the test.');
                                return false;
                            }

                            let newTest = {
                                Device: this.testType.Code,
                                TestName: this.enterNewName
                            }

                            this.protocolService.addNewTest(newTest).then( res => {
                                this.tests = res;
                                console.log('New test added', res);
                            });

                            this.createMode = false;
                            this.activateMainButtons();
                        }
                    }, {
                        label: 'Cancel',
                        click: () => {
                            this.createMode = false;
                        }
                    }]);


                }
            });
        }

        this.footerContext.activateButtons(buttons);
    }


    editProtocols () {
        this.router.navigate(['protocol']);
    }

    ngOnInit () {
        this.protocolService.getTestTypes().then( res => {
            console.log('TestsComponent TC received', res);
            this.testTypes = res;

            this.retrieveList();
        });
    }

    editTest (test) {
        const modalRef = this.modalService.open(TestEditorModalComponent, {'size':'lg'});
        modalRef.result.then(res => {
            console.log('Resulting Response', res);
        }, rej => {

        });

        console.log('Running editor for test', this.testType, test);

        modalRef.componentInstance.acceptTest({ code: this.testType.Code, name: test.TestName });
    }

    retrieveList () {
        let lastTestType;
        if (!(lastTestType = localStorage.getItem(this.lastTestTypeKey))) {
           lastTestType = this.testTypes[0].Code || '--';
        }

        for (let i = 0; i < this.testTypes.length; i++) {
            if (this.testTypes[i].Code === lastTestType) {
                this.testType = this.testTypes[i];
                this.updateList();
                return;
            }
        }

        console.error('Could not locate the last test.');
    }

    deleteTest (test) {
        if (!confirm('Are you ABSOLUTELY SURE you want to delete this test? This is not reversible!')) {
           return false;
        }

        this.protocolService.deleteTest(this.testType.Code, test.TestName).then (tests => {
            this.tests = tests;
            this.footerContext.updateProtocols();
        });
    }

    updateList () {
        console.log('updateList() -- ', this.testType);

        localStorage.setItem(this.lastTestTypeKey, this.testType.Code);

        if(!this.protocolService.getSourceByCode(this.testType.Code)) {
            this.tests = [];
        } else {
            this.protocolService.promiseTestsByCode(this.testType.Code).then (tests => {
                this.tests = tests;
            });
        }
        this.activateMainButtons();
        return;
        //
        // for (let source in this.sources) {
        //     if (true) {
        //         console.log('examining', source, this.sources[source], this.sources[source].indexOf(this.testType.Code));
        //         if (this.sources[source].indexOf(this.testType.Code) !== -1) {
        //             this.source = source;
        //
        //             this.pouchService.get('ARC_PROTOCOL_' + this.source).then( (res) => {
        //                 console.log('Returned list', res);
        //                 this.tests = res.items;
        //             });
        //             return;
        //         }
        //     }
        // }

    }
}
