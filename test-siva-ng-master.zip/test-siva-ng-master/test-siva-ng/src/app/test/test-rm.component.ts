import {ApplicationRef, Component, Input, OnInit, ViewChild} from "@angular/core";
import {CalculationsService} from "../services/calculations.service";
@Component({
    selector: 'test-rm',
    templateUrl: './test-rm.component.html',
    styleUrls: ['./test-rm.component.css']
})
export class TestRmComponent implements OnInit {
    ignoreChange = false;
    chartA: any = {
        data: [{
            label: 'Trials',
            data: [],
            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f'],
            bars: [
                {fillColor: '#ff0000', backgroundColor: '#f00'},
                {fillColor: '#00ffff', backgroundColor: '#0ff'},
                {fillColor: '#ffff00', backgroundColor: '#0ff'},
                {fillColor: '#f0f', backgroundColor: '#0ff'},
                {fillColor: '#0f0', backgroundColor: '#0ff'},
                {fillColor: '#00f', backgroundColor: '#0ff'},
            ]
        }],
        type: 'bar',
        colors: [{
            // backgroundColor: 'rgba(255,255,255,1)',
            // borderColor: 'rbga(0,0,0,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3', '4', '5', '6'],
        options: {
            animation: {
                duration: 1,
                onComplete: (a) => {
                    console.error('CHART ANIMATION FINISHED', a);
                }
            },
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }

    chartB: any = {
        data: [{
            label: 'Trials',
            data: [],
            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f'],
            bars: [
                {fillColor: '#ff0000', backgroundColor: '#f00'},
                {fillColor: '#00ffff', backgroundColor: '#0ff'},
                {fillColor: '#ffff00', backgroundColor: '#0ff'},
                {fillColor: '#f0f', backgroundColor: '#0ff'},
                {fillColor: '#0f0', backgroundColor: '#0ff'},
                {fillColor: '#00f', backgroundColor: '#0ff'},
            ]
        }],
        type: 'bar',
        colors: [{
            // backgroundColor: 'rbga(0,0,0,1)',
            // borderColor: 'rgba(255,255,255,1)',
            // pointBackgroundColor: 'rgba(148,159,177,1)',
            // pointBorderColor: '#fff',
            // pointHoverBackgroundColor: '#fff',
            // pointHoverBorderColor: 'rgba(148,159,177,0.8)'
        }],
        legend: false,
        labels: ['1', '2', '3', '4', '5', '6'],
        options: {
            animation: {
                duration: 1,
                onComplete: (a) => {
                    console.error('CHART ANIMATION FINISHED', a);
                }
            },
            scales: {
                xAxes: [{
                    // ticks: {
                    //     min: 0,
                    //     max: 1
                    // }
                }],
                yAxes: [{
                    ticks: {
                        // max: 250,
                        beginAtZero: true
                    }
                }]
            }
        }
    }

    testActive = false;
    testComplete = false;
    @Input() testData: any = {};
    @Input() viewData: any = {};
    trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
    trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
    comparisonMethod = 'mea';
    calculationMethod = 'rnd';
    resolve;
    reject;

    @ViewChild('firstInput') firstInput: any;
    @ViewChild('secondInput') secondInput: any;
    @ViewChild('firstChart') firstChart: any;
    @ViewChild('secondChart') secondChart: any;


    constructor (
        private appRef: ApplicationRef,
        private calcService: CalculationsService
    ) {}

    ngOnInit () {
        console.log('RM LOADING WITH ', this.testData, this.viewData);
        this.resetChartSettings();
        this.updateChartValues(0);
        this.updateChartValues(1);
    }

    resetChartSettings () {
        console.log('test-cs.component::resetChartSettings() -- ', this.viewData);
        this.chartA.options = {
            animation: {
                // duration: 0,
                // onComplete: (a) => {
                //     console.error('CHART ANIMATION FINISHED 2', a);
                // }
            },
            scales: {
                yAxes: [{
                    ticks: {
                        max: this.viewData.test ? +this.viewData.test.ScaleMax : null,
                        beginAtZero: true
                    }
                }]
            }
        }

        this.chartB.options = {
            animation: {
                // duration: 0,
                // onComplete: (a) => {
                //     console.error('CHART ANIMATION FINISHED 2', a);
                // }
            },
            scales: {
                yAxes: [{
                    ticks: {
                        min: this.viewData.test ? -this.viewData.test.ScaleMax : null,
                        beginAtZero: true
                    }
                }]
            }
        }
    }

    updateChartValues (y = 0) {
        // this.lineChartData = [];
        let newData = [];
        let side = ['A','B'][y];

         console.log("test-rm::updateChartValues() -- starting loop", this.testData);
        let data = [];
        let labels = [];
        for (let i = 0; i < +this.viewData.test.MaxTrials; i++) {
            labels.push(i+1);
            if (this.testData['trials'+side] && this.testData['trials'+side][i]) {
                console.log('test-rm::updateChartValues() -- checking', side, i, this.testData['trials'+side][i]);
                let dat = this.testData['trials'+side][i].value;
                data.push(dat*(y?-1:1));
            } else if(!this.testData['trials'+side]) {
                console.log('test-rm::updateChartValues() -- Missing testData index', 'trials'+side);
            } else {
                console.log('test-rm::updateChartValues() -- could not locate index for', side, i);
            }
        }
        newData.push({
            label: 'Trials',
            data: data,
            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f'],
            bars: [
                {fillColor: '#ff0000', backgroundColor: '#f00'},
                {fillColor: '#00ffff', backgroundColor: '#0ff'},
                {fillColor: '#ffff00', backgroundColor: '#0ff'},
                {fillColor: '#f0f', backgroundColor: '#0ff'},
                {fillColor: '#0f0', backgroundColor: '#0ff'},
                {fillColor: '#00f', backgroundColor: '#0ff'},
            ]
        });
        this['chart'+side].labels = labels;
        this['chart'+side].data = newData;

        console.log('firstChart', this.firstChart, 'secondChart', this.secondChart);


        // console.log(this.testData);
    }

    tabIndex (x, y, z) {
        if (z && !+this.viewData.test.Dual) {
            return 0;
        }
        return (x+6*y)*(!+this.viewData.test.Dual ? 1 : 2) + z + 1;
    }

    trialInputDisabled (x, y, z) {
        if(this.isBilateral() && !x) {
            return false;
        }
        if (z && !+this.viewData.test.Dual) {
            return true;
        }
        if (!this.testActive || this.testComplete) {
            return true;
        }
        if (y && !this.testData.secondTask || !y && this.testData.secondTask) {
            return true;
        }
        if (y && x > this.testData.trialsB.length || !y && x > this.testData.trialsA.length) {
            return true;
        }
        return false;
    }

    zSideOverride (z) {
        if (z || this.viewData.labels.length === 1) {
            return 0;
        }
        return 1;
    }

    detectTabKey($event, x, y, z) {
        if ($event.keyCode === 9) {
            $event.target.valueAsNumber = this['trial'+['Uppers','Lowers'][z]][x+y*6] = this['trial'+['Uppers','Lowers'][z]][x+y*6] || 0;
            this.processTrialInputs($event, x, y, z);
        }
    }

    processTrialInputs ($event, x, y, z) {

        if(this.ignoreChange) {
            console.log('CHANGE HAPPENED MID-TRANSITION, IGNORING');
            this.ignoreChange = false;
            return;
        }

        let useSideB = y || this.isBilateral() && this.testData.secondTask;

        // console.log('BILATERAL STUFF', {y: y, bi: this.isBilateral(), st: this.testData.secondTask, td: this.testData, condition: useSideB});

        console.log('CAPTURED INPUT for ','Trial' + (x+1),useSideB?'B':'A',z?'Lower':'Upper', $event.target.valueAsNumber);
        let trialLetter = (useSideB ? 'B' : 'A')
        let trialSide = 'trials' + trialLetter;

        if (!this.testData[trialSide][x]) {
            this.testData[trialSide][x] = { upper: null, lower: null, value: null };
        }

        if (!z) {
            this.testData[trialSide][x].upper = $event.target.valueAsNumber;
            console.log('CAPTURED UPPER VALUE, OBJ IS', this.testData[trialSide][x]);
            if (!this.testData[trialSide][x].lower && +this.viewData.test.Dual) {
                return;
            }
        } else {
            this.testData[trialSide][x].lower = $event.target.valueAsNumber;
            console.log('CAPTURED LOWER VALUE, OBJ IS', this.testData[trialSide][x]);
        }

        this.testData[trialSide][x].value = Math.abs(
            this.testData[trialSide][x].upper - this.testData[trialSide][x].lower
        );

        if (!this.isBilateral() || !this.testData.secondTask) {
            this.updateChartValues(y);
        }
        let trialCompletion = this.trialDataCompleted(this.testData[trialSide]);

        if (trialCompletion !== false) {

            if(trialCompletion === -1) {
                this.testData['failed' + trialLetter] = true;
            }

            let useAverage = false;

            this.testData['rom' + trialLetter] = Math.round(this.calcService['generate' + (useAverage?'Average':'Maximum')](this.testData[trialSide])).toString();
            this.testData['upper' + trialLetter] = Math.round(this.generateAverage(this.testData[trialSide],'upper'));
            this.testData['lower' + trialLetter] = Math.round(this.generateAverage(this.testData[trialSide],'lower'));

            if (this.isBilateral()) {

                if (this.testData.secondTask) {
                    this.testData.secondTask = false;
                    $event.stopPropagation();
                    $event.preventDefault();

                    console.error('Swapping sides', {td: this.testData});
                    this.testData.trialsA = [];
                    this.trialUppers[0] = null;
                    this.trialLowers[0] = null;
                    this.trialFields[6] = this.testData.trialsB[0].value;

                    this.ignoreChange = true;

                    this.appRef.tick();
                    this.firstInput.nativeElement.focus();
                } else {
                    this.testCompleted();
                }

                return;
            }


            if(y || this.viewData.labels.length < 2) {
                this.testCompleted();
            } else {
                this.testData.secondTask = true;
                $event.stopPropagation();
                $event.preventDefault();
                this.appRef.tick();
                this.secondInput.nativeElement.focus();
            }
        }
    }

    trialDataCompleted (myArray) {
        console.error('EVALUATING TRIAL DATA FOR', myArray);

        if(this.isBilateral() && this.testData.secondTask) {
            return true;
        }

        if (myArray.length < 3) {
            console.log('[test-rm::trialDataCompleted] Not enough trials, continuing...');
            return false;
        }
        let lastThree = myArray.slice(myArray.length-3, myArray.length);
        let mean = this.generateAverage(lastThree);
        console.log('Feeding mean to stDev which is', mean);
        let stDev = this.calcService.generateStandardDeviation(lastThree, mean, 4);
        let coVar = this.generateCoefficientOfVariation(stDev, mean);
        console.log('[test-rm::trialDataCompleted] Calculated data to see if trials are completed: ', {
            avg: mean,
            std: stDev,
            cv: coVar,
            lastThree: lastThree
        });
        if (stDev < 5 && coVar < .1) {
            console.log('[test-rm::trialDataCompleted] Trials are within boundaries. Stopping...');
            return true;
        }
        if (myArray.length === +this.viewData.test.MaxTrials) {
            console.log('[test-rm::trialDataCompleted] Could not reconcile trials, marking as failed');
            return -1;
        }
        console.log('[test-rm::trialDataCompleted] Trials are not close enough, continuing...');
        return false;
    }

    testCompleted () {
        this.testComplete = true;
        this.resolve(this.testData);
    }

    generateAverage (myArray, key = 'value') {
        let total = 0;
        for (let i = 0; i < myArray.length; i++) {
            total += myArray[i][key];
        }
        return total / myArray.length;
    }

    generateStandardDeviation (myArray, mean = null) {
        if (!mean) {
            mean = this.generateAverage(myArray);
        }

        let total = 0;
        for (let j = 0; j < myArray.length; j++) {
            total += Math.pow((myArray[j].value - mean), 2);
        }
        return Math.sqrt(total / (myArray.length - 1));
    }

    generateCoefficientOfVariation(stDev, mean) {
        if(mean === 0) {
            return 0;
        }
        return stDev / mean;
    }

    resetTest () {
        console.log('### RESETTING TEST --- ');
        this.trialFields = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialUppers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.trialLowers = [null, null, null, null, null, null, null, null, null, null, null, null];
        this.testData = {};
        //this.viewData = {};



        this.testActive = false;
        this.testComplete = false;
    }

    loadTestData (testData) {
        console.log('LOAD TEST DATA -- loading test data for', testData);

        for (let i = 0; i < testData.trialsA.length; i++) {
            this.trialUppers[i] = testData.trialsA[i].upper;
            this.trialLowers[i] = testData.trialsA[i].lower;
        }

        for (let i = 0; i < testData.trialsB.length; i++) {
            this.trialUppers[i+6] = testData.trialsB[i].upper;
            this.trialLowers[i+6] = testData.trialsB[i].lower;
        }


    }

    isBilateral () {
        return this.viewData.test.TestName == 'Thoracic Flexion';
    }

    startTest () {
        this.testActive = true;
        this.testData.step = 0;
        this.testData.trialsA = [];
        this.testData.trialsB = [];

        if(this.isBilateral()) {
            this.testData.secondTask = true;
        }

        this.appRef.tick();

        this.firstInput.nativeElement.focus();

        let promise = new Promise( (res, rej) => { this.resolve = res; this.reject = rej; });
        return promise;
    }
}
