import {Component, ViewChild} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
import {ProtocolService} from "../protocol/protocol.service";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Editing Test Record &hellip;</h4>
            <button type="button" class="close" aria-label="Close" (click)="cancel()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">

            <ng-container *ngIf="test" [ngSwitch]="testParams.code">
                <editor-cx #testEl *ngSwitchCase="'CX'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos" [units]="info.units"></editor-cx>
                <editor-cx #testEl *ngSwitchCase="'HD'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos" [units]="info.units"></editor-cx>
                <editor-cx #testEl *ngSwitchCase="'PG'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos" [units]="info.units"></editor-cx>
                <editor-eg #testEl *ngSwitchCase="'EG'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos"></editor-eg>
                <editor-rm #testEl *ngSwitchCase="'RM'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos"></editor-rm>
                <editor-st #testEl *ngSwitchCase="'ST'" [test]="test" [testModes]="info.testModes" [graphInfos]="info.graphInfos" [units]="info.units" [jobTasks]="info.jobTasks"></editor-st>
                <ng-container #testEl *ngSwitchDefault>
                    No Editor Available
                </ng-container>
            </ng-container>
            <!---->
            <!---->

        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="save()"> Save</button>
            <button type="submit" class="btn btn-danger" (click)="cancel()"> Cancel</button>
        </div>
    `
})
export class TestEditorModalComponent {
    testParams;
    test;
    testModes;
    graphInfos;
    units;

    info = {};

    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService,
        private protocolService: ProtocolService
    ) { }

    // testForm = this.fb.group([
    //
    // ]);

    @ViewChild('testEl') testEl: any;

    acceptTest(test) {
        console.log('## Accepted FORM information', test);
        this.testParams = test;

        this.loadTest();
    }

    loadTest () {
        this.protocolService.promiseFormInfoLoaded().then(info=>{
            this.info = info;

            console.log('FORM INFO LOADED -- pulling test, now', this.testParams);
            this.protocolService.promiseTest(this.testParams).then( res => {
                console.log('PROMISE TEST -- returned', res);
                this.test = res;
            }, err => {
                console.error('Could not find test', err);
            });
        });
    }

    save () {
        console.log('saving', this.test, this.testEl.testForm.value);

        this.activeModal.close(this.protocolService.save(this.test, this.testEl.testForm.value));
    }


    cancel () {
        this.activeModal.close(false);
    }

}
