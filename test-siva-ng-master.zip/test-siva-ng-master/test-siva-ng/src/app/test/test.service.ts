import {Injectable} from "@angular/core";
import {FooterContextService} from "../services/footer-context.service";
@Injectable()
export class TestService {
    constructor (
        // private footerContext: FooterContextService
    ) { }

    startNewSeries () {

    }

    saveSeries () {

    }

    slashsplit(string, prependBeginner = false) {
        var chunks = string.split(' ');
        var index;

        for (var i = 0; i < chunks.length; i++) {
            if (chunks[i].indexOf('/') !== -1) {
                index = i;
                break;
            }
        }

        var trailing = chunks.splice(index);
        var slashchunk = trailing.shift().split('/');

        var splits = [];
        for (var i = 0; i < slashchunk.length; i++) {
            let arr = prependBeginner ? chunks : [];
            var temp = arr.concat([slashchunk[i]].concat(trailing));

            splits.push(temp.join(' '));
        }

        return splits;
    }
}
