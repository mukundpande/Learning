import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule,BrowserXhr} from '@angular/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MdCardModule} from '@angular/material';
import {MdDialogModule} from '@angular/material';
import { AppComponent } from './app.component';
import { ContactDetailsComponent } from './contacts/contact-details.component';
import { ContactListComponent } from './contacts/contact-list.component';
import {AppRoutingModule} from "./app-routing.module";
import {FrontPageComponent} from "./front-page.component";
import {PageNotFoundComponent} from "./utils/not-found.component";
import {AuthService} from "./admin/auth.service";
import {LoginDialogComponent} from "./login-dialog/login-dialog.component";
import {SearchpatientComponent} from "./searchpatient/searchpatient.component";
import {PouchDBService} from "./services/pouchdb.service";
import {AdminModule} from "./admin/admin.module";
import {AdminGuard} from "./admin/admin-guard.service";
import {CommonModule} from "@angular/common";
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {PatientComponent} from "./patient/patient.component";
import {MdButtonModule, MdRadioModule, MdTabsModule, MdSelectModule, MdAutocompleteModule} from "@angular/material";
import {FooterContextService} from "./services/footer-context.service";
import {DebugComponent} from "./utils/debug-component";
import {ProtocolService} from "./protocol/protocol.service";
import {FtueModalComponent} from "./services/ftue-modal.component";
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {FtueService} from "./services/ftue.service";
import {TestModule} from "./test/test.module";
import {WpiService} from "./services/wpi.service";
import {PatientService} from "./patient/patient.service";
import {PatientContactModalComponent} from "./patient/patient-contact-modal.component";
import {ProtocolModule} from "./protocol/protocol.module";
// import {PatientDiagnosisModalComponent} from "./patient-diagnosis-modal.component";
import {PdfTestComponent} from "./utils/pdf-test.component";
import {WordService} from "./utils/word.service";
import { FroalaEditorModule, FroalaViewModule } from 'angular2-froala-wysiwyg';
import {ErrorDisplayModalComponent} from "./utils/error-display-modal.component";
import {AmputationsModalComponent} from "./utils/amputations-modal.component";
import {WebcamComponent} from "./patient/webcam.component";
import {PatientDiagnosis10ModalComponent} from "./patient/patient-diagnosis10-modal.component";
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
import {OrderByPipe} from "./utils/orderbypipe.component";
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { FilterPipe } from './searchpatient/filter.pipe';

@NgModule({
    declarations: [
        AmputationsModalComponent,
        AppComponent,
        ContactDetailsComponent,
        ContactListComponent,
        DebugComponent,
        ErrorDisplayModalComponent,
        FrontPageComponent,
        FtueModalComponent,
        PageNotFoundComponent,
        PatientComponent,
        PatientContactModalComponent,
        PatientDiagnosis10ModalComponent,
        PdfTestComponent,
        WebcamComponent,
        LoginDialogComponent,
        SearchpatientComponent,
        ManageUsersComponent,
        SearchpatientComponent,
        OrderByPipe,
        FilterPipe
    ],
    entryComponents: [
        AmputationsModalComponent,
        ErrorDisplayModalComponent,
        FtueModalComponent,
        PatientContactModalComponent,
        PatientDiagnosis10ModalComponent,
        WebcamComponent,
        LoginDialogComponent,
        SearchpatientComponent,
        PatientComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MdCardModule,
        MdButtonModule,
        MdDialogModule,
        NgxDatatableModule,
        HttpModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MdRadioModule,
        MdTabsModule,
        MdSelectModule,
        MdAutocompleteModule,
        NgbModule.forRoot(),
        FroalaEditorModule.forRoot(), FroalaViewModule.forRoot(),
        AdminModule,
        TestModule,
        ProtocolModule,
        AppRoutingModule,
        Ng2FilterPipeModule,
        AngularFontAwesomeModule
    ],
    providers: [
        AdminGuard,
        AuthService,
        FooterContextService,
        FtueService,
        PatientService,
        PouchDBService,
        ProtocolService,
        WordService,
        WpiService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
