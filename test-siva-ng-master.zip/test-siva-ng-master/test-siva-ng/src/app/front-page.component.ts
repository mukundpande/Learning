import {Component, OnInit} from '@angular/core';
import {AuthService} from './admin/auth.service';
import {Router} from '@angular/router';
import {FooterContextService} from "./services/footer-context.service";
import {PouchDBService} from "./services/pouchdb.service";

@Component({
    template: `
        <div class="container white">
            <h1>Welcome</h1>
            <!--<p></p>-->

            <!--<div *ngIf="!getPouch().currentUser">-->
                <!--Login-->
            <!--</div>-->
            <!--<div *ngIf="getPouch().currentUser">-->
                <!--You are logged in-->
            <!--</div>-->

        </div>
    `
})
export class FrontPageComponent implements OnInit {
    constructor(
        private authService: AuthService,
        private router: Router,
        private footerContext: FooterContextService,
        private pouchService: PouchDBService
    ) { }
    ngOnInit () {
        // if(this.authService.isLoggedIn)
        //     this.authService.getCurrentUser().subscribe((res) => {
        //         this.router.navigate(['dashboard']);
        //     });
        this.footerContext.activateMain();
    }

    getPouch () {
        return this.pouchService;
    }
}
