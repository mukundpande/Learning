import {Component} from "@angular/core";
import * as Papa from 'papaparse/papaparse.min.js';
import {PouchDBService} from "../services/pouchdb.service";

@Component({
    template: `
        <div class="container white">
            <h3>Upload</h3>

            <input type="text" [(ngModel)]="target" class="form-control" placeholder="_id" />

            <input type="file" (change)="readUpload($event)" #input />
        </div>
    `
})
export class CsvComponent {
    target = '';

    constructor (private pouchService: PouchDBService) { }

    readUpload($event) {
        alert('disabled');
        // const someValue = false;
        // if(someValue) {
        //     console.log('reading upload', $event);
        //
        //     let fr: FileReader = new FileReader();
        //     let file: File = $event.target.files[0];
        //     let data = [];
        //
        //     Papa.parse(file, {
        //         complete: results => {
        //
        //             let headers = results.data.shift();
        //
        //             for (let i = 0; i < headers.length; i++)  {
        //                 headers[i] = headers[i].replace(/[.\s]+/gi, '');
        //             }
        //
        //             //headers[0] = '_id'; // for pouchDB
        //
        //             for (let i = 0; i < results.data.length; i++) {
        //                 let json: any = {};
        //
        //                 // skip bad column counts
        //                 if (results.data[i].length !== headers.length) { continue; }
        //
        //                 for (let j = 0; j < results.data[i].length; j++) {
        //                     json[headers[j]] = results.data[i][j];
        //                 }
        //
        //                 data.push(json);
        //
        //                 //json._id = 'PAT_' + json._id; // for pouchDB
        //                 //console.log('UPLOADING THIS OBJECT', json);
        //                 //this.pouchService.put(json._id, json);
        //             }
        //
        //             console.log('FINISHED - data loaded', headers, data.length);
        //
        //             let doc = {
        //                 items: data
        //             }
        //
        //             if (this.target.length) {
        //                 this.pouchService.put(this.target, doc).then(doc => {
        //                     console.log('Upload successful!', doc);
        //                 }, err => {
        //                     console.error('Could not push, reason', err);
        //                 })
        //             }
        //
        //         }
        //     });
        // }
    }
}
