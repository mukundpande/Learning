import { Component } from '@angular/core';

@Component({
  template: `<div class="container white">
      <h2>Page not found</h2>
      <a routerLink="/" class="btn btn-default">Go Home</a>
  </div>`
})
export class PageNotFoundComponent {}
