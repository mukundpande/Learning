import {Component} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {FtueService} from "../services/ftue.service";
import {WordService} from "./word.service";



@Component({
    template: `
        <div class="container white">
            <h1>Debug Section</h1>
            <!---->
            <!--<button (click)="indexTest()" class="btn btn-primary">Index Test</button>-->

            <ul style="list-style:none;">
                <li>
                    <button (click)="ftue()" class="btn btn-primary">View First-Time User Explanation</button>
                </li>
            </ul>

            <!--<button (click)="allDocs()">Print Offline Document IDs to Debug Console</button>-->
        </div>
    `
})
export class DebugComponent {
    constructor (
        private pouchService: PouchDBService,
        private ftueService: FtueService

    ) { }
    indexTest() {
        console.log('Indexing Test');

        let db = this.pouchService.getDb();
        db.find({
            selector: {'_id': {'$gt': 'PAT_', '$lt': 'PAT_\uFFFF'}, 'LastName': {'$gt': 'Er', '$lt': 'Er\uffff'}},
            fields: ['_id', 'FirstName', 'LastName'],
            sort: ['_id']
        }).then(function (result) {
            // handle result
            console.log('results', result);
        }).catch(function (err) {
            console.log(err);
        });

        // this.pouchService.getDb().createIndex({
        //     index: {
        //         fields: ['type']
        //     }
        // }).then(() => {
        //     return this.pouchService.getDb().find({
        //         selector: {
        //             type: 'patient',
        //         }
        //     });
        // }).then(res => { console.log('RESPONSE: ', res); });
    }

    printDoc () {
    }

    allDocs () {
        this.pouchService.allDocs().then( res => {
            console.log('DEBUG:: returned All Docs', res);
        });
    }

    ftue () {
        this.ftueService.openFTUE();
    }
}
