import {Component} from "@angular/core";
import {PatientService} from "../patient/patient.service";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Editing Amputations</h4>
            <button type="button" class="close" aria-label="Close" (click)="close()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">

            <div class="form-group" *ngIf="amputations">
                <label>Add New Amputation</label>
                <select class="form-control" [(ngModel)]="selectedAmputation">
                    <option [value]="null"> -- Select Amputation --</option>
                    <option [ngValue]="amputation" *ngFor="let amputation of amputations;">
                        {{ amputation.AMPUTATION }} ({{ amputation.LOCATIONNAME }})
                    </option>
                </select>
                <button class="btn btn-success btn-block" (click)="addAmputation(selectedAmputation)">
                     Add Selected Amputation
                </button>
            </div>

            <ul style="list-style:none;">
                <li *ngIf="!patient.amputations.length">No amputations</li>
                <li *ngFor="let amputation of patient.amputations; let i = index;">
                    {{ amputation.AMPUTATION }} ({{ amputation.LOCATIONNAME }})
                    <button class="btn btn-danger" (click)="removeAmputation(i)">
                        Remove
                    </button>
                </li>
            </ul>

        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="close()">OK</button>
        </div>
    `
})
export class AmputationsModalComponent {
    constructor (private ngbModal: NgbActiveModal) {}
    patient;

    amputations;

    selectedAmputation = null;
    changesMade = false;

    open (patient) {
        this.patient = patient;

        if(!patient.amputations) {
            patient.amputations = [];
        }

        // this.patientService.promiseInfo().then((info: any) => {
        //     // console.log('PATIENT SERVICE LOADED INFO', info);
        //     let amputations = [];
        //     for (let i = 0; i < info.amputations.length; i++) {
        //         let amputation = info.amputations[i];
        //         // console.log('Loading Amputation Option', amputation);
        //         if (+amputation.DUAL) {
        //             let left = this.findLocation(info.bodycodes, amputation.LEFTBODYCODE);
        //             let right = this.findLocation(info.bodycodes, amputation.RIGHTBODYCODE);
        //             // console.log('Amputation is a DUAL', left, right);
        //             amputations.push({
        //                 AMPUTATION: amputation.AMPUTATION,
        //                 LOCATIONNAME: left.DESCRIP,
        //                 LOCATION: amputation.LEFTBODYCODE
        //             });
        //             amputations.push({
        //                 AMPUTATION: amputation.AMPUTATION,
        //                 LOCATIONNAME: right.DESCRIP,
        //                 LOCATION: amputation.RIGHTBODYCODE
        //             });
        //         } else {
        //             let body = this.findLocation(info.bodycodes, amputation.BODYCODE);
        //             // console.log('Amputation is NOT a DUAL', body);
        //             amputations.push({
        //                 AMPUTATION: amputation.AMPUTATION,
        //                 LOCATIONNAME: body.DESCRIP,
        //                 LOCATION: amputation.BODYCODE
        //             });
        //         }
        //
        //     }
        //
        //     this.amputations = amputations;
        //
        // });
    }

    findLocation (list, location) {
        // console.log('Searchin for', location);
        for (let j = 0; j < list.length; j++) {
            // console.log('Scanning Body Code');
            let loc = list[j];
            if (loc.LOCATION == location) {
                return loc;
            }
        }
        // console.error('Could not find location', location, 'in', list);
        return false;
    }

    addAmputation (amputation) {
        if (!amputation) {
            return;
        }
        this.changesMade = true;
        console.log('pushing', amputation);
        this.selectedAmputation = null;
        this.patient.amputations.push(amputation);
    }

    removeAmputation (index) {
        this.changesMade = true;
        this.patient.amputations.splice(index, 1);
    }

    close () {
        this.ngbModal.close(this.changesMade);
    }
}
