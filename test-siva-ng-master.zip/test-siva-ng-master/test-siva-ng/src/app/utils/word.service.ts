import {Injectable} from "@angular/core";
// import * as officegen from 'officegen';
@Injectable()
export class WordService {
    public example () {
        // let docx = officegen('docx');
    }
}