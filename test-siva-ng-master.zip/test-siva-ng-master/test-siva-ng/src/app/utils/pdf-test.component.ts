import {Component, OnInit, ViewChild} from "@angular/core";
// import * as jsPDF from 'jspdf';
import * as htmlDocx from 'html-docx-js/dist/html-docx.js';
import * as FileSaver from 'file-saver';
// import * as html2pdf from "assets/scripts/html2pdf-orig.js"
// import * as html2canvas from "html2canvas/dist/html2canvas"
// import * as html2canvas from "assets/scripts/html2canvas.js"
@Component({
    selector: 'pdf-test',
    template: `
        <div id="pdf" #content class="pdf-container" style="padding: 10px; width: 90%; height:300px; overflow-y: scroll; background:white;">
            <!-- <div  style="position:absolute;"> -->
            <img src="/assets/images/mds.png" width="50%;"/>
                <br>
                <h2> Evidence Based Functional Evaluation Report</h2>
            <!-- <div style='position: absolute'> -->
            <div style="border:.1em solid gray;"><h2>Patient Information</h2>
                <!-- <p><span>Patient Name:</span><input type="text" id="patientNameO" value=/></p> -->

                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
            </div>
            <hr>
            <h2 style="margin-left:1.5em;font-size:.8em;">Diagnosis</h2>
            <!-- <table class='diagnosis'> -->
            <table class='CSSTableGenerator' id="diagnosis" style="width:85%;margin-bottom:1em;">
                <tr><!-- use angular ng-repeat diagDesc in diagDescs -->
                    <td id="diagDesc">Description</td>
                    <td id="diagIcd">ICD Code</td>
                </tr>
                <tr>
                    <td id="diagDesc1">Branchial Neuritis NOS</td>
                    <td id="diagIcd1">723.4</td>
                </tr>
                <tr>
                    <td id="diagDesc2">Somatic Dysfunction Cervical Region</td>
                    <td id="diagIcd2">739.1</td>
                </tr>
                <tr>
                    <td id="diagDesc3">Spasm of Muscle</td>
                    <td id="diagIcd3">728.85</td>
                </tr>
            </table>
            <hr style="width:95%">
            <h2 style="margin-left:1.5em;font-size:.8em;">Functional Abilities</h2>
            <table class='CSSTableGenerator' id="funcAbilities" style="width:75%;margin-bottom:1em;">
                <tr>
                    <td id="funcAbilitiesTesAct">Tested Activities</td>
                    <td id="funcAbilitiesImpDef">Impairment Deficit</td>
                    <td id="funcAbilitiesImpDefN">No Impairment Deficit</td>
                    <td id="funcAbilitiesNotPerf">Not Performed</td>
                    <td id="funcAbilitiesComm">Comments on Tested Results</td>
                </tr>
                <tr>
                    <td>Static Lift testing</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Muscle Testing</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Ranges of Motion Consistency Check</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Hand Grip Standard</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Pinch Grip Key/Tip/Palmer</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <img src="/assets/images/patient.png" style="border:.1em solid black; width:100px; height:100px; float:right;margin-right:10px;"/>
            </table>
            <hr style="width:95%">
            <h2 style="font-size:.8em;">RELIABILITY AND CONSISTENCY OF EFFORT</h2>
            <p style="margin-left:1.5em;font-size:1em;">The results of this evaluation suggest that {{pat.name}} gave a reliable effort, with {{taken.tests}} of {{total.tests}} consitency measures within expected limits.</p>

            <br>
            <p style="margin-left:1.5em;margin-right:.3em;font-size:1em;"><span style="margin-bottom:.5em;">I Dr. {{lname.doc}} have read the report, interpreted the report, and made the appropriate treatment protocol changes, and I have reviewed this with the patient.</span></p>
            <br>
            <hr style="margin-left:10%;margin-bottom:1em;margin-top:1.5em;float:left;width:25%;">
            <hr style="margin-right:15%;margin-bottom:1em;margin-top:1.5em;float:right;width:25%;">

            <br>
            <br>
            <p><span style="float:left;margin-left:-22%;margin-top:-.3em;">Dr. {{doc.name}}</span>
                <span style="float:right;margin-right:-12%;margin-top:-.3em;">Date</span></p>
            <br>
            <br>
            <!-- page 2 -->
            <h3 class="page-break"></h3>

            <img src="/assets/images/mds.png" width="50%;">
            <h2 style="margin-left:1.5em;margin-top:1.5em;font-size:.8em;">Functional Ability Results Quick View:</h2>

            <table class='CSSTableGenerator' id="nioshLift" style="width:95%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2">NIOSH Lift Test Results</td>
                    <td colspan="2">Force Data</td>
                    <td colspan="3">Job Related Strength and Lifting Recommendations **</td>
                </tr>
                </thead>
                <tr><!-- 2nd heading -->
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>Avg Force</td>
                    <td>CV (%)</td>
                    <td></td>
                    <td></td>
                    <td>Occasional Lift (Table ST1)</td>
                </tr>
                <tr><!-- begin data -->
                    <td>Arm Lift</td>
                    <td>6/25/14</td>
                    <td>44.3 lb</td>
                    <td>5.9</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>22 lb (Medium)</td>
                </tr>
                <tr>
                    <td>High Near Lift</td>
                    <td>6/25/14</td>
                    <td>21.7 lb</td>
                    <td>4.3</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>11 lb (Light)</td>
                </tr>
            </table>
            <table class='CSSTableGenerator' id="muscleTesting" style="width:95%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2">Muscle Testing Results</td>
                    <td colspan="4">Force Data</td>
                    <td colspan="3">Weaker Side Comparison</td>
                </tr>
                </thead>
                <tr>
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>Left</td>
                    <td>CV (%)</td>
                    <td>Right</td>
                    <td>CV (%)</td>
                    <td>Weaker Side</td>
                    <td>Expected Force</td>
                    <td>Force Deficit</td>
                </tr>
                <tr> <!-- begin data -->
                    <td>Elbow Extension</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Elbow Flexion</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Shoulder Abduction</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Cervical Rotation</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                <tr>
                    <td>Cervical Lateral Flexion</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Cervical Extension</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Cervical Flexion</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Finger Flexion</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                <tr>
                    <td>Thumb Opposition</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
                <tr>
                    <td>Hip Flexion</td>
                    <td>6/25/14</td>
                    <td>20 lb</td>
                    <td>0.0</td>
                    <td>17.7</td>
                    <td>2.7</td>
                    <td>Right</td>
                    <td>20 lb</td>
                    <td>-11%</td>
                </tr>
            </table>
            <table class='CSSTableGenerator' id="romsTest" style="width:95%;height:80%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2" width="30%">Ranges of Motion Test Results</td>
                    <td colspan="2" width="30%">Range of Motion</td>
                    <td colspan="2" width="40%">Normative Data</td>
                </tr>
                </thead>
                <tr><!-- 2nd heading -->
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>ROM Value</td>
                    <td>Valid</td>
                    <td>Population Norm</td>
                    <td>Percent of Norm</td>
                </tr>

                <tr><!-- begin data -->
                    <td>Cervical Flexion</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
                <tr>
                    <td>Cervical Extensions</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
                <tr>
                    <td>Cervical Lateral Flexion - Left</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
                <tr>
                    <td>Cervical Lateral Flection - Right</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
                <tr>
                    <td>Cervical Rotation - Left</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                <tr>
                    <td>Cervical Rotation - Right</td>
                    <td>6/25/14</td>
                    <td>21.7 lb</td>
                    <td>4.3</td>
                    <td>n/a</td>
                    <td>11 lb (Light)</td>
                </tr>
                <tr>
                    <td>Lumbar Flexion</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
                <tr>
                    <td>Lumbar Extension</td>
                    <td>6/25/14</td>
                    <td>70 deg</td>
                    <td>Yes</td>
                    <td>60 deg</td>
                    <td>117%</td>
                </tr>
            </table>
            <hr>

            <p>** Donald B. Chaffin, Ph.D.; Gary D. Herrin, Ph.D.; W.Monroe Keyserling, M.S.; "Pre-Employment Strength Testing. An Updated Position", Journal of Occupational Medicine, Vol 20. No.6, June, 1978.</p>
            <p>{{pat.name}}</p>



            <br>
            <h3 class="page-break"></h3>
            <!-- page 3 -->
            <table class='CSSTableGenerator' id="handDynaTest" style="width:95%;height:80%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2" width="30%">Hand Dynamometer Test Results </td>
                    <td colspan="2" width="30%">Force Data</td>
                    <td colspan="3" width="40%">Normative Data</td>
                </tr>
                </thead>
                <tr><!-- 2nd heading -->
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>Avg Force</td>
                    <td>CV (%)</td>
                    <td>Population Norm</td>
                    <td>Standard Deviation</td>
                    <td>Comp to Norm</td>
                </tr>

                <tr><!-- begin data -->
                    <td>Position 1 - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 1 - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Standard - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>76.8 lb</td>
                    <td>+/- 20.3</td>
                    <td>high</td>
                </tr>
                <tr>
                    <td>Standard - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
                <tr>
                    <td>Position 2 - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 2 - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 3 - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 3 - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 4 - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 4 - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 5 - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
                <tr>
                    <td>Position 5 - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>n/a</td>
                    <td>n/a</td>
                    <td>n/a</td>
                </tr>
            </table>
            <table class='CSSTableGenerator' id="pinchGrip" style="width:95%;height:80%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2" width="30%">Pinch Grip Test Results</td>
                    <td colspan="2" width="30%">Force Data</td>
                    <td colspan="3" width="40%">Normative Data</td>
                </tr>
                </thead>
                <tr><!-- 2nd heading -->
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>Avg Force</td>
                    <td>CV (%)</td>
                    <td>Standard Deviation</td>
                    <td>Comp to Norm</td>
                </tr>

                <tr><!-- begin data -->
                    <td>Key -Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
                <tr>
                    <td>Key - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
                <tr>
                    <td>Tip - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
                <tr>
                    <td>Tip - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
                <tr>
                    <td>Palmar - Left</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                <tr>
                    <td>Palmar - Right</td>
                    <td>6/25/14</td>
                    <td>62 lb</td>
                    <td>4.6</td>
                    <td>89.7 lb</td>
                    <td>+/- 20.4</td>
                    <td>normal</td>
                </tr>
            </table>
            <table class='CSSTableGenerator' id="romsTest2" style="width:95%;height:80%;margin-bottom:1em;">
                <thead>
                <tr>
                    <td colspan="2" width="30%">Ranges of Motion Test Results</td>
                    <td colspan="2" width="30%">Range of Motion</td>
                    <td colspan="3" width="40%">Normative Data</td>
                </tr>
                </thead>
                <tr><!-- 2nd heading -->
                    <td>Demonstrated Activity</td>
                    <td>Date</td>
                    <td>Left</td>
                    <td>Right</td>
                    <td>Norm</td>
                    <td>Left % Norm</td>
                    <td>Right % Norm</td>
                </tr>

                <tr><!-- begin data -->
                    <td>Elbow Flexion</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                </tr>
                <tr>
                    <td>Elbow Extension</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                </tr>
                <tr>
                    <td>Wrist Palmar Flexion</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                </tr>
                <tr>
                    <td>Wrist Dorsal Flexion</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                </tr>
                <tr>
                    <td>Ankle Dorsi Flexion</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                <tr>
                    <td>Ankle Plantar Flexion</td>
                    <td>6/25/14</td>
                    <td>153 deg</td>
                    <td>146 deg</td>
                    <td>140 deg</td>
                    <td>109%</td>
                    <td>104%</td>
                </tr>
            </table>
            <br>
            <hr>
            <p class="patient">{{pat.name}}</p>
            <br>
            <h3 class="page-break"></h3>
            <!-- <p>Page 4</p> -->
            <h2 style="border:2px solid black;">5th Edition Impairment Rating Report: 6/25/2014</h2>
            <p>The results of this functional evaluation show that {{pat.name}} has the following impairment levels. The impairments are broken down by whole person and body region.</p>
            <table class='CSSTableGenerator' id="impairmentSummary" style="width:85%;margin-bottom:1em;margin-top:2em;">
                <!-- <tbody> -->
                <caption>Impairment Summary</caption>
                <tr>
                    <td>Location of Impairment</td>
                    <td>Impairment % (at location)</td>
                </tr>
                <tr>
                    <td>Whole Person</td>
                    <td>10</td>
                </tr>
                <tr>
                    <td>Right Arm</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>Right Hand</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Right Wrist</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>Left Arm</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Left Hand</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Spine</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>Cervical</td>
                    <td>6</td>
                </tr>
            </table>
            <br>
            <hr>
            <p>{{pat.name}}</p>
            <br>
            <h3 class="page-break"></h3>
            <!-- <p>Page 5</p> -->
            <h2 style="border:2px solid black;">5th Edition Impairment Rating Report: 6/25/2014</h2>

            <p><img src="/assets/images/bodyPic.png" style="float:left; margin-left:10px;height:250px;border: 1px solid black;">
                <img src="/assets/images/spinePic.png" style="margin-left:55px;height:250px;border: 1px solid black;"></p>
            <br>
            <p style="text-align:center;">Whole Person Impairment Value = 10%</p>
            <table class='CSSTableGenerator' id="impairmentSummary" style="width:85%;margin-bottom:1em;margin-top:2em;">
                <!-- <tbody> -->
                <caption>Impairment Summary</caption>
                <tr>
                    <td>Location of Impairment</td>
                    <td>Impairment % (at location)</td>
                </tr>
                <tr>
                    <td>Whole Person</td>
                    <td>10</td>
                </tr>
                <tr>
                    <td>Right Arm</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>Right Hand</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Right Wrist</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>Left Arm</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Left Hand</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>Spine</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>Cervical</td>
                    <td>6</td>
                </tr>
            </table>
            <br>
            <hr>
            <p>{{pat.name}}</p>
            <br>

            <h3 class="page-break"></h3>
            <!-- page 6 -->
            <h2 style="text-decoration:underline;margin:2em 0 2em 0;">Automated 5th Edition Impairment Calculation Summary</h2>
            <h2>Spine Impairment</h2>
            <hr>
            <h4>Cervical Region: 6% - (combine multiple impairments)</h4>
            <h5>Abnormal Motion: 0% - (add multiple impairments)</h5>
            <h6>Maximum Flexion measured was 70, yielding an impairment of 0%</h6>
            <h6>Maximum Extension measured was 51, yielding an impairment of 0%</h6>
            <h6>Maximum Left Lateral Flexion measured was 48, yielding an impairment of 0%</h6>
            <h6>Maximum Right Lateral Flexion measured was 38, yielding an impairment of 0%</h6>
            <h6>Maximum Left Rotation measured was 81, yielding an impairment of 0%</h6>
            <h6>Maximum Right Rotation measured was 89, yielding an impairment of 0%</h6>
            <h6>Add 0% and 0% for a result of 0%</h6>
            <h6>Add 0% and 0% for a result of 0%</h6>
            <h6>Add 0% and 0% for a result of 0%</h6>
            <h6>Add 0% and 0% for a result of 0%</h6>
            <h6>Add 0% and 0% for a result of 0%</h6>
            <br>
            <h5>Other Impairment: 6% - (combine multiple impairments)</h5>
            <h6>Unoperated intervertebral disc or other soft tissue lesion, with medically documented injury and a minimum of six months of medically documented pain, recurrent muscle spasm or rigidity, associated with moderate to severe degenerative changes on structural tests; includes unoperated herniated nucleus pulposus with or without radiculopathy, effecting level(s) C5-C6, C6-C7, 2 levels 6% impairment</h6>
            <br>
            <h2>Left Arm Impairment</h2>
            <hr>
            <h4>Left Hand: 0% - (add multiple impairments)</h4>
            <h5>Muscle Function: 0% - (combine multiple impairments)</h5>
            <h6>Loss of Grip Strength - Grip Strength of 46.23 Kg for a Strength Loss Index of -1% when compared to the AMA norms for the minor hand of other Unrated workers of the same sex, for a 0% impairment</h6>
            <h6>Loss of Pinch Strength - Pinch Strength of 11.07 Kg for a Strength Loss Index of -48% when compared to the AMA norms for the minor hand of other Unrated workers of the same sex, for a 0% impairment</h6>
            <h6>Combine 0% and 0% for a result of 0%</h6>
            <br>
            <h5>Left Arm: 0% - (combine multiple impairments)</h5>
            <h6>Left Hand: 0%, which translates to a 0% impairment at this location</h6>
            <br>
            <h3 class="page-break"></h3>
            <h2>Right Arm Impairment</h2>
            <hr>
            <h4>Right Wrist: 1% - (combine multiple impairments)</h4>
            <h5>Nerve Disorder: 5% - (combine multiple impairments)</h5>
            <h6>Median (below midforearm): 13% Motor Deficit (Grade 4), 1% impairment</h6>
            <br>
            <h4>Right Hand: 0% - (add multiple impairments)</h4>
            <h5>Muscle Function: 0% - (combine multiple impairments)</h5>
            <h6>Loss of Grip Strength - Grip Strength of 45.5 Kg for a Strength Loss Index of -1% when compared to the AMA norms for the major hand of other Unrated workers of the same sex, for a 0% impairment</h6>
            <h6>Loss of Pinch Strength - Pinch Strength of 11.53 Kg for a Strength Loss Index of -54% when compared to the AMA norms for the major hand of other Unrated workers of the same sex, for a 0% impairment</h6>
            <h6>Combine 0% and 0% for a result of 0%</h6>
            <br>

            <h4>Right Arm: 6% - (combine multiple impairments)</h4>
            <h5>Nerve Disorder: 5% - (combine multiple impairments)</h5>
            <h6>Musculocutaneous: 20% Motor Deficit (Grade 4), 5% impairment</h6>
            <h5>Right Wrist: 1%</h5>
            <h5>Right Hand: 0%, which translates to a 0% impairment at this location</h5>
            <h5>Combine 5% and 1% for a result of 6%</h5>
            <br>
            <h2>Whole Person Impairment</h2>
            <hr>
            <h4>Whole Person: 10% - (combine multiple impairments)</h4>
            <h5>Spine: 6%</h5>
            <h5>Left Arm: 0%, which translates to a 0% whole person impairment</h5>
            <h5>Right Arm: 6%, which translates to a 4% whole person impairment</h5>
            <h5>Combine 4% and 6% for a result of 10%</h5>
            <br>

        </div>
        <button (click)="printContent()">
             PDF
        </button>
    `,
    styles: [`

        html {
            font: 10px/1 Verdana, sans-serif;
            /*background-color: blue;*/
            /*color: black;*/
        }

        body {
            /*margin: 1em;
            border: .1em solid black;
            padding: 0;
            width: 58em;
            background-color: white;*/
        }
        .pdf-container {
            margin: .5em 1.1em .5em 1.1em;
            /*border: .1em solid black;*/
            /*padding: 0;*/
            width: 57.5em;
            /*background-color: white;*/
        }
        .page-break {
            page-break-before: always;
        }
        dl {
            margin: 0;
            border: 0;
            padding: .5em;

        }

        dt {
            background-color: rgb(204, 0, 0);
            margin: 0;
            padding: 1em;
            width: 10.638%; /* refers to parent element's width of 47em. = 5em or 50px */
            height: 28em;
            border: .5em solid black;
            float: left;
        }

        dd {
            float: right;
            margin: 0 0 0 1em;
            border: 1em solid black;
            padding: 1em;
            width: 34em;
            height: 27em;
        }

        ul {
            margin: 0;
            border: 0;
            padding: 0;
        }

        li {
            display: block; /* i.e., suppress marker */
            /*color: black;*/
            height: 9em;
            width: 5em;
            margin: 0;
            border: .5em solid black;
            padding: 1em;
            float: left;
            background-color: #FC0;
        }

        #bar {
            /*background-color: black;*/
            color: white;
            width: 41.17%; /* = 14em */
            border: 0;
            margin: 0 1em;
        }

        #baz {
            margin: 1em 0;
            border: 0;
            padding: 1em;
            width: 10em;
            height: 10em;
            /*background-color: black;*/
            color: white;
        }

        form {
            margin: 0;
            display: inline;
        }

        p {
            margin: 0;
        }

        form p {
            line-height: 1.9;
        }

        blockquote {
            margin: 1em 1em 1em 2em;
            border-width: 1em 1.5em 2em .5em;
            border-style: solid;
            border-color: black;
            padding: 1em 0;
            width: 5em;
            height: 9em;
            float: left;
            background-color: #FC0;
            /*color: black;*/
        }

        address {
            font-style: normal;
        }

        h1 {
            /*background-color: black;*/
            /*color: black;*/
            /*float: left;*/
            margin: 1em 0;
            border: 0;
            padding: 1em;
            width: 10em;
            height: 10em;
            font-weight: normal;
            font-size: 1em;
        }

        h2 {
            font-color:black;
        }
        /*h3 {

        }*/

        h4 {
            font-size: 1em;
            font-weight: bold;
        }

        h5 {
            font-size: .8em;
            font-style: italic;
            margin-left: 10px;
            margin-top: 10px;
            text-decoration: underline;
        }

        h6 {
            font-size: .8em;
            margin-left: 20px;
            margin-bottom: -.5em;
            line-height: 1em;
        }
        table {
            margin-bottom: 1em;
        }

        table td {
            padding: 3px;
        }

        .table1 {
            border: 1px solid red;
        }

        .diagnosis,.diagnosis td {
            border: 1px solid silver;
            border-collapse: collapse;
        }

        .diagnosis td:first-child {
            background-color: lightblue;
        }

        .CSSTableGenerator {
            margin: 0px;
            padding: 0px;
            width: 100%;
            box-shadow: 10px 10px 5px #888888;
            border: 1px solid #000000;
            -moz-border-radius-bottomleft: 0px;
            -webkit-border-bottom-left-radius: 0px;
            border-bottom-left-radius: 0px;
            -moz-border-radius-bottomright: 0px;
            -webkit-border-bottom-right-radius: 0px;
            border-bottom-right-radius: 0px;
            -moz-border-radius-topright: 0px;
            -webkit-border-top-right-radius: 0px;
            border-top-right-radius: 0px;
            -moz-border-radius-topleft: 0px;
            -webkit-border-top-left-radius: 0px;
            border-top-left-radius: 0px;
        }

        .CSSTableGenerator table {
            border-collapse: collapse;
            border-spacing: 0;
            width: 100%;
            height: 100%;
            margin: 0px;
            padding: 0px;
        }

        .CSSTableGenerator tr:last-child td:last-child {
            -moz-border-radius-bottomright: 0px;
            -webkit-border-bottom-right-radius: 0px;
            border-bottom-right-radius: 0px;
        }

        .CSSTableGenerator table tr:first-child td:first-child {
            -moz-border-radius-topleft: 0px;
            -webkit-border-top-left-radius: 0px;
            border-top-left-radius: 0px;
        }

        .CSSTableGenerator table tr:first-child td:last-child {
            -moz-border-radius-topright: 0px;
            -webkit-border-top-right-radius: 0px;
            border-top-right-radius: 0px;
        }

        .CSSTableGenerator tr:last-child td:first-child {
            -moz-border-radius-bottomleft: 0px;
            -webkit-border-bottom-left-radius: 0px;
            border-bottom-left-radius: 0px;
        }

        .CSSTableGenerator tr:hover td {

        }

        .CSSTableGenerator tr:nth-child(odd) {
            background-color: #ffaa56;
        }

        .CSSTableGenerator tr:nth-child(even) {
            background-color: #ffffff;
        }

        .CSSTableGenerator td {
            vertical-align: middle;
            border: 1px solid #000;
            border-width: 0px 1px 1px 0px;
            text-align: left;
            padding: 3px;
            font-size: 8px;
            font-family: Arial;
            font-weight: normal;
            color: black;
        }

        .CSSTableGenerator tr:last-child td {
            border-width: 0px 1px 0px 0px;
        }

        .CSSTableGenerator tr td:last-child {
            border-width: 0px 0px 1px 0px;
        }

        .CSSTableGenerator tr:last-child td:last-child {
            border-width: 0px 0px 0px 0px;
        }

        .CSSTableGenerator tr:first-child td {
            background: -o-linear-gradient(bottom, #ff7f00 5%, #bf5f00 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ff7f00), color-stop(1, #bf5f00));
            background: -moz-linear-gradient(center top, #ff7f00 5%, #bf5f00 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ff7f00", endColorstr="#bf5f00");
            background: -o-linear-gradient(top, #ff7f00, bf5f00);
            background-color: #ff7f00;
            border: 0px solid #000000;
            text-align: center;
            border-width: 0px 0px 1px 1px;
            font-size: 10px;
            font-family: Arial;
            font-weight: bold;
            color: black;
        }

        .CSSTableGenerator tr:first-child:hover td {
            background: -o-linear-gradient(bottom, #ff7f00 5%, #bf5f00 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ff7f00), color-stop(1, #bf5f00));
            background: -moz-linear-gradient(center top, #ff7f00 5%, #bf5f00 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#ff7f00", endColorstr="#bf5f00");
            background: -o-linear-gradient(top, #ff7f00, bf5f00);
            background-color: #ff7f00;
        }

        .CSSTableGenerator tr:first-child td:first-child {
            border-width: 0px 0px 1px 0px;
        }

        .CSSTableGenerator tr:first-child td:last-child {
            border-width: 0px 0px 1px 1px;
        }
    `]
})
export class PdfTestComponent implements OnInit {
    @ViewChild('content') content: any;
    pat = {
        name: 'Example Name'
    }
    taken = {
        tests: 5
    };
    total = {
        tests: 6
    }
    lname = {
        doc: 'Dr. Fumbles'
    }
    doc = {
        name: 'Dr. Filler'
    }

    ngOnInit () {
        // (<any>window).html2pdf = html2pdf;
        // ((w) => {
        //    w.html2pdf = html2pdf;
        //
        // })(window)
        // window.html2pdf = html2pdf;
    }

    printContent () {
        console.log('Generated Content', this.content);


        // let pdf = new jsPDF();
        // console.log('function', jsPDF, 'instance', pdf);
        // pdf.canvas.height = 72 * 11;
        // pdf.canvas.width = 72 * 8.5;
        // let source = this.content.nativeElement.innerHTML;
        //
        // console.log('html2canvas -- ', html2canvas);
        //
        // debugger;
        // html2pdf(source, pdf, html2canvas, (pdf) => {
        //     console.log('aaaahhhh');
        //     let iframe = document.createElement('iframe');
        //     iframe.setAttribute('style','position:absolute;right:0; top:0; bottom:0; height:100%; width:50%;');
        //     document.body.appendChild(iframe);
        //     iframe.src = pdf.output('datauristring');
        //     // FileSaver.saveAs(pdf.output('blob'),"report.pdf");
        // });

        // pdf.fromHTML(source);

        // FileSaver.saveAs(pdf.output('blob'),"report.pdf");
    }
}
