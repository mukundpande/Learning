import {Component} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">An error occurred.</h4>
            <button type="button" class="close" aria-label="Close" (click)="close()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            {{ error }}
            <ul *ngIf="reasons">
                <li *ngFor="let reason of reasons">{{ reason }}</li>
            </ul>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="close()">OK</button>
        </div>
    `
})
export class ErrorDisplayModalComponent {
    error;
    reasons;

    constructor(private activeModal: NgbActiveModal){}

    setError(msg) {
        this.error = msg;
    }

    setReasons(list) {
        this.reasons = list;
    }

    close(){
        this.activeModal.close(true);
    }
}