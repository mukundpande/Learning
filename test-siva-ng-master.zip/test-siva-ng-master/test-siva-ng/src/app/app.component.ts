import {Component, OnInit} from '@angular/core';
import {EventEmitter, Input, Output } from '@angular/core';
import {Router} from "@angular/router";
import {MdDialog,MdDialogRef,MdDialogConfig} from '@angular/material';
import {LoginDialogComponent} from "./login-dialog/login-dialog.component";
import {SearchpatientComponent} from "./searchpatient/searchpatient.component";
import {FooterContextService} from "./services/footer-context.service";
import {PouchDBService} from "./services/pouchdb.service";
import {PatientService} from "./patient/patient.service";
import {ProtocolService} from "./protocol/protocol.service";
import {FtueService} from "./services/ftue.service";
import {WpiService} from "./services/wpi.service";
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Patient } from './patient/patient.model';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/do';
import { User } from './admin/user.model';



@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
       loggedIn:boolean =false;
       firstPatientToBePopulated:String='';
        firstProtocolToBePopulated:String='';

       patientTobeSelected:String='';
       selectedIdTobePopulated:String='';
        patientsList: any = {};

        title = 'MDS';

        protocols = [];
        testsUnderProtocol = [];
        tests = [];

        patient: any = null;
        patients: any;
        patientsByDate: any = [];
        totalProtocols: any = [];
        storageKey='loggedInUserData';

        results: Object;
        searchTerm$ = new Subject<string>();

   public constructor(
       private router: Router,
       private footerContext: FooterContextService,
       private pouchService: PouchDBService,
       private protocolService: ProtocolService,
       private ftueService: FtueService,
       private wpiService: WpiService,
       private patientService: PatientService,
       public dialog: MdDialog
   ) {
    
    }

   ngOnInit () {
     let userLoggedInData=localStorage.getItem('loggedInUserData');
     let selectedPatient=null;

    if(userLoggedInData===null){
       this.openDialog();
    }else{
      this.loggedIn=true;
    }
     this.getPatientsForDropDown();
     this.getProtocolsForDropDown();
     require('events').EventEmitter.prototype._maxListeners = 1000;
     console.log('-- DONE INITIATING THE MAIN APP COMPONENT');
   }

   successfulLoginHandler(loggedIn:boolean,user:User)
   {
     this.loggedIn = loggedIn;
     let loggedInUserData={
       logIn:this.loggedIn,
       user:user
     }
     this.rememberCurrentLoggedInUser(loggedInUserData);
   }
   rememberCurrentLoggedInUser (loggedInUserData) {
       localStorage.setItem('loggedInUserData', JSON.stringify(loggedInUserData));
   }

   onClickMe() {
        this.openDialogForSearchPatient();
   }

   openDialogForSearchPatient() {
       let dialogRef:MdDialogRef<SearchpatientComponent>;
       let config = new MdDialogConfig();
       config.disableClose = true;
       dialogRef = this.dialog.open(SearchpatientComponent,{
         height: '80%',
         width: '30%',
         panelClass: 'my-panel'
       });
       dialogRef.afterClosed().subscribe(patientId => {
        this. populateSelectedInDropdown(patientId);
         console.log(`Dialog closed: Successfully selected the Searched Patient`);
         //this.dialogResult = result;
        });
     }

   openDialog() {
       let dialogRef:MdDialogRef<LoginDialogComponent>;
       let config = new MdDialogConfig();
       config.disableClose = true;
       dialogRef = this.dialog.open(LoginDialogComponent,config);
       dialogRef.afterClosed().subscribe(user => {
        this.successfulLoginHandler(true,user);
         console.log(`Dialog closed:Successfully loggedin`);
         //this.dialogResult = result;
       });
     }

     logout () {
         this.logoutHandler();
   }
    logoutHandler(){
        localStorage.clear();
        this.loggedIn=false;
        window.location.reload();
        this.router.navigate(['/']);
    }

    populateSelectedInDropdown(patientId: String):void {
      if(patientId===undefined){
          this.router.navigate(['/']);
      }
        this.firstPatientToBePopulated=patientId;
        this.onSelectChangeName(patientId);
    }

      getPatientsForDropDown(){
        this.patientService.getPatientsForDropDown().subscribe(patients => {
        this.patients = patients;
        localStorage.setItem('allPatients', JSON.stringify(this.patients));
        this.firstPatientToBePopulated=this.patients[0]._id;
        this.selectedIdTobePopulated=this.patients[0]._id;
        console.log(this.patients );
       });
       }

       getProtocolsForDropDown(){
           this.protocolService.getAllProtocols().subscribe(protocols => {
             this.totalProtocols = protocols;
            // this.firstProtocolToBePopulated=this.totalProtocols[0]._id;
             console.log(this.totalProtocols );
          });
        }

    onSelectChangeName(patientId) {
      if(patientId===undefined){
          this.router.navigate(['/']);
      }
      console.log(patientId);
       this.firstPatientToBePopulated=patientId;
       this.selectedIdTobePopulated=patientId;
       this.router.navigate(['/patient/'+patientId]);
    }

    onSelectChangeProtocol(protocolId) {
        let protocolsList=this.totalProtocols;
        let lngth=protocolsList.length;
        for (let i = 0; i <lngth ; i++) {
            if(protocolId===protocolsList[i]._id){
                this.testsUnderProtocol=protocolsList[i].tests;
            }
      }
}

    onSelectChangeProtocolTest(protocol,testName) {
      alert(protocol+'  '+testName);
    }

    onSelectChangeNameDropdown(patientName) {
      if(patientName===undefined){
          this.router.navigate(['/']);
      }
      console.log(patientName);
    //  this.refresh(patientId) ;
       this.router.navigate(['/patient'+patientName+'_true']);
    }

    onSelectChangeDateDropdown(patientName) {
      if(patientName===undefined){
          this.router.navigate(['/']);
      }
      console.log(patientName);
    //  this.refresh(patientId) ;
       this.router.navigate(['/patient/'+patientName+'_true']);
    }




    selectSearchedRecord(patientId) {
      console.log(patientId);
    //  this.refresh(patientId) ;
       this.firstPatientToBePopulated=patientId;
       this.searchTerm$=null;
       this.router.navigate(['/patient/'+patientId]);
    }

    openConnection () {

    }

    getFooterContext() {
        return this.footerContext;
    }

    getPouchService () {
        return this.pouchService;
    }


        menuItems = [
            {
                name: 'Test',
                icon: 'bar-chart',
                click: () => {
                    /* if (!this.footerContext.patient) {
                        alert('Please select a patient.');
                        return false;
                    }

                    if (!this.footerContext.test) {
                       alert('Please select a protocol and test to start.');
                       return false;
                    }*/
                    this.router.navigate(['/test']);
                }
            },
            {
                name: 'Review', icon: 'archive', click: () => {
                  /*  if (!this.footerContext.patient) {
                        alert('Please select a patient.');
                        return false;
                    } */
                    this.router.navigate(['/review']);
                }
            },
            {
                name: 'Report',
                icon: 'files-o',
                click: () => {
                    /*if (!this.footerContext.patient) {
                        alert('Please select a patient.');
                        return false;
                    }*/
                    this.router.navigate(['/report']);
                }
            },
            { name: 'Utilities', icon: 'wrench', disabled: true },
            this.footerContext.retestMode ? {name: 'Retest', icon: 'question', yellow: true, click: () => { this.footerContext.retest(); }} : { name: 'Help', icon: 'question', disabled: true }
        ];

}
