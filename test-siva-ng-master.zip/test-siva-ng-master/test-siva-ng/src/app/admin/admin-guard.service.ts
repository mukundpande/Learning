import { Injectable } from '@angular/core';
import {
    CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';
import {PouchDBService} from "../services/pouchdb.service";

@Injectable()
export class AdminGuard implements CanActivate {
    constructor(private pouchService: PouchDBService,
                private router: Router) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        let url: string = state.url;
        return this.checkLogin(url);
    }

    checkLogin(url: string): boolean {
        if (this.pouchService.currentUser && this.pouchService.hasRole('_admin')) {
            return true;
        }

        console.log("Don't even warn, just boot.");

        // Store the attempted URL for redirecting
        // this.authService.redirectUrl = url;
        // this.loginService.open('Admin privileges required.');
        // Navigate to the login page with extras
        this.router.navigate(['/']);
        return false;
    }
}
