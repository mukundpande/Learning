export class User {
  _id: String;
  name: String;
  pass: String;
  roles: String;

  //usertype: String;
  //firstname: String;
  //lastname: String;
  //hash: String,
  //salt: String
}
