import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
@Component({
    templateUrl: './admin.component.html',
})
export class AdminComponent { }
