import {Component} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as Papa from 'papaparse/papaparse.min.js';
@Component({
    templateUrl: './rm-norms.component.html',
})
export class RmNormsComponent {
    items;
    constructor (private pouchService: PouchDBService) {}
    ngOnInit () {
        this.pouchService.get('ARC_norms_RM').then(doc => {
            console.log('GOT DOCUMENT', doc);
            this.items = doc.items;
        });
    }

    newItem () {
        this.items.push({ TastName: '', Norm: 0 });
    }

    removeItem (i) {
        this.items.splice(i,1);
    }

    saveItems () {
        this.pouchService.put('ARC_norms_RM', {
            items: this.items
        }).then(doc => {
            alert('Norms have been updated!');
        })
    }
}
