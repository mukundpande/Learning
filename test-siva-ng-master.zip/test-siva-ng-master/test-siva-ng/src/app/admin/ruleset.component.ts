import {Component} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as Papa from 'papaparse/papaparse.min.js';
@Component({
  templateUrl: './ruleset.component.html',
})
export class RulesetComponent {
    private dbs;
    documentID;
    constructor (private pouchService: PouchDBService) {}
    ngOnInit () {
        this.pouchService.allDbs().then(dbs => {
            this.dbs = [];
            dbs.map(db => {
                this.dbs.push({
                    name: db
                });
            })
        });
    }
    getDbs () {
        return this.dbs;
    }
    readUpload($event) {
        console.log('reading upload', $event);

        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        Papa.parse(file, {
            complete: results => {

                let headers = results.data.shift();

                for (let i = 0; i < headers.length; i++)  {
                    headers[i] = headers[i].replace(/[.\s]+/gi, '');
                }

                //headers[0] = '_id'; // for pouchDB
                let items = [];
                for (let i = 0; i < results.data.length; i++) {
                    let json: any = {};

                    // skip bad column counts
                    if (results.data[i].length !== headers.length) { continue; }

                    for (let j = 0; j < results.data[i].length; j++) {
                        json[headers[j]] = results.data[i][j];
                    }

                    // json._id = this.idPrefix + json._id; // for pouchDB
                    console.log('PUSHING THIS OBJECT', json);
                    items.push(json);
                    // this.pouchService.put(json._id, json);
                }

                let json = {
                    _id: this.documentID,
                    items: items
                }

                console.log('UPLOADING THIS OBJECT', json);

                this.pouchService.putAll(json._id, json);

                console.log('headers', headers);

            }
        });
        //
        // let fileType = $event.target.parentElement.id;
        //
        // fr.onloadend = (end) => {
        //     let result = atob(fr.result.split('base64,')[1]);
        //     console.log('FINISHED', result);
        //
        //
        //
        //
        // };
        // // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        //
        // fr.readAsDataURL(file);
    }
}
