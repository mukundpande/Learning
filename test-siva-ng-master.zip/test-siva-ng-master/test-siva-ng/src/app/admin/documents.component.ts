import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as Papa from 'papaparse/papaparse.min.js';

@Component({
  templateUrl: './documents.component.html',
})
export class DocumentsComponent implements OnInit {
    documents = [];
    idPrefix = '';
    constructor(private pouchService: PouchDBService) { }

    ngOnInit () {
        this.initiateSearch();
    }

    initiateSearch(id = '') {
        let obj: any = {};

        if (id.length) {
            obj.startkey = id;
            obj.endkey = id + '\uFFFF';
        }

        console.log('searching alldocs', obj);

        this.pouchService.allDocs(obj).then(res => {
            this.documents = [];
            this.documents = res.rows;
            console.log('Got documents', obj, res);
        });
    }

    prefixChanged($event, idPrefix) {
        console.log('CHANGED', $event, idPrefix);

        this.initiateSearch(idPrefix);
    }

    deleteAll () {
        if (!confirm('Are you sure?')) {  return false; }

        console.log('removing documents', this.documents);

        for (let i = 0; i < this.documents.length; i++) {
            this.pouchService.get(this.documents[i].key).then(doc => this.pouchService.remove(doc))
            // this.pouchService.remove(this.documents[i].key);
        }
    }

    readUpload($event) {
        console.log('reading upload', $event);

        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        Papa.parse(file, {
            complete: results => {

                let headers = results.data.shift();

                for (let i = 0; i < headers.length; i++)  {
                    headers[i] = headers[i].replace(/[.\s]+/gi, '');
                }

                //headers[0] = '_id'; // for pouchDB
                let items = [];
                for (let i = 0; i < results.data.length; i++) {
                    let json: any = {};

                    // skip bad column counts
                    if (results.data[i].length !== headers.length) { continue; }

                    for (let j = 0; j < results.data[i].length; j++) {
                        json[headers[j]] = results.data[i][j];
                    }

                    // json._id = this.idPrefix + json._id; // for pouchDB
                    console.log('PUSHING THIS OBJECT', json);
                    items.push(json);
                    // this.pouchService.put(json._id, json);
                }

                let json = {
                    _id: this.idPrefix,
                    items: items
                }

                console.log('UPLOADING THIS OBJECT');

                this.pouchService.put(json._id, json);

                console.log('headers', headers);

            }
        });
        //
        // let fileType = $event.target.parentElement.id;
        //
        // fr.onloadend = (end) => {
        //     let result = atob(fr.result.split('base64,')[1]);
        //     console.log('FINISHED', result);
        //
        //
        //
        //
        // };
        // // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        //
        // fr.readAsDataURL(file);
    }

}
