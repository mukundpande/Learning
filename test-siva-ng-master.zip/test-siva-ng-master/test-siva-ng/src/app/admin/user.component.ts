import {Component, OnInit} from "@angular/core";
import {ActivatedRoute, Params} from "@angular/router";
import {AuthService} from "../admin/auth.service";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
@Component({
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
    user;

    roles=[
     {name: "USER"},
     {name: "ADMIN"}
    ];

    userForm = this.fb.group({
        name: '',
        pass: '',
        roles : [this.roles]
    });


    constructor (private pouchService: PouchDBService,private authService: AuthService, private route: ActivatedRoute, private fb:FormBuilder) {}

    ngOnInit () {
        this.route.params
            .switchMap((params: Params) => this.authService.getUser(params['id']))
            .subscribe(user =>  console.log('Loaded Document', this.user = user) );
        // this.pouchService.dbInfo();
    }

    updateValue($event, list, index) {
        console.log('update user role');
        list[index] = $event.target.value;
    }

    checkEnter($event, list, index) {
        if($event.keyCode === 13) {
            this.updateValue($event, list, index);
        }
    }

    addRole () {
        this.user.roles.push('');
    }

    removeRole (i) {
        this.user.roles.splice(i,1);
    }

    updateUser (user) {
        if(user.password && !user.password.length) {
            delete user.password;
        }

        let roles = [];
        console.log('Updating User Roles', this.user.roles);
        this.user.roles.map(role => {
            if (role.length) {
                roles.push(role);
            }
        })
        this.user.roles = roles;

        this.pouchService.updateUser(user).then(res => {
            alert('User updated.');
            console.log('res', res);
            this.user.rev = res.rev;
        }, err => {
            alert('Could not update user. Please try again later.');
        });
    }
}
