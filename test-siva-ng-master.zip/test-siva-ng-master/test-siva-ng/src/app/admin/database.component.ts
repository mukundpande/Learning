import {Component, OnInit} from "@angular/core";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {PouchDBService} from "../services/pouchdb.service";
@Component({
     templateUrl: './database.component.html',
})
export class DatabaseComponent implements OnInit {
    db;
    security;
    clone;
    cloning = false;

    constructor (private pouchService: PouchDBService, private route: ActivatedRoute, private router:Router) {}

    ngOnInit () {
        this.route.params
            .switchMap((params: Params) => this.pouchService.dbInfo(params['id']))
            .subscribe(db => {

                this.db = db;
                this.pouchService.getDBSecurity(this.db.db_name).then(sec => {
                    this.security = sec;

                    if(this.security.error) {
                        delete this.security.error;
                    }
                    if(this.security.reason) {
                        delete this.security.reason;
                    }

                    if(!this.security.admins) {
                        this.security.admins = {
                            names: [],
                            roles: []
                        };
                    }
                    if(!this.security.members) {
                        this.security.members = {
                            names: [],
                            roles: []
                        };
                    }
                    if(!this.security.admins.names) {
                        this.security.admins.names = [];
                    }
                    if(!this.security.admins.roles) {
                        this.security.admins.roles = [];
                    }
                    if(!this.security.members.names) {
                        this.security.members.names = [];
                    }
                    if(!this.security.members.roles) {
                        this.security.members.roles = [];
                    }

                    console.log('SECURITY SANITIZED', this.security);

                });

                console.log('Loaded Document', db);

            } );
        // this.pouchService.dbInfo();
    }

    updateSecurity (security) {
        return this.pouchService.updateSecurity(this.db.db_name, security).then(res => {
            alert('Security updated.');
        }, err => {
            console.error('Could not update because', err);
        });
    }

    updateValue($event, list, index) {
        console.log('UPDATING VALUE', $event, list, index);
        list[index] = $event.target.value;
    }
    checkEnter($event, list, index) {
        if($event.keyCode === 13) {
            this.updateValue($event, list, index);
        }
    }

    appendList(list){
        list.push('');
    }

    deleteFromList(list, i) {
        list.splice(i,1);
    }

    duplicateDatabase(db, clone) {
        console.log('copying database information', db, clone);
        this.cloning = true;
        this.pouchService.duplicateDatabase(db.db_name, clone).then(res => {
            this.cloning = false;
            alert('Finished duplicating database to ' +clone+ '.');
        });
    }

    deleteDatabase (db) {
        this.pouchService.deleteDatabase(db.db_name).then(res => {
            console.log('database destroyed', res);
            this.router.navigate(['/admin/all_dbs']);
        })
    }
}
