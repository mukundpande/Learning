import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AdminComponent} from "./admin.component";
import {AdminGuard} from "./admin-guard.service";
import {DocumentsComponent} from "./documents.component";
import {DocumentComponent} from "./document.component";
import {PatientsComponent} from "../patient/patients.component";
import {CsvComponent} from "../utils/csv.component";
import {ContactsComponent} from "../contacts/contacts.component";
import {MainReportEditorComponent} from "../reports/main-report-editor.component";
import {AllDbsComponent} from "./all-dbs.component";
import {DatabaseComponent} from "./database.component";
import {UsersComponent} from "./users.component";
import {UserComponent} from "./user.component";
import {RulesetComponent} from "./ruleset.component";
import {RmNormsComponent} from "./rm-norms.component";
import {IcdComponent} from "./icd.component";

const routes: Routes = [
    {
        path: 'admin',
        canActivate: [
            AdminGuard
        ],
        children: [
            { path: '', component: AdminComponent },
            { path: 'all_dbs', component: AllDbsComponent },
            { path: 'contacts', component: ContactsComponent },
            { path: 'csv', component: CsvComponent },
            { path: 'db/:id', component: DatabaseComponent },
            { path: 'documents', component: DocumentsComponent },
            { path: 'documents/:id', component: DocumentComponent },
            { path: 'icd', component: IcdComponent },
            { path: 'mainreport', component: MainReportEditorComponent },
            { path: 'patients', component: PatientsComponent },
            { path: 'reports', component: CsvComponent },
            { path: 'rmnorms', component: RmNormsComponent },
            { path: 'ruleset', component: RulesetComponent },
            { path: 'users', component: UsersComponent }

        ]
    }

];
@NgModule({
    imports: [ RouterModule.forChild(routes) ],
    exports: [ RouterModule ]
})
export class AdminRoutingModule {}
