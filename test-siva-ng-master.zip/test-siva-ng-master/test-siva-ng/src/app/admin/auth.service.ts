import {Injectable} from '@angular/core';
import { Http, Response,BrowserXhr } from '@angular/http';
import { User } from './user.model';

@Injectable()
export class AuthService {

    private LOGIN_SERVICE_URL = 'http://localhost:8080/api/login';

    private LOGOUT_SERVICE_URL = 'http://localhost:8080/api/logout';

    private USER_URL = 'http://localhost:8080/api/users/';
    
    constructor (private http: Http) {

    }

    login(user:User):Promise<void | User>{
        return this.http.post(this.LOGIN_SERVICE_URL, user)
               .toPromise()
               .then(response => response.json() as User)
               .catch(this.handleError);
    }

    logout(user:User):Promise<void | User>{
        return this.http.post(this.LOGOUT_SERVICE_URL,user)
               .toPromise()
               .then(response => response.json() as User)
               .catch(this.handleError);
    }

    addUser(user:User):Promise<void | User>{
        return this.http.post(this.USER_URL+'add', user)
               .toPromise()
               .then(response => response.json() as User)
               .catch(this.handleError);
    }

    getUsers ():Promise<void | User[]>{
        return this.http.get(this.USER_URL +'all')
               .toPromise()
               .then(response => response.json() as User[])
               .catch(this.handleError);
    }

    getUser (_id:String):Promise<void | User>{
        return this.http.get(this.USER_URL +_id)
               .toPromise()
               .then(response => response.json() as User)
               .catch(this.handleError);
    }

    deleteUser (_id:String):Promise<void | User>{
        return this.http.delete(this.USER_URL+'delete/'+_id)
               .toPromise()
               .then(response => response.json() as User)
               .catch(this.handleError);
    }



    private handleError (error: any) {
      let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
      console.error(errMsg); // log to console instead
    }
}
