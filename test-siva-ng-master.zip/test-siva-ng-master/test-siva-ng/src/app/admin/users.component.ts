import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
@Component({
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
    users;

    newUserName = '';
    newUserPass = '';

    userForm = this.fb.group({
        name: '',
        pass: ''
    });

    constructor (private pouchService: PouchDBService, private fb: FormBuilder) {}

    addUser (form) {
        console.log('saving this user');
        this.pouchService.addUser(form.name, form.pass).then(res => {
            console.log('user added', res);
            this.getUsers();
            this.userForm.reset({});
        }, err => {
            console.error('could not add user because', err);
        })

    }

    ngOnInit () {
        this.getUsers();
    }

    getUsers () {
        this.pouchService.getUsers().then(users => {
            console.log('[Admin/Users] Loading Users', users);
            this.users=users
        });
    }

    deleteUser(name) {
        if(!confirm('Really delete this user? This is NOT REVERSIBLE!')) {
            return;
        }

        this.pouchService.deleteUser(name).then(res => this.getUsers());
    }
}
