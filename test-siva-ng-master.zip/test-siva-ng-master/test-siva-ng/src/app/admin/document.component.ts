import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {ActivatedRoute, Params} from "@angular/router";

import 'rxjs/add/operator/switchMap';

@Component({
   templateUrl: './document.component.html',
})
export class DocumentComponent implements OnInit {
    document: any;
    config: any = {
        enableAdminModeSwitch: true
    }

    constructor(private pouchService: PouchDBService, private route: ActivatedRoute) { }
    ngOnInit () {
        this.route.params
            .switchMap((params: Params) => this.pouchService.get(params['id']))
            .subscribe(document =>  console.log('Loaded Document', this.document = document) );
    }



}
