import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
@Component({
  templateUrl: './all-dbs.component.html',
})
export class AllDbsComponent implements OnInit {
    private dbs;
    constructor (private pouchService: PouchDBService) {}
    ngOnInit () {
        this.pouchService.allDbs().then(dbs => {
            this.dbs = [];
            dbs.map(db => {
                this.dbs.push({
                    name: db
                });
            })

        });
    }
    getDbs () {
        return this.dbs;
    }
}
