import {NgModule} from "@angular/core";
import {AdminRoutingModule} from "./admin-routing.module";
import {AdminComponent} from "./admin.component";
import {DocumentsComponent} from "./documents.component";
import {UsersComponent} from "./users.component";
import {CommonModule} from "@angular/common";
import {NgxDatatableModule} from "@swimlane/ngx-datatable";

import {DocumentComponent} from "./document.component";
import {PatientsComponent} from "../patient/patients.component";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {CsvComponent} from "../utils/csv.component";
import {ContactsComponent} from "../contacts/contacts.component";
import {MainReportEditorComponent} from "../reports/main-report-editor.component";
import {FroalaEditorModule, FroalaViewModule} from "angular2-froala-wysiwyg";
import {AllDbsComponent} from "./all-dbs.component";
import {MdListModule} from '@angular/material';
import {DatabaseComponent} from "./database.component";
import {UserComponent} from "./user.component";
import {RulesetComponent} from "./ruleset.component";
import {RmNormsComponent} from "./rm-norms.component";
import {IcdComponent} from "./icd.component";

@NgModule({
    declarations: [
        AdminComponent,
        AllDbsComponent,
        ContactsComponent,
        CsvComponent,
        DatabaseComponent,
        DocumentComponent,
        DocumentsComponent,
        MainReportEditorComponent,
        IcdComponent,
        PatientsComponent,
        RmNormsComponent,
        RulesetComponent,
        UsersComponent,
        UserComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgxDatatableModule,
        
        MdListModule,
        FroalaEditorModule.forRoot(), FroalaViewModule.forRoot(),
        AdminRoutingModule
    ]
})
export class AdminModule {}
