import { Component, OnInit, Inject } from '@angular/core';
import {MD_DIALOG_DATA} from '@angular/material';
import {MdDialogRef} from '@angular/material';

import {MdDialogModule,MdDialog,MdDialogConfig} from '@angular/material';


import {Output,EventEmitter} from '@angular/core';
import {FormBuilder, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import {AuthService} from "../admin/auth.service";
import { User } from '../admin/user.model';

@Component({
  selector: 'app-login-dialog',
  templateUrl: './login-dialog.component.html',
  styleUrls: ['./login-dialog.component.css']
})
export class LoginDialogComponent implements OnInit {

  userr: any = {};

  public shortName: string

  attemptingLogin;
  dbs;
  selectedDB = null;

  loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });

  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private router: Router,
    public dialog: MdDialog,
    private dialogRef: MdDialogRef<LoginDialogComponent>

  ) { }

  getAuthService () {
      return this.authService;
  }

  ngOnInit () {

  }

   loginFormSubmit () {
      // this.attemptingLogin = true;
      // console.log('attempting to login');
      // let user = this.loginForm.value;
      //
      //  this.authService.login(user).then((user: User) => {
      //
      //         this.loginForm.reset();
      //         this.attemptingLogin = false;
      //       });
      let user = this.loginForm.value;
      console.log('user data'+ user);

      this.dialogRef.close(user);

      this.router.navigate(['/']);
  }


}
