import {NgModule} from "@angular/core";
import {ProtocolComponent} from "./protocol.component";
import {TestEditorModalComponent} from "../test/test-editor-modal.component";
import {CommonModule} from "@angular/common";
import {TestsComponent} from "../test/tests.component";
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {BrowserModule} from "@angular/platform-browser";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {HttpModule} from "@angular/http";
import {MdCheckboxModule, MdOptionModule, MdSelectModule} from "@angular/material";
import {EditorSt} from "./editor-st.component";
import {EditorRm} from "./editor-rm.component";
import {EditorHd} from "./editor-hd.component";
import {EditorCx} from "./editor-cx.component";
import {EditorEg} from "./editor-eg.component";
import {ProtocolRoutingModule} from "./protocol-routing.module";
import {ProtocolDirectoryComponent} from "./protocol-directory.component";
import {AppendProtocolComponent} from "./append-protocol.component";
import {AppendTestComponent} from "../test/append-test.component";
@NgModule({
    declarations: [
        AppendProtocolComponent,
        AppendTestComponent,
        EditorCx,
        EditorEg,
        EditorHd,
        EditorRm,
        EditorSt,
        ProtocolComponent,
        ProtocolDirectoryComponent,
        TestsComponent,
        TestEditorModalComponent
    ],
    entryComponents: [
        AppendProtocolComponent,
        AppendTestComponent,
        TestEditorModalComponent
    ],
    imports: [
        CommonModule,
        NgxDatatableModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        MdCheckboxModule,
        MdSelectModule,
        MdOptionModule,
        ProtocolRoutingModule
    ]
})
export class ProtocolModule {}
