import {Component, OnInit} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {FormBuilder} from "@angular/forms";
import {PouchDBService} from "../services/pouchdb.service";
import {ProtocolService} from "./protocol.service";
import {FooterContextService} from "../services/footer-context.service";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Select Protocol Name &hellip;</h4>
            <button type="button" class="close" aria-label="Close" (click)="cancel()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Name</label>
                <md-select [(ngModel)]="selectedProtocol" style="width:100%">
                    <md-option [value]="protocol" *ngFor="let protocol of testProtocols">{{ protocol.Name }}</md-option>
                </md-select>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="select()"> Save</button>
            <button type="submit" class="btn btn-danger" (click)="cancel()"> Cancel</button>
        </div>
    `
})
export class AppendProtocolComponent implements OnInit {
    selectedProtocol;

    testProtocols = [];
//getFooterContext().protocols
    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService,
        private protocolService: ProtocolService,
        private footerContext: FooterContextService
    ) { }

    ngOnInit () {
        var item={
          Name:'Protocol1'
        }
        this.testProtocols.push(item);
    }

    // getFooterContext () {
    //     return this.footerContext;
    // }

    select() {
        this.activeModal.close(this.selectedProtocol);
    }

    cancel() {
        this.activeModal.close(null);
    }
}
