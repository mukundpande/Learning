import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {ProtocolService} from "./protocol.service";
import {Router} from "@angular/router";
import {FooterContextService} from "../services/footer-context.service";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {TestEditorModalComponent} from "../test/test-editor-modal.component";
import {AppendProtocolComponent} from "../protocol/append-protocol.component";
import {AppendTestComponent} from "../test/append-test.component";
import { TreeModel, NodeEvent } from 'ng2-tree';

@Component({
    templateUrl: './protocol.component.html',
    styles: [`
        ul.top-list > li > button {
            width:48px;
        }
        .protocol-list-label {
            padding: 0 20px 0 0;
        }
        .protocol-index {
            padding: 2px 10px;
            background: #5cb3fd;
        }
        .half-width { width:50%; }
    `]
})
export class ProtocolComponent implements OnInit {
    index = 0;
    editMode = false;
    createMode = false;
    newProtocolName = '';
    protocols = [];
    protocol: any;

    constructor(
        private footerContext: FooterContextService,
        private modalService: NgbModal,
        private router: Router,
        private pouchService: PouchDBService,
        private protocolService: ProtocolService
    ) { }

    getPouchService () {
        return this.pouchService;
    }

    editProtocol (protocol) {
        this.protocolService.broadcastProtocolEdit(protocol.Name);
        // alert('editing protocol' + protocol.Name);
    }

    removeTestFromProtocol (protocol,testCodeTobeDeleted,testNameTobeDeleted) {

       let codes = protocol.TestCodes;
       let names = protocol.TestNames;
        let tests = protocol.tests;
       let length=names.length;
       for(let i = 0; i <length ; i++){
         if(codes[i]!==undefined && codes[i].toUpperCase()===testCodeTobeDeleted.toUpperCase()){
            codes.splice(testCodeTobeDeleted,1);
            names.splice(testNameTobeDeleted,1);
            tests.splice(testCodeTobeDeleted,1);
            break;
         }
       }
      protocol.TestCodes=[];
      protocol.TestCodes=(codes);

      protocol.TestNames=[];
      protocol.TestNames=(names);

      protocol.tests=[];
      protocol.tests=tests;

     protocol.NumTests=protocol.NumTests-1;

      let prcls=this.protocols;
      prcls.splice(protocol.Name,1);
      prcls.push(protocol);
      this.protocols=prcls;
      this.updateProtocol(protocol);
    }

    updateProtocol(protocol){
        this.protocolService.updateProtocol(protocol).then(res=>{
            console.log('Response from add protocol service' + res);
        }, err => {
            console.error('Failed to update protocols because:' + err);
        });
    }

    updateViewedProtocol(protocols) {
        console.log('loading protocols', protocols);
       var protocolsLength=protocols.length;
        for (let i = 0; i <protocolsLength ; i++) {
          var currentprotocol = protocols[i];
          //this.protocol = this.protocolService.populateTests(this.protocol);
          let codes =currentprotocol.TestCodes;
          let names = currentprotocol.TestNames;
          currentprotocol.tests = [];
          console.log('CODES', codes);
          console.log('NAMES', names);
          for (let i = 0; i < codes.length; i++) {
              currentprotocol.tests.push({ code: codes[i], name: names[i] });
          }
          console.log('updated results', currentprotocol);
          this.protocols.push(currentprotocol);
        }

    }

    loadAllProtocols(){
      this.protocolService.getAllProtocols().subscribe(protocols => {
      var prtcls = protocols;
      this.updateViewedProtocol(prtcls);
    },
    err => console.error('Failed to load Protocols', err)
    );
    }

    ngOnInit () {
        this.loadAllProtocols();

        // this.protocolService.promiseFormInfoLoaded().then( info => {
        //         this.protocols = info.protocols;
        //         console.log('Protocols loaded', this.protocols);
        //
                // for (let i = 0; i < this.protocols.length; i++) {
                //     if (this.footerContext.protocol && this.protocols[i].Name === this.footerContext.protocol.Name) {
                //         console.log('Index found for', this.footerContext.protocol);
                //         this.index = i;
                //         break;
                //     }
                // }
                //
                // this.updateViewedProtocol();
        //     },
        //     err => console.error('Failed to load Protocols', err)
        // );
        this.activateMainButtons();

        // this.footerContext;

        this.protocolService.getEditorObservable().subscribe(res => {

            this.protocolService.promiseFormInfoLoaded().then( info => {

                switch(res.type) {
                    case 'protocol':

                        // for (let i = 0; i < this.footerContext.protocols.length; i++) {
                        //     if (info.protocols[i].Name === res.name) {
                        //         console.log('LOADING EDITOR FOR TEST');
                        //         this.protocol = this.footerContext.protocol = this.footerContext.protocols[i];
                        //         this.footerContext.protocolChanged({});
                        //         this.activateEditMode();
                        //         // .setProtocol()
                        //     }
                        // }

                        // this.protocolService.getProtocolByName();
                        break;
                    case 'test':
                        this.editTest({code: res.code, name: res.name});
                        break;
                    default:
                        console.error('Could not find a matching type', res);
                        break;
                }
            })
        });
    }

    activateMainButtons () {
        this.createMode = false;
        this.editMode = false;
        this.footerContext.activateButtons([
            {
                label: 'New',
                click: () => {
                    let oldProtocol = this.footerContext.protocol;
                    this.footerContext.protocol = {};
                    this.createMode = true;
                    this.newProtocolName = '';

                    this.footerContext.activateButtons([{}, {
                        label: 'OK',
                        click: () => {
                            this.protocolService.addProtocol(this.newProtocolName).then(res=>{
                                console.log('Response from add protocol service' + res);
                                // this.footerContext.updateProtocols().then(res => {
                                //     this.index = this.footerContext.protocols.length - 1;
                                //     this.updateViewedProtocol();
                                //     this.footerContext.protocol = this.footerContext.protocols[this.index];
                                // });
                            }, err => {
                                console.error('Failed to update protocols because:' + err);
                            });
                            this.activateMainButtons();
                        }
                    }, {
                        label: 'Cancel',
                        click: () => {
                            this.createMode = false;
                            this.footerContext.protocol = oldProtocol;
                            this.activateMainButtons()
                        }
                    }]);
                }
            }, {
                label: 'Edit',
                click: () => {
                    this.activateEditMode ()
                }
            }, {
                label: 'Delete',
                click: () => {
                    if (!confirm('Really delete this protocol? This CANNOT BE REVERSED!')) {
                        return;
                    }

                    this.protocolService.dropProtocol(this.protocol.Name).then(() => {
                        this.footerContext.updateProtocols().then(res => {

                            console.log('PROP: ', res, this.footerContext.protocols);
                            this.index = this.footerContext.protocols.length - 1;
                            //this.updateViewedProtocol(this.protocol);
                            this.footerContext.protocol = this.footerContext.protocols[this.index];
                        });
                    })
                }
            }, {
                label: 'Quit',
                click: () => {
                    this.router.navigate(['/']);
                }
            }
        ]);
    }

    activateEditMode () {
        this.editMode = true;
        let tempProtocol = this.footerContext.protocol;

        this.footerContext.activateButtons([{},{
            label: 'OK',
            click: () => {
                this.editMode = false;

                this.protocolService.saveProtocol(this.protocol).then( res => {
                    console.log('PROTOCOL COMPONENT RECEIVED RESPONSE', res);
                    this.footerContext.updateProtocols();
                });

                this.activateMainButtons();
            }
        },{
            label: 'Cancel',
            click: () => {
                this.editMode = false;
                this.footerContext.protocol = tempProtocol;
                this.activateMainButtons()
            }
        },{}]);
    }

    editTests () {
        if(this.editMode || this.createMode) {
            return false;
        }
        this.router.navigate(['/tests']);
    }

    editTest (test) {
        const modalRef = this.modalService.open(TestEditorModalComponent, {'size':'lg'});
        modalRef.result.then(res => {
            console.log('Resulting Response', res);
        }, rej => {

        });
        modalRef.componentInstance.acceptTest(test);
    }
    openAppendProtocol () {

        const modalRef = this.modalService.open(AppendProtocolComponent, {'size':'lg'});
        modalRef.result.then(res => {
            console.log('Resulting Response', res);
            this.protocol.TestNames += res.Name + ';';
            this.protocol.TestCodes += 'PR';
        }, rej => {

        });
    }

    openAppendTest () {

        const modalRef = this.modalService.open(AppendTestComponent, {'size':'lg'});
        modalRef.result.then(res => {
            if(!res) {
                return;
            }

            console.log('Resulting Response', res);
            this.protocol.TestNames += res.test.TestName + ';';
            this.protocol.TestCodes += res.code.Code;
        }, rej => {

        });
    }


}
