export class Protocol {
  _id: String;
  Name: String;
  NumTests: Number;
  TestNames: string[];
  TestCodes: string[];
  tests: string[];
}
