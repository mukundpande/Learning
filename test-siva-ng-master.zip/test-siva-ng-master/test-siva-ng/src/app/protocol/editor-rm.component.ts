import {Component, Input, OnInit} from "@angular/core";
import {FormBuilder} from "@angular/forms";
@Component({
    selector: 'editor-rm',
    template: `
        <form [formGroup]="testForm">

            <div class="row">

                <div class="form-group col-2">
                    <label>Type</label>
                    <input type="text" class="form-control" [value]="test.Device" readonly />
                </div>
                <div class="form-group col-10">
                    <label>Test Name</label>
                    <input type="text" class="form-control" [value]="test.TestName" readonly />
                </div>

            </div>

            <div class="row">

                <div class="form-group col-4 trial-max-input">
                    <label >Trials / Max</label>
                    <input type="text" formControlName=".Trials" class="form-control " />
                    <input type="text" formControlName="MaxTrials" class="form-control " />
                </div>
                <div class="form-group col-5">
                    <label>ROM Measurement</label>
                    <md-checkbox formControlName="Dual" [value]="1">Dual</md-checkbox>
                    <md-checkbox formControlName="TwoWay" [value]="1">Two-Way</md-checkbox>
                </div>
                <div class="form-group col-3">
                    <label>Test Mode</label>
                    <md-select formControlName="TestMode">
                        <md-option *ngFor="let testMode of testModes" [value]="testMode.Mode">{{ testMode.Mode }}<span style="color:#888;"> | {{ testMode.Description}}</span></md-option>
                    </md-select>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-2">
                    <label>Units</label>
                    <input type="text" class="form-control" readonly="" value="Degrees" />
                </div>
                <div class="form-group col-4">
                    <label>Maximum Graph Value</label>
                    
                    <div class="row">
                        <div class="col-4">
                            <input type="text" class="form-control" formControlName="ScaleMax" />
                        </div>
                        <div class="col-8">
                            <md-checkbox formControlName="Autoscale" [value]="1">AutoScale</md-checkbox>
                        </div>
                    </div>

                </div>
                <div class="form-group col-2">
                    <label>Min. Deg:</label>
                    <input type="text" class="form-control" formControlName="MinRom" />

                </div>
                <div class="form-group col-4">
                    <label>Additional Information For Testing Graph &hellip;</label>

                    <label>Test Mode</label>
                    <md-select formControlName="GraphInfo">
                        <md-option *ngFor="let graphInfo of graphInfos" [value]="graphInfo.GICode">{{ graphInfo.GICode }}<span style="color:#888;"> | {{ graphInfo.GraphInfo}}</span></md-option>
                    </md-select>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-4">
                    <label>{{ this.testForm.value.OtherName }}</label>
                    <input type="text" formControlName="OtherInfo" class="form-control" />
                </div>
                <div class="form-group col-8">
                    <label>Additional Testing Options &hellip;</label>
                    <md-checkbox formControlName="HeartRate" [value]="1">Monitor Heart Rate</md-checkbox>
                    <md-checkbox formControlName="Audio" [value]="1">Use Primary/#2 for Single ROM</md-checkbox>
                    <md-checkbox formControlName="Distraction" [value]="true">Distraction</md-checkbox>
                </div>

            </div>

        </form>
    `,
    styles: [`
        .trial-max-input label {
            display:block;
            text-align:center
        }
        .trial-max-input input{
            width:49%;
            display:inline-block;
            margin:0;
        }
    `]
})
export class EditorRm implements OnInit {
    @Input() test;
    @Input() testModes;
    @Input() graphInfos;

    constructor (private fb:FormBuilder) {

    }

    ngOnInit () {
        console.log('Loading RM TEST with', this.test);

        let keys = ['HeartRate', 'Dual', 'TwoWay', 'Audio', 'AutoScale'];

        for (let i = 0; i < keys.length; i++) {
            this.test[keys[i]] = +this.test[keys[i]];
        }

        this.testForm.reset(this.test);
    }

    testForm = this.fb.group({
        '.Trials': [3],
        Audio: "1",
        Autoscale: "1",
        // Device: "RM",
        Distraction: false,
        Dual: "1",
        GraphInfo: "MN",
        HeartRate:  "0",
        MaxTrials: "6",
        MinRom: "1",
        OtherInfo: "",
        OtherName: "Position",
        ScaleMax: "75",
        Spare: "0",
        TestMode: "LA",
        // TestName: "Cervical Lateral Flexion",
        TwoWay: "0"
    });
}