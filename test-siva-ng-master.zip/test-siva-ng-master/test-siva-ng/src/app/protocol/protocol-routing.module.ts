import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {ProtocolComponent} from "./protocol.component";
import {TestsComponent} from "../test/tests.component";
const helpRoutes: Routes = [
    { path: 'protocol', component: ProtocolComponent },
    { path: 'tests', component: TestsComponent },
    //
    // {
    //     // canActivate: [ AdminGuard ],
    //     path: 'protocol',
    //     // component: UserListComponent,
    //     children: [
    //         { path: '',   component: ProtocolComponent }
    //     ]
    // },
    // {
    //     path: 'tests'
    //     children: [
    //         }
    //     ]
    // }
    // { path: 'user/:id', component: UserDetailComponent }
];
@NgModule({
    imports: [ RouterModule.forChild(helpRoutes) ],
    exports: [ RouterModule ]
})
export class ProtocolRoutingModule { }
