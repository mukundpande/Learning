import {Component, Input} from "@angular/core";
import {FormBuilder} from "@angular/forms";
@Component({
    selector: 'editor-hd',
    template: `
        <form [formGroup]="testForm">

            <div class="row">

                <div class="form-group col-2">
                    <label>Type</label>
                    <input type="text" class="form-control" />
                </div>
                <div class="form-group col-10">
                    <label>Test Name</label>
                    <input type="text" class="form-control" />
                </div>

            </div>

            <div class="row">

                <div class="form-group col-2">
                    <label>Trials</label>
                    <input type="text" class="form-control" />
                </div>
                <div class="form-group col-4">
                    <label>Trials</label>
                    <input type="text" class="form-control" />
                    <input type="text" class="form-control" />
                </div>
                <div class="form-group col-5">
                    <label>ROM Measurement</label>
                    <md-checkbox>Dual</md-checkbox>
                    <md-checkbox>Two-Way</md-checkbox>
                </div>
                <div class="form-group col-3">
                    <label>Test Mode</label>
                    <md-select>
                        <md-option></md-option>
                    </md-select>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-2">
                    <label>Units</label>

                </div>
                <div class="form-group col-2">
                    <label>Maximum Graph Value</label>

                </div>
                <div class="form-group col-2">
                    <label>Min. Deg:</label>

                </div>
                <div class="form-group col-2">
                    <label>Additional Information For Testing Graph &hellip;</label>

                </div>

            </div>

            <div class="row">

                <div class="form-group col-4">
                    <label>Position</label>

                </div>
                <div class="form-group col-8">
                    <label>Additional Testing Options &hellip;</label>

                    <md-checkbox formControlName="Distraction" [value]="true">Distraction</md-checkbox>
                </div>

            </div>

        </form>
    `
})
export class EditorHd {
    @Input() test;
    @Input() testModes;
    @Input() graphInfos;

    constructor (private fb:FormBuilder) {

    }

    ngOnInit () {
        console.log('Loading RM TEST with', this.test);

        let keys = ['HeartRate', 'Dual', 'TwoWay', 'Audio', 'AutoScale'];

        for (let i = 0; i < keys.length; i++) {
            this.test[keys[i]] = +this.test[keys[i]];
        }

        this.testForm.reset(this.test);
    }

    testForm = this.fb.group({
        '.Trials': [3],
        Audio: "1",
        Autoscale: "1",
        // Device: "RM",
        Distraction: false,
        Dual: "1",
        GraphInfo: "MN",
        HeartRate:  "0",
        MaxTrials: "6",
        MinRom: "1",
        OtherInfo: "",
        OtherName: "Position",
        ScaleMax: "75",
        Spare: "0",
        TestMode: "LA",
        // TestName: "Cervical Lateral Flexion",
        TwoWay: "0"
    });
}