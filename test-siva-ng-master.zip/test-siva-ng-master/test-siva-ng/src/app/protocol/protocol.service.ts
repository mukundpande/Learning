import {Injectable} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {Observable} from "rxjs/Observable";
import {FooterContextService} from "../services/footer-context.service";
import { Protocol } from './protocol.model';
import { Http, Response,BrowserXhr } from '@angular/http';

@Injectable()
export class ProtocolService {

    private PROTOCOLS_API = 'http://localhost:8080/api/protocols/';

    private sources: any = {
        'AirsTest': {
            devices: ['AI']
        },
        'DexTest': {
            devices: ['DX']
        },
        'DynamicTest': {
            devices: ['SP','LC']
        },
        'NadepTest': {
            devices: ['NA','MT','PE']
        },
        'RomTest': {
            devices: ['EG','RM']
        },
        'StaticTest': {
            devices: ['CX','HD','PG','ST']
        },
    }

    private info_sources = {
        'ARC_PROTOCOL_TestModes': 'testModes',
        'ARC_PROTOCOL_TestTypes': 'testTypes',
        'ARC_PROTOCOL_GraphInfo': 'graphInfos',
        'ARC_PROTOCOL_Units': 'units',
        'ARC_PROTOCOL_JobTask': 'jobTasks',
        'ARC_PROTOCOL_Protocol': 'protocols',

    }

    private info;
    private editorObservable;
    private editorObserver;

    constructor (
        private pouchService: PouchDBService,
        private http: Http
    ) {
        this.editorObservable = new Observable(obs => this.editorObserver=obs)
    }

    public getSourceByCode(code) {
        // console.log('checking sources exist for ', code);
        for (let x in this.sources) {
            // if(true) {
                // console.log('comparing', code, 'with', this.sources[x].devices);
                if (this.sources[x].devices.indexOf(code) !== -1) {
                    console.log('protocol.service::getSourceByCode -- source found for', code, '@', x);
                    return x;
                }
            // }
        }
        console.log('protocol.service::getSourceByCode -- no source found for ', code);
        return false;
    }

    deleteTest (code, name) {
        for (let x in this.sources) {
            if (this.sources[x].devices.indexOf(code) !== -1) {
                let source = 'ARC_PROTOCOL_' + x;
                return this.pouchService.get(source).then( doc => {
                    let removeIndex;
                    let indexFound = false;
                    for (let i = 0; i < doc.items.length; i++) {
                        // console.log('searching for ', code, name, 'with', doc.items[i]);
                        if ((this.sources[x].devices.length === 1 || code === doc.items[i].Device) && name === doc.items[i].TestName) {
                            removeIndex = i;
                            indexFound = true;
                        }
                    }
                    if(!indexFound) {
                        throw 'Test not found. Not deleting';
                    }
                    doc.items.splice(removeIndex,1);
                    // console.log('theoretically updating with new items', doc.items);

                    this.promiseFormInfoLoaded().then( info => {
                        let protocolsChanged = false;
                        // console.log('protocol.service::deleteTest() -- Searching for any occurences of: ', code, name, 'within protocols');
                        for (let i = 0; i < info.protocols.length; i++) {
                            //@TODO: Unlikely test names will ever match and have two codes, but consider looping through array entirely to be sure.
                            // && info.protocols[i].TestCodes.substr(info.protocols[i].TestNames.split(';').indexOf(name),2)==code
                            while(info.protocols[i].TestNames.split(';').indexOf(name) !== -1 && info.protocols[i].TestCodes.substr(info.protocols[i].TestNames.split(';').indexOf(name)*2,2)) {
                                // console.log('What about the code? ', info.protocols[i].TestCodes.substr(info.protocols[i].TestNames.split(';').indexOf(name)*2,2));
                                protocolsChanged = true;
                                let names = info.protocols[i].TestNames.split(';');
                                // console.log('protocol.service::deleteTest() -- found and changing protocol', info.protocols[i].Name, info.protocols[i]);
                                let dropIndex = names.indexOf(name);
                                names.splice(dropIndex,1);
                                info.protocols[i].TestNames = names.join(';');
                                info.protocols[i].TestCodes = info.protocols[i].TestCodes.substr(0,dropIndex*2) + info.protocols[i].TestCodes.substr(dropIndex*2+2);

                                this.populateTests(info.protocols[i]);
                            }
                        }
                        if (protocolsChanged) {
                            console.log('protocol.service::deleteTest() -- protocols did change, so updating', info.protocols);
                            return this.pouchService.get('ARC_PROTOCOL_Protocol').then( doc => {
                                doc.items = info.protocols;
                                return this.pouchService.put('ARC_PROTOCOL_Protocol', doc).then(res => {
                                    console.log('protocol.service::deleteTest() -- Saved new protocol information', res);
                                    return res;
                                });
                            });
                        }
                    })

                    this.updateSource(source, doc.items);
                    return doc.items;
                });
            }
        }
        return new Promise( (r, e) => {
            e('no source found');
        })
    }

    public addNewTest (test) {
        for (let x in this.sources) {
            if (this.sources[x].devices.indexOf(test.Device) !== -1) {
                let source = 'ARC_PROTOCOL_' + x;
                return this.pouchService.get(source).then( doc => {
                    doc.items.push(test);
                    // console.log('theoretically updating with new items', doc.items);
                    this.updateSource(source, doc.items);
                    return doc.items;
                });
            }
        }
        return new Promise( (r, e) => {
            e('no source found');
        })
    }

    public getEditorObservable () {
        return this.editorObservable;
    }

    public broadcastProtocolEdit (Name) {
        if(this.editorObserver) {
            this.editorObserver.next({type: 'protocol', name: Name});
        }
    }

    public broadcastTestEdit (Code, Name) {
        if(this.editorObserver) {
            this.editorObserver.next({type: 'test', name: Name, code: Code});
        }
    }

    public promiseProtocol (Name) {
        // console.log('Searching for Protocol Name', Name);
        return this.promiseFormInfoLoaded().then( info => {
            // console.log('the info is loaded', info);
            for (let i = 0; i < info.protocols.length; i++) {
                if (this.info.protocols[i].Name === Name) {
                   return new Promise (r => r(this.populateTests(this.info.protocols[i])));
                }
            }
            console.error('NO MATCH FOUND FOR PROTOCOL', Name);
        });
    }

    public populateTests (protocol) {
        if (!protocol) {
           protocol = {
               TestCodes: '',
               TestNames: ''
           };
        }

        let codes = protocol && protocol.TestCodes ? protocol.TestCodes.match(/.{2,2}/g) : [];
        let names = protocol && protocol.TestNames ? protocol.TestNames.split(';') : [];
        protocol.tests = [];

        if(!codes) {
            // console.error('COULD NOT SPLIT CODES', protocol);
            return protocol;
        }

        for (let i = 0; i < codes.length; i++) {

            if(codes[i] === 'PR') {
                let protocolFound = false;
                for (let j = 0; j < this.info.protocols.length; j++) {
                    if (this.info.protocols[j].Name === names[i]) {
                        protocolFound = true;
                        // console.log('POPULATE TESTS -- SUB-PROTOCOL MATCH FOUND FOR ', protocol, this.info.protocols[j]);
                        this.populateTests(this.info.protocols[j]);
                        // console.log('CONCATENATING', protocol.tests, 'with', this.info.protocols[j].tests);
                        protocol.tests = protocol.tests.concat(this.info.protocols[j].tests);
                    }
                }
                if (!protocolFound) {
                    console.error('no protocol found for', names[i]);
                }
            } else {
                protocol.tests.push({ code: codes[i], name: names[i] });
            }

        }
        return protocol;
    }
   protocol: any;

    addProtocol (protocolName: String):Promise<void | Protocol>{
      protocol=null;
      var protocol={
      _id: 'Id_'+protocolName,
      Name: protocolName,
      NumTests: 2,
      TestNames: ['Blood Test','Sugar Test'],
      TestCodes: ['BT','ST'],
      tests: [
        {code:'BT',name:'Blood Test'},
        {code:'ST',name:'Sugar Test'}
    ]
    };
      return this.http.post(this.PROTOCOLS_API+'add', protocol)
             .toPromise()
             .then(response => response.json() as Protocol)
             .catch(this.handleError);
    }

    updateProtocol (protocol: Protocol):Promise<void | Protocol>{
      return this.http.post(this.PROTOCOLS_API+'update', protocol)
             .toPromise()
             .then(response => response.json() as Protocol)
             .catch(this.handleError);
    }

    dropProtocol(protocolId: String):Promise<void | String>{
      return this.http.delete(this.PROTOCOLS_API, protocolId)
             .toPromise()
             .then(response => response.json() as String)
             .catch(this.handleError);
    }

    getAllProtocols (): Observable<Protocol[]>{
      return this.http
          .get(this.PROTOCOLS_API+'all')
          .map(res => res.json());
    }


    private handleError (error: any) {
      let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
      console.error(errMsg); // log to console instead
    }


    // dropProtocol (Name) {
    //     return this.promiseFormInfoLoaded().then( info => {
    //         for (let j = 0; j < this.info.protocols.length; j++) {
    //             if (this.info.protocols[j].Name === Name) {
    //                 this.info.protocols.splice(j, 1);
    //                 // console.log('-- Updated: ', this.info.protocols);
    //                 return this.updateSource('ARC_PROTOCOL_Protocol', this.info.protocols);
    //             }
    //         }
    //         console.error('Missing Protocol: ' + Name);
    //         return;
    //     });
    // }

    // addProtocol (Name) {
    //     return this.promiseFormInfoLoaded().then( info => {
    //         for (let j = 0; j < this.info.protocols.length; j++) {
    //             if (this.info.protocols[j].Name === Name) {
    //                 throw 'Protocol already exists: ' + Name;
    //             }
    //         }
    //
    //         this.info.protocols.push({
    //             Name: Name,
    //             NumTests: 0,
    //             TestNames: '',
    //             TestCodes: '',
    //             tests: []
    //         });
    //         return this.updateSource('ARC_PROTOCOL_Protocol', this.info.protocols);
    //     });
    // }





    public saveProtocol (protocol) {
        // console.log('saving protocol information', protocol);

        return this.promiseFormInfoLoaded().then( info => {
            for (let j = 0; j < this.info.protocols.length; j++) {
                if (this.info.protocols[j].Name === protocol.Name) {
                    this.info.protocols[j] = this.populateTests(protocol);

                    return this.pouchService.get('ARC_PROTOCOL_Protocol').then( doc => {
                       doc.items = this.info.protocols;

                       // console.log('THEROETICALLY YOU WOULD BE SAVING THIS AS ', doc);
                       return this.pouchService.put('ARC_PROTOCOL_Protocol', doc).then(res => {
                           // console.log('Saved new protocol information', res);
                           return res;
                       });
                    });
                }
            }

            return new Promise((r,e)=>{e('Could not update, Name not found in protocol list')});
        })
        // return new Promise (r=>r(protocol));
    }




    private updateSource(source, items) {
        return this.pouchService.get(source).then( doc => {
            doc.items = items;

            // console.log('THEROETICALLY YOU WOULD BE SAVING THIS AS ', doc);
            return this.pouchService.put(source, doc).then(res => {
                // console.log('Saved new protocol information', res);
                return res;
            });
        });
    }

    public getTestTypes () {
        return this.promiseFormInfoLoaded().then(info => {
            return info.testTypes;
        })
        // return this.pouchService.get('ARC_PROTOCOL_TestTypes').then( res => {
        //     // console.log('Received the ARCON Test Types', res);
        //     return res.items;
        // });
    }

    promiseTestsByCode (code) {
        // console.log('called to compare', code, 'with', this.sources);

        return this.promiseFormInfoLoaded().then( info => {
            for (let x in this.sources) {
                if(true) {
                    // console.log('pulling and comparing', x, this.sources[x].devices, code);
                    if(this.sources[x].devices.indexOf(code) !== -1) {
                        // console.log('found source', this[this.info_sources['ARC_PROTOCOL_' + x]]);
                        return this.pouchService.get('ARC_PROTOCOL_' + x).then(doc => {
                            let items = [];
                            // console.log('[promiseTestsByCode] Found document, now looping through', doc);
                            for(let i = 0; i < doc.items.length; i++) {
                                let test = doc.items[i];

                                // console.log('[promiseTestsByCode] Comparing', test);
                                if (this.sources[x].devices.length === 1 || test.Device === code) {
                                    console.log('[promiseTestsByCode] Pushing', test);
                                    items.push(test);
                                }
                            }


                            console.log('[promiseTestsByCode] items by the end', items);

                            return items;
                        });
                        // return info[this.info_sources['ARC_PROTOCOL_' + x]];
                    }
                }
            }
            throw 'protocol.service::promiseTestsByCode() -- Could not locate source items for test type ' + code;
        })
    }

    promiseFormInfoLoaded () {
        if (this.info) {
            return new Promise(r => {r(this.info)});
        }
        let keys = Object.keys(this.info_sources);

        return this.pouchService.allDocs({ include_docs: true, keys: keys }).then( res => {

            let info = {};
            for (let i = 0; i < res.rows.length; i++ ) {
                let row = res.rows[i];

                if(!row.doc) {
                    console.error('Failed to get critical protocol document', row);
                    throw 'Missing document ' + row.key;
                    // continue;
                }

                if (this.info_sources[row.doc._id]) {
                    // console.log('SOURCE match for', this.info_sources[row.doc._id], row.doc);
                    info[this.info_sources[row.doc._id]] = row.doc.items;
                } else {
                    console.error('could not match source', row.doc._id);
                }
            }
            this.info = info;
            return this.info;
        })
    }

    // { code: '--', name: ''}
    public promiseTest (test) {

        let source = this.determineTestSource(test.code);

        return this.pouchService.get('ARC_PROTOCOL_' + source).then( res => {
            //match Device & TestName
            for (let i = 0; i < res.items.length; i++) {
                if ((this.sources[source].devices.length === 1 || test.code === res.items[i].Device) && test.name === res.items[i].TestName) {
                    return res.items[i];
                }
            }

            throw 'Could not locate ' + test.code + ' - ' + test.name;
        }, err => {
            console.error('COULD NOT FIND PROTOCOL FILE', source);
        });

    }

    public determineTestSource(code) {

        for (let source in this.sources) {
            if (this.sources[source].devices.indexOf(code) !== -1) {
                return source;
            }
        }
        throw 'No matching sources for test.';
    }

    public save(test, data) {
        // console.log('attempting to save with', test, data);
        let source = this.determineTestSource(test.Device);
        return this.pouchService.get('ARC_PROTOCOL_' + source).then( res => {
            //match Device & TestName
            let updateMade = false;
            for (let i = 0; i < res.items.length; i++) {
                if (test.Device === res.items[i].Device && test.TestName === res.items[i].TestName) {
                    updateMade = true;
                    let updatedItem = test;
                    for(var item in data) {
                        if (true) {
                           updatedItem[item] = data[item];
                        }
                    }
                    res.items[i] = updatedItem;
                    break;
                }
            }


            if(!updateMade) {

                throw 'Could not locate ' + test.Device + ' - ' + test.TestName;
            }

            this.pouchService.put('ARC_PROTOCOL_' + source, res).then( res => {
                console.log('Updated tests', res);
            } );
        }, err => {
            console.error('COULD NOT FIND PROTOCOL FILE', source);
        });

    }


}
