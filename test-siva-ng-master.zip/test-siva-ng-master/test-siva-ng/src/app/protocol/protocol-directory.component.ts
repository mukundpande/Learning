import {
    AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, Input, OnChanges,
    OnInit
} from "@angular/core";
import {ProtocolService} from "./protocol.service";
@Component({
    selector: 'protocol-directory',
    templateUrl: './protocol-directory.component.html',
})
export class ProtocolDirectoryComponent implements AfterContentChecked { //
    @Input() protocol;
    @Input() child = [];
    @Input() edit;
    @Input() admin;

    children = {};
    loaded;

    constructor (private protocolService: ProtocolService) {}

    trimNameSplit (array) {
        if(array[array.length-1] === '') array.pop();
        return array;
    }

    ngAfterContentChecked () {
        // if (this.protocol && this.protocol.TestNames) {
        //     // console.log('AFTER CONTENT CHECKED --- Loading with parameters', this.protocol, this.child);
        //     // this.loaded = true;
        //     let testNames = this.protocol.TestNames.split(';');
        //     for (let i = 0; i < testNames.length; i++) {
        //         if (this.protocol.TestCodes.substr(i*2,2) == 'PR' && !this.children[i]) {
        //             this.children[i] = { Name: 'Loading...'};
        //             this.protocolService.promiseProtocol(testNames[i]).then(protocol => {
        //                 console.log('setting', i, 'to', protocol);
        //                 this.children[i] = protocol;
        //             });
        //         }
        //     }
        //
        // }
    }

    editProtocol (protocol) {
        this.protocolService.broadcastProtocolEdit(protocol.Name);
        // alert('editing protocol' + protocol.Name);
    }

    editTest (code, test) {
        this.protocolService.broadcastTestEdit(code,test);
        // alert('editing test' + code + ' ' + test);
    }

    removeItem (index) {
        let names = this.protocol.TestNames.split(';');
        names.splice(index,1);
        this.protocol.TestCodes = this.protocol.TestCodes.substr(0,index*2) + this.protocol.TestCodes.substr(index*2+2);
        this.protocol.TestNames = names.join(';');
    }

    // getDirectory (name) {
    //     console.log('Grabbing subdirectory', name);
    //     return this.protocolService.promiseProtocol(name);
    // }
}
