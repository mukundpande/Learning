import {Component, Input, OnInit} from "@angular/core";
import {FormBuilder} from "@angular/forms";
@Component({
    selector: 'editor-cx',
    template: `
        <form [formGroup]="testForm">

            <div class="row">

                <div class="form-group col-2">
                    <label>Type</label>
                    <input type="text" class="form-control" [value]="test.Device" readonly />
                </div>
                <div class="form-group col-10">
                    <label>Test Name</label>
                    <input type="text" class="form-control" [value]="test.TestName" readonly />
                </div>

            </div>

            <div class="row">

                <div class="form-group col-3">
                    <label >Trials</label>
                    <input type="text" formControlName=".Trials" class="form-control " />
                </div>
                <div class="form-group col-3">
                    <label>Test Time</label>
                    <div class="row">
                        <div class="col-6">
                            <input type="text" formControlName="TestTime" class="form-control " />
                        </div>
                        <div class="col-6">
                            Sec.
                        </div>
                    </div>
                </div>
                <div class="form-group col-3">
                    <label >Rest Time</label>
                    <div class="row">
                        <div class="col-6">
                            <input type="text" formControlName="RestTime" class="form-control " />
                        </div>
                        <div class="col-6">
                            Sec.
                        </div>
                    </div>
                </div>
                <div class="form-group col-3">
                    <label>Test Mode</label>
                    <md-select formControlName="TestMode">
                        <md-option *ngFor="let testMode of testModes" [value]="testMode.Mode">{{ testMode.Mode }}<span style="color:#888;"> | {{ testMode.Description}}</span></md-option>
                    </md-select>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-2">
                    <label>Units</label>
                    <md-select formControlName="Units">
                        <md-option *ngFor="let unit of units" [value]="unit.Units">{{ unit.Units }}<span style="color:#888;"> | {{ unit.Description}}</span></md-option>
                    </md-select>
                </div>
                <div class="form-group col-4">
                    <label>Maximum Graph Value</label>

                    <div class="row">
                        <div class="col-4">
                            <input type="text" class="form-control" formControlName="ScaleMax" />
                        </div>
                        <div class="col-8">
                            <md-checkbox formControlName="Autoscale">AutoScale</md-checkbox>
                        </div>
                    </div>

                </div>
                <div class="form-group col-2">
                    <label>Start at:</label>
                    <input type="text" class="form-control" formControlName="StartForce" />

                </div>
                <div class="form-group col-4">
                    <label>Additional Information For Testing Graph &hellip;</label>

                    <label>Test Mode</label>
                    <md-select formControlName="GraphInfo">
                        <md-option *ngFor="let graphInfo of graphInfos" [value]="graphInfo.GICode">{{ graphInfo.GICode }}<span style="color:#888;"> | {{ graphInfo.GraphInfo}}</span></md-option>
                    </md-select>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-4">
                    <label>{{ this.testForm.value.OtherName }}</label>
                    <input type="text" formControlName="OtherInfo" class="form-control" />
                </div>
                <div class="form-group col-8">
                    <label>Additional Testing Options &hellip;</label>
                    <md-checkbox formControlName="HeartRate" [value]="true">Monitor Heart Rate</md-checkbox>
                    <md-checkbox formControlName="Audio" [value]="true">Audio Feedback</md-checkbox>
                    <md-checkbox formControlName="Distraction" [value]="true">Distraction</md-checkbox>
                </div>

            </div>

        </form>
    `,
    styles: [`
        .trial-max-input label {
            display:block;
            text-align:center
        }
        .trial-max-input input{
            width:49%;
            display:inline-block;
            margin:0;
        }
    `]
})
export class EditorCx implements OnInit {
    @Input() test;
    @Input() testModes;
    @Input() graphInfos;
    @Input() units;

    constructor (private fb:FormBuilder) {

    }

    ngOnInit () {
        console.log('Loading RM TEST with', this.test);

        let keys = ['HeartRate', 'Audio', 'Autoscale', 'Spare'];

        for (let i = 0; i < keys.length; i++) {
            this.test[keys[i]] = +this.test[keys[i]];
        }

        this.testForm.reset(this.test);
    }

    testForm = this.fb.group({
        '.Trials': "3",
        Audio: "0",
        Autoscale: "1",
        // Device: "CX",
        Distraction: false,
        GraphInfo: "MN",
        HeartRate: "0",
        OtherInfo: "",
        OtherName: "Position",
        RestTime: "5",
        ScaleMax: "50",
        Spare: "0",
        StartForce: "1.00",
        TestMode: "LR",
        // TestName: "Elbow Extension",
        TestTime: "5.00",
        Units: "LB"
    });
}