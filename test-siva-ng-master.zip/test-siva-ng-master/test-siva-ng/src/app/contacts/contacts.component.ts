import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as Papa from 'papaparse/papaparse.min.js';

@Component({
    template: `
        <div class="container">
            <button class="btn btn-danger" (click)="deleteAll()"> Delete All</button>
            <input type="file" (change)="readUpload($event)" #input />

            <ngx-datatable
                    [rows]="contacts"
                    class="material"
                    [columnMode]="'force'"
                    [limit]="20"
                    [headerHeight]="50"
                    [footerHeight]="50"
                    [rowHeight]="'auto'">
                <ngx-datatable-column name="Document Name" prop="id"></ngx-datatable-column>
                <ngx-datatable-column name="Actions" [width]="120" [sortable]="false"
                                      [canAutoResize]="false"
                                      [draggable]="false"
                                      [resizeable]="false">
                    <ng-template ngx-datatable-cell-template let-value="value" let-row="row">
                        <button class="btn btn-primary btn-sm" routerLink="{{ row.id }}">
                             Edit
                        </button>
                    </ng-template>
                </ngx-datatable-column>
            </ngx-datatable>
        </div>
    `
})
export class ContactsComponent implements OnInit {
    contacts = [];
    // csv = new CSVParser();
    constructor(private pouchService: PouchDBService) { }

    deleteAll () {
        if (!confirm('Are you sure?')) return false;

        for (let i = 0; i < this.contacts.length; i++) {
            this.pouchService.remove(this.contacts[i].doc);
        }
    }

    readUpload($event) {
        console.log('reading upload', $event);

        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        Papa.parse(file, {
            complete: results => {

                let headers = results.data.shift();

                for (let i = 0; i < headers.length; i++)  {
                    headers[i] = headers[i].replace(/[.\s]+/gi, '');
                }

                headers[0] = '_id'; // for pouchDB

                for (let i = 0; i < results.data.length; i++) {
                    let json: any = {};

                    // skip bad column counts
                    if (results.data[i].length !== headers.length) { continue; }

                    for (let j = 0; j < results.data[i].length; j++) {
                        json[headers[j]] = results.data[i][j];
                    }

                    json._id = 'CONTACT_' + json.Type + '_' + json._id; // for pouchDB
                    console.log('UPLOADING THIS OBJECT', json._id, json);
                    // this.pouchService.put(json._id, json);
                }

                console.log('headers', headers);

            }
        });
        //
        // let fileType = $event.target.parentElement.id;
        //
        // fr.onloadend = (end) => {
        //     let result = atob(fr.result.split('base64,')[1]);
        //     console.log('FINISHED', result);
        //
        //
        //
        //
        // };
        // // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        //
        // fr.readAsDataURL(file);
    }

    ngOnInit () {
        this.pouchService.allDocs({include_docs: true, startkey: 'CONTACT_', endkey: 'CONTACT_\uFFFF'}).then(res => {
            this.contacts = res.rows;
            console.log('Got documents', res);
        });
    }
}
