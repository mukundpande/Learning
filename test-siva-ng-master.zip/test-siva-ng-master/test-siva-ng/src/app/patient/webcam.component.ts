import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {DomSanitizer} from "@angular/platform-browser";
@Component({
  templateUrl: './webcam.component.html',
    styles: [`
        .cssWebCam{
            width: 480px;
            height: 480px;
        }
    `]
})
export class WebcamComponent implements OnInit {

    public videosrc:any;
    public img:any;
    public imgsrc:any;
    public streamA:any;
    public stream:any;
    @ViewChild('videoimg') videoimg: any;

    constructor(private sanitizer:DomSanitizer, private element:ElementRef,private activeModal: NgbActiveModal) {
    }

    ngOnInit() {
        this.showCam();
    }

    stopCam () {
        console.log('stop these video tracks', this.stream, this.stream.getVideoTracks(), this.streamA, this.streamA.getVideoTracks());
        if(this.stream.getVideoTracks().length) {
            this.stream.getVideoTracks()[0].stop();
        }
        if(this.streamA.getVideoTracks().length) {
            this.streamA.getVideoTracks()[0].stop();
        }
        // this.stream.getAudioTracks()[0].stop();
    }

    acceptImage () {
        this.activeModal.close(this.imgsrc);
    }

    redoImage () {
        this.img = null;
        this.showCam();
    }

    private showCam() {
        // 1. Casting necessary because TypeScript doesn't
        // know object Type 'navigator';
        let nav = <any>navigator;

        // 2. Adjust for all browsers
        nav.getUserMedia = nav.getUserMedia || nav.mozGetUserMedia || nav.webkitGetUserMedia;

        // 3. Trigger lifecycle tick (ugly, but works - see (better) Promise example below)
        //setTimeout(() => { }, 100);

        // 4. Get stream from webcam
        nav.getUserMedia(
            {video: true},
            (stream) => {
                this.streamA = stream;
                let webcamUrl = URL.createObjectURL(stream);

                // 4a. Tell Angular the stream comes from a trusted source
                this.videosrc = this.sanitizer.bypassSecurityTrustUrl(webcamUrl);

                // 4b. Start video element to stream automatically from webcam.
                this.videoimg.nativeElement.autoplay = true;
            },
            (err) => console.log(err));


        // OR: other method, see http://stackoverflow.com/questions/32645724/angular2-cant-set-video-src-from-navigator-getusermedia for credits
        var promise = new Promise<string>((resolve, reject) => {
            nav.getUserMedia({video: true}, (stream) => {
                resolve(stream);
            }, (err) => reject(err));
        }).then((stream) => {
            this.stream = stream;
            let webcamUrl = URL.createObjectURL(stream);
            this.videosrc = this.sanitizer.bypassSecurityTrustResourceUrl(webcamUrl);
            // for example: type logic here to send stream to your  server and (re)distribute to
            // other connected clients.
        }).catch((error) => {
            console.log(error);
        });
    }

    snapPhoto () {
        // console.log(this.videoimg);
        let scale = 1;
        let video = this.videoimg.nativeElement;
        let canvas = document.createElement("canvas");
        canvas.width = video.videoWidth * scale;
        canvas.height = video.videoHeight * scale;
        canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);

        this.imgsrc = canvas.toDataURL();
        this.img = this.sanitizer.bypassSecurityTrustResourceUrl(this.imgsrc);
        this.stopCam();
    }

    close(){
        this.stopCam();
        this.activeModal.close(true);
    }
}
