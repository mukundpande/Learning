import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as Papa from 'papaparse/papaparse.min.js';

@Component({
  templateUrl: './patients.component.html',
})
export class PatientsComponent implements OnInit {
    patients = [];
    // csv = new CSVParser();
    constructor(private pouchService: PouchDBService) { }

    deleteAll () {
        if (!confirm('Are you sure?')) return false;

        for (let i = 0; i < this.patients.length; i++) {
            this.pouchService.remove(this.patients[i].doc).then(res => {
                console.log('RES DELETED', res);
            });
        }
    }

    readUpload($event) {
        console.log('reading upload', $event);

        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        Papa.parse(file, {
            complete: results => {

                let headers = results.data.shift();

                for (let i = 0; i < headers.length; i++)  {
                    headers[i] = headers[i].replace(/[.\s]+/gi, '');
                }

                headers[0] = '_id'; // for pouchDB

                for (let i = 0; i < results.data.length; i++) {
                    let json: any = {};

                    // skip bad column counts
                    if (results.data[i].length !== headers.length) { continue; }

                    for (let j = 0; j < results.data[i].length; j++) {
                        json[headers[j]] = results.data[i][j];
                    }

                    json._id = 'PAT_' + json._id; // for pouchDB
                    console.log('UPLOADING THIS OBJECT', json);
                    this.pouchService.put(json._id, json);
                }

                console.log('headers', headers);

            }
        });
        //
        // let fileType = $event.target.parentElement.id;
        //
        // fr.onloadend = (end) => {
        //     let result = atob(fr.result.split('base64,')[1]);
        //     console.log('FINISHED', result);
        //
        //
        //
        //
        // };
        // // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        //
        // fr.readAsDataURL(file);
    }

    ngOnInit () {
        this.pouchService.allDocs({include_docs: true, startkey: 'PAT_', endkey: 'PAT_\uFFFF'}).then(res => {
            this.patients = res.rows;
            console.log('Got documents', res);
        });
    }
}
