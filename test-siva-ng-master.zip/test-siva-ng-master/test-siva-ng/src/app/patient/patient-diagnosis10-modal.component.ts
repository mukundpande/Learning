import {Component, OnInit} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
@Component({
    templateUrl: './patient-diagnosis10-modal.component.html',
})
export class PatientDiagnosis10ModalComponent implements OnInit {
    test;
    info: any = {};
    icdCode = '';
    icdDiag = '';

    code;
    codes = [];

    sources: any = {
        // 'ARC_ICD_Category': 'categories',
        'ARC_ICD10': 'codes'
    }

    private categories_key = '';
    private codes_key = '';

    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService
    ) { }

    ngOnInit () {
        this.pouchService.allDocs({include_docs:true, keys: Object.keys(this.sources)}).then(docs => {
            console.log('loaded documents', docs);
            for (let i = 0; i < docs.rows.length; i++) {
                let doc = docs.rows[i].doc;
                console.log('[ICD-10 Popup] Loaded Document', doc, docs.rows[i]);
                this.info[this.sources[doc._id]] = doc.items;
            }

            console.log('[ICD-10 Popup] loaded info', this.info);

            this.codes = this.info.codes;
        });
    }

    detectAutofill(value) {
        console.log('autofilling', value);
        let cat;
        if (cat = this.findCodeFor(value)) {
            console.log('Found category', cat);

            this.code = cat;
            this.codeChanged(value);

        } else {
            console.error('Could not match category find for', value);
        }
    }

    findCodeFor (value) {
        let minDex = 0,
            maxDex = this.codes.length - 1,
            loopStop = 1000,
            i = 0;

        while (minDex != maxDex && i < loopStop ) {

            let curDex = Math.round((minDex+maxDex)/2);
            let cur = this.codes[curDex].Code.toLowerCase();
            // console.log('');
            value = value.toLowerCase();

            for (let m = 0; m < value.length; m++) {
                if (value.charCodeAt(m) < cur.charCodeAt(m)) {
                    maxDex = curDex;
                    // console.log('Setting maxDex', value.charCodeAt(m), ' < ', cur.charCodeAt(m), {value, cur});
                    break;
                } else if (value.charCodeAt(m) > cur.charCodeAt(m)) {
                    minDex = curDex;
                    // console.log('Setting minDex', value.charCodeAt(m), ' > ', cur.charCodeAt(m), {value, cur});
                    break;
                } else {
                    // console.log('Continuing...', {value, cur});
                    continue;
                }
            }

            i++;
        }

        console.error('stopping because while loop ended', {minDex, maxDex, i, loopStop});

        let curDex = Math.round((minDex+maxDex)/2);
        return this.codes[curDex];

        // for (let i = 0; i < this.codes.length; i++) {
        //     let code = this.codes[i];
        //     console.log('COMPARING WITH', code);
        //
        //     if(code.Code.substr(0,value.length) === value) {
        //         return code;
        //     }
        // }
        // return false;
    }


    codeChanged (value) {
        this.icdCode = this.code.Code;
        this.icdDiag = this.code.Description;
    }

    finish () {
        this.activeModal.close({code: this.icdCode, diag: this.icdDiag});
    }

    clear () {
        this.activeModal.close(null);
    }

    close () {
        this.activeModal.close(false);
    }

}
