import {Component, OnDestroy, OnInit, Sanitizer, ViewChild,Input} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {FooterContextService} from "../services/footer-context.service";
import {Router, ActivatedRoute, Params, Data} from "@angular/router";
import {FormArray, FormBuilder,FormControl, Validators} from "@angular/forms";
import {PatientService} from "./patient.service";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {PatientContactModalComponent} from "./patient-contact-modal.component";
import {DomSanitizer} from "@angular/platform-browser";
import {AmputationsModalComponent} from "../utils/amputations-modal.component";
import {WebcamComponent} from "./webcam.component";
import {PatientDiagnosis10ModalComponent} from "./patient-diagnosis10-modal.component";
import { Patient } from './patient.model';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import { TSMap } from "typescript-map";

@Component({
    templateUrl: './patient.component.html',
    styleUrls: ['./patient.component.css'],
})
export class PatientComponent implements OnInit, OnDestroy {
    @Input() patient: any = {};
    rollerId:String='';
    userIdValidation:String='';
    show:boolean =false;
    age: any = 0;
    placeholder;
    excludeRelationalData = false;
    createMode = false;
    patientTab = 0;
    historyTab = 0;
    @ViewChild('refField') refField: any;
    contactNames = {};
    nameCache = {};
    private activities = [
        'Walk', 'Climb', 'Balance', 'Stoop', 'Kneel', 'Crouch', 'Crawl',
        'Reach', 'Handling', 'Fingering', 'Feeling', 'Eye/Hd/Ft',
        'Sitting', 'Standing', 'Push Cart', 'Pull Cart'
    ];
    private strengths = [
        'Lift High', 'Lift Mid', 'Lift Low', 'Overall', 'Carry', 'Push', 'Pull'
    ]
    patientForm = this.fb.group({
        _id: new FormControl('', [Validators.required]),
        FirstName: ['', Validators.required],
        Initial: '',
        LastName: ['', Validators.required],
        Address: ['', Validators.required],
        City:['', Validators.required],
        State:['', Validators.required],
        Zip:['', Validators.required],
        HomePhone: ['', Validators.required],
        WorkPhone: '',
        DateofBirth: '',
        Sex: ['', Validators.required],
        Height: ['', Validators.required],
        Weight: ['', Validators.required],
        Units: '',
        DominantHand: '',
        Occupation: '',
        LastTestDate:new Date(),
        Side1: '',
        Date1: '',
        Code1: '',
        Diag1: '',
        Side2: '',
        Date2: '',
        Code2: '',
        Diag2: '',
        Side3: '',
        Date3: '',
        Code3: '',
        Diag3: '',
        Employer: '',
        Physician: '',
        Attorney: '',
        Insurance: '',
        Spare: '',
        InDate: '',
        BP: '',
        Pulse: '',
        Referred: '',
        Intake: '',
        GUID: '',
        Photo: '',
        Injury: '',
        Demands: '',
        therapies: this.fb.array([]),
        medications: this.fb.array([]),
        employments: this.fb.array([]),
        educations: this.fb.array([]),
        activities: this.fb.group({
            'Walk': '', 'Climb': '', 'Balance': '', 'Stoop': '', 'Kneel': '', 'Crouch': '', 'Crawl': '',
            'Reach': '', 'Handling': '', 'Fingering': '', 'Feeling': '', 'Eye/Hd/Ft': '',
            'Sitting': '', 'Standing': '', 'Push Cart': '', 'Pull Cart': ''
        }),
        strengths: this.fb.group({
            'Lift High': '', 'Lift Mid': '', 'Lift Low': '', 'Overall': '', 'Carry': '', 'Push': '', 'Pull': ''
        }),
    });

    public constructor(
        private footerContext: FooterContextService,
        private modalService: NgbModal,
        private pouchService: PouchDBService,
        private patientService: PatientService,
        private router: Router,
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private sanitizer:DomSanitizer
    ) {
       console.log(this.router.url); //  /routename
      this.router.events.subscribe(path => {
        console.log('path = ', path);
        var _id=this.router.url;
        var trueOrFalse = _id.startsWith("/patient");
        if(trueOrFalse){
            let patientID=_id.split('/')[2];
            this.loadingPatientById(patientID);
        }else{
          this.loadingPatientById(_id);
        }

     });
    }

    ngOnInit () {
        this.activateMainButtons();
        let _id=this.route.snapshot.params['patientId'];
        //alert(id);
        console.log('LOADING WITH PATIENT', _id);
        if(_id===undefined){
            this.router.navigate(['/']);
        }else{
            this.loadingPatientById(_id);
        }
        this.loadAllPatients();
    }

    loadingPatientById(_id){
      this.patientService.getPatientById(_id).subscribe(patient => {
      //this.patient = patient;
      this.rollerId=_id;
       this.populateValuesToForm(patient);
      //JSON.stringify(patients)
      console.log(this.patient );
        });
     }

     loadAllPatients(){
       this.patientService.getAllPatients().subscribe(patients => {
       let patientsLength=patients.length;
       var myMap = new TSMap<String,number>();
         for (let i = 0; i <patientsLength ; i++) {
              myMap.set(patients[i]._id,i);
       }
       localStorage.setItem('allPatientsMap', JSON.stringify(myMap));
       console.log(myMap);
      });
      }

      goForward (Id) {
         this.patientMoveHelper("next",Id);
        //this.goToPatientIndex(this.footerContext.patientIndex + 1);
      }

      goBack(Id) {
        this.patientMoveHelper("back",Id);
          //this.goToPatientIndex(this.footerContext.patientIndex - 1);
      }

      gotoFirst(Id) {
        this.patientMoveHelper("first",Id);
        //this.goToPatientIndex(0);
      }

      gotoLast (Id) {
          this.patientMoveHelper("last",Id);
          //this.goToPatientIndex(this.footerContext.getPatients().length - 1);
      }

      // fastBack (Id) {
      //   this.patientMoveHelper("last",Id);
      //     //this.goToPatientIndex(this.footerContext.patientIndex - 10);
      // }
      //
      // fastForward (Id) {
      //   this.patientMoveHelper("last",Id);
      //     //this.goToPatientIndex(this.footerContext.patientIndex + 10);
      // }

       patientMoveHelper(helpString,Id){
         let allPatientsMap=localStorage.getItem('allPatientsMap');
         let map = JSON.parse(allPatientsMap);

         let strMap = new Map();
         for (let k of Object.keys(map)) {
         strMap.set(k, map[k]);
        }
        console.log(strMap);
        let nextPatient=strMap.get(Id);

        if(helpString==='next'){
          nextPatient++;
        }else if(helpString==='back'){
            nextPatient--;
        }else if(helpString==='first'){
            nextPatient=0;
        }else if(helpString==='last'){
            nextPatient=strMap.size-1;
        }

        strMap.forEach((value, key, strMap) => {
           console.log(key, ':', value);
           if(value===nextPatient){
             this.router.navigate(['/patient/'+key]);
           }
         });
       }


     populateValuesToForm(patient){

       this.patientForm.get('_id').setValue(patient._id);
       this.patientForm.get('FirstName').setValue(patient.FirstName);
       this.patientForm.get('Initial').setValue(patient.Initial);
       this.patientForm.get('LastName').setValue(patient.LastName);
       this.patientForm.get('Address').setValue(patient.Address);
       this.patientForm.get('City').setValue(patient.City);
       this.patientForm.get('State').setValue(patient.State);
       this.patientForm.get('Zip').setValue(patient.Zip);
       this.patientForm.get('HomePhone').setValue(patient.HomePhone);
       this.patientForm.get('WorkPhone').setValue(patient.WorkPhone);
       this.patientForm.get('DateofBirth').setValue(patient.DateofBirth);
       this.patientForm.get('Sex').setValue(patient.Sex);
       this.patientForm.get('Height').setValue(patient.Height);
       this.patientForm.get('Weight').setValue(patient.Weight);
       this.patientForm.get('Units').setValue(patient.Units);
       this.patientForm.get('DominantHand').setValue(patient.DominantHand);

       this.patientForm.get('Occupation').setValue(patient.Occupation);
       this.patientForm.get('LastTestDate').setValue(patient.LastTestDate);
       this.patientForm.get('Side1').setValue(patient.Side1);
       this.patientForm.get('Date1').setValue(patient.Date1);
       this.patientForm.get('Code1').setValue(patient.Code1);
       this.patientForm.get('Diag1').setValue(patient.Diag1);

       this.patientForm.get('Side2').setValue(patient.Side2);
       this.patientForm.get('Date2').setValue(patient.Date2);
       this.patientForm.get('Code2').setValue(patient.Code2);
       this.patientForm.get('Diag2').setValue(patient.Diag2);

       this.patientForm.get('Side3').setValue(patient.Side3);
       this.patientForm.get('Date3').setValue(patient.Date3);
       this.patientForm.get('Code3').setValue(patient.Code3);
       this.patientForm.get('Diag3').setValue(patient.Diag3);

       this.patientForm.get('Employer').setValue(patient.Employer);
       this.patientForm.get('Physician').setValue(patient.Physician);
       this.patientForm.get('Attorney').setValue(patient.Attorney);
       this.patientForm.get('Insurance').setValue(patient.Insurance);
       this.patientForm.get('Spare').setValue(patient.Spare);
       this.patientForm.get('InDate').setValue(patient.InDate);
       this.patientForm.get('BP').setValue(patient.BP);
       this.patientForm.get('Pulse').setValue(patient.Pulse);

       this.patientForm.get('Referred').setValue(patient.Referred);
       this.patientForm.get('Intake').setValue(patient.Intake);
       this.patientForm.get('GUID').setValue(patient.GUID);
       this.patientForm.get('Photo').setValue(patient.Photo);
       this.patientForm.get('Injury').setValue(patient.Injury);
       this.patientForm.get('Demands').setValue(patient.Demands);
     }
     selectedFile=null;
     readImageUpload($event) {
     console.log($event);
     this.selectedFile=<File>$event.target.files[0];

         // let fr: FileReader = new FileReader();
         // let file: File = $event.target.files[0];
         // let fileType = $event.target.parentElement.id;
         // fr.onloadend = (end) => {
         //     let result = fr.result.split('base64,')[1];
         //     console.log('FINISHED', fr.result.split('base64,')[0] + 'base64,', file, result.length);
         //     this.patient._attachments = {};
         //     this.patientForm.patchValue({'Photo':file.name});
         //     this.patient._attachments[file.name] = {
         //         content_type: file.type,
         //         data: result
         //     };
         //
         //     this.patientForm.markAsDirty();
         // };
         // // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
         //
         // fr.readAsDataURL(file);
     }
    saveNewPatient ()  {
        if (!this.patientForm.dirty && !this.patientForm.valid) {
          if (this.patientForm.value._id === '' || !this.patientForm.value._id) {
              this.show=true;
              this.userIdValidation='Please enter PatientID';
              return false;
          }
             return false;
          }
        this.show=false;
        //this.patientForm.append('Photo',this.selectedFile,this.selectedFile.name);
        let obj = this.patientForm.value;
        obj._id = obj._id;
        alert('saving to ' + obj._id);
        obj.Photo=this.selectedFile;
        this.patientService.addPatient(obj).then((patient: Patient) => {
            this.patientForm.reset();
           });
         this.activateMainButtons();
    }

    getFooterContext () {
        return this.footerContext;
    }

    newRowFormGroup (patch = {}) {
        let group = this.fb.group({
            from: '',
            to: '',
            description: ''
        });
        // group.patchValue(patch);
        return group;
    }

    removeRowIfEmpty(section, i) {
        const control = <FormArray>this.patientForm.controls[section];

        // console.log('dropping', section, i, control, '?');

        let emptyValues = true;
        let formValues = control.controls[i].value;
        // console.log('Empty?', formValues.to.length, formValues.from.length, formValues.description.length);
        for(let x in formValues) {
            if (formValues[x].length) {
                // console.log('FOUND NON-EMPTY');
                emptyValues = false;
                break;
            }
        }
        if(emptyValues){
            control.removeAt(i);
        }

        // console.log('is this empty? ', formValues);
    }

    createNewRow (section, patch = {}) { // , $event
        // console.log('creating new row', section, $event);
        const control = <FormArray>this.patientForm.controls[section];
        // let patch = {};
        // patch[$event.target.name] = $event.target.value;
        // console.log('Control for', section, control);
        control.push(this.newRowFormGroup(patch));
    }

    ngOnDestroy () {
        //this.checkForChanges();
    }

    openWebcam () {
        const webcam = this.modalService.open(WebcamComponent);
        webcam.result.then(res => {
            if(!res) {
                return;
            }
            let imgName = 'webcam.png';
            let contentType = 'image/png';
            // console.log('The returned webcam result was ', res);
            let result = res.split('base64,')[1];
            console.log('FINISHED', res.split('base64,')[0] + 'base64,', result.length);
            this.patient._attachments = {};
            this.patientForm.patchValue({'Photo':imgName});
            this.patient._attachments[imgName] = {
                content_type: contentType,
                data: result
            };
            this.patientForm.markAsDirty();
        })
    }

    patientTabChanged ($event) {
        this.patientTab = $event.index;
    }
    historyTabChanged ($event) {
        this.historyTab = $event.index;
    }

    activateMainButtons () {
        this.createMode = false;
        this.excludeRelationalData = false;
        this.footerContext.activateButtons([
            {
                label: 'New Patient',
                click: () => {
                    this.createMode = true;
                    this.patientForm.reset({Units: '1'});
                    let oldPatient = this.patient;
                    let oldContextPatient = this.footerContext.patient;
                    this.patient = {};
                    this.footerContext.patient = null;
                    this.excludeRelationalData = true;
                    this.footerContext.activateButtons([
                        {},
                        {
                            label: 'OK',
                            click: () => { this.saveNewPatient(); }
                        },
                        {
                            label: 'Cancel',
                            click: () => {
                                this.patient = oldPatient;
                                this.footerContext.patient = oldContextPatient;
                                this.loadPatient();
                                this.activateMainButtons();
                            }
                        },
                        {}
                    ]);
                }
            },
            {
                label: 'Search',
                click: () => {
                   this.patientForm.reset();
                    this.footerContext.activateButtons([
                        {},
                        {
                            label: 'OK',
                            click: () => {
                              let obj = this.patientForm.value;
                              obj._id = obj.Id;
                            //  alert('Search started' + obj);
                              this.patientService.searchPatient(obj._id).subscribe((patient: Patient) => {
                                 this.patientForm.reset();
                                 this.populateValuesToForm(patient);
                                 });
                                this.activateMainButtons();
                                this.loadPatient();
                                console.log('RESULTS RETURNED', this.footerContext.searchPatients);
                            }
                        },
                        {
                            label: 'Cancel',
                            click: () => {
                                this.patientForm.reset();
                                this.activateMainButtons();
                            }
                        },
                        {}
                    ]);

                }
            },
            {
                label: 'Delete',
                click: () => {
                    if (!confirm('Really delete this patient from the database? All test data will be lost!')) {  return false; }

                    if (this.patientForm.value._id === '' || !this.patientForm.value._id) {
                        alert('Please Enter An ID#');
                        return false;
                    }
                    let obj = this.patientForm.value;

                    obj._id = 'PAT_' + obj._id;
                    var patientId=obj._id;
                    alert('Deleting ' + obj._id);

                      this.patientService.deletePatient(patientId).then((patientId: String) => {
                          alert('Patient Deleted'+patientId);
                        //this.deleteHandler(deletedContactId);
                        this.activateMainButtons();
                      });

                    // this.footerContext.patients.splice(this.footerContext.patientIndex, 1);
                    // this.pouchService.remove(this.patient).then( () => {
                    //
                    //     this.footerContext.patientIndex = 0;
                    //
                    //     // : no patients left should go to new patient
                    //     this.footerContext.patient = this.footerContext.patients[0] || {};
                    //     this.loadPatient();

                    }

            },
            {
                label: 'Quit',
                click: () => {
                    this.router.navigate(['/']);
                }
            }
        ]);
    }

    // checkForChanges () {
    //     if (this.patientForm.dirty && confirm(this.createMode ? 'Save new patient?' : 'Save changes?')) {
    //
    //         if(this.createMode) {
    //             console.log('IN CREATE MODE, SAVING NEW PATIENT INSTEAD');
    //             this.saveNewPatient()
    //             return;
    //         }
    //
    //         for (let k in this.patientForm.value) {
    //             if (true) {
    //                 // if(k === "Photo" && this.patientForm.value[k] !== this.patient[k]) {
    //                 //     //process new photo
    //                 //
    //                 // }
    //
    //                 this.patient[k] = this.patientForm.value[k];
    //             }
    //         }
    //
    //         console.log('UPDATING USER ', 'PAT_' + this.patient.Id, this.patient);
    //         this.pouchService.put('PAT_' + this.patient.Id, this.patient).then( (res) => {
    //             console.log('UPDATED USER', res);
    //             this.patient._id = this.patient._id.substr(4);
    //             let objKeys = Object.keys(this.patient);
    //             for (let i = 0; i < objKeys.length; i++) {
    //                 this.footerContext.patient[objKeys[i]] = this.patient[objKeys[i]]
    //             }
    //             this.footerContext.rememberCurrentPatient(this.patient);
    //         });
    //     }
    //     // console.log(this.patientForm, this.patientForm.dirty);
    // }

    loadPatient () {
        if (this.footerContext.patient) {
            this.pouchService.get('PAT_' + this.footerContext.patient._id, {attachments: true}).then(res => {
                this.patient = res;
                console.log('LOADED PATIENT', this.patient, "SETTING Id", this.patient._id.substr(4));
                this.patient.Id = this.patient._id.substr(4);

                let subsections = ['therapies', 'medications', 'employments', 'educations', 'activities', 'strengths'];
                let spreadsheets = ['therapies', 'medications', 'employments', 'educations'];
                for (let i = 0; i < subsections.length; i++) {
                    if (!this.patient[subsections[i]]) {
                       this.patient[subsections[i]] = {};
                    } else if (spreadsheets.indexOf(subsections[i]) !== -1) {
                        for (let j = 0; j < this.patient[subsections[i]].length; j++) {
                            this.createNewRow(subsections[i], this.patient[subsections[i]][j]);
                        }
                    }
                }

                // calculate age
                let dob = new Date(this.patient.DateofBirth);
                let date = new Date();

                this.age = date.getFullYear() - dob.getFullYear() - 1;

                if (date.getMonth() > dob.getMonth() ||
                    date.getMonth() === dob.getMonth() && date.getDate() > dob.getDate() ) { this.age++; }

                this.patient.DateofBirth = this.patient.DateofBirth ? this.patient.DateofBirth.split(' ')[0] : '';

                console.log('Patching Patient into Form', this.patient);

                this.patientForm.reset(this.patient);

                let contactFields = ['Employer','Insurance','Physician','Attorney','Spare'];
                for (let i = 0; i < contactFields.length; i++) {
                    this.setNameFor(contactFields[i]);
                }
            }).catch(err => {
                console.error('Could not load because: ' + err);
                this.patient = {
                    Id: 'COULD NOT LOAD PATIENT'
                }
            });
        }
    }

    modifyAmputations (patient) {
        const amputations = this.modalService.open(AmputationsModalComponent);
        amputations.componentInstance.open(patient);

        amputations.result.then(changesMade => {
            if (changesMade) {
                this.patientForm.markAsDirty();
            }
        })
    }



    dropPatientImage () {
        this.patient.attachments = {};
        this.patientForm.patchValue({'Photo':''});
        this.patientForm.markAsDirty();
    }

    forceReferredFieldUpdate () {
        this.refField.nativeElement.value = this.patientForm.value.Referred;
        console.log(this.refField.nativeElement);
    }


    goToPatientIndex(i) {
      //  this.checkForChanges();
        this.footerContext.goToPatientIndex(i);
        this.loadPatient();
    }

    generateImageSrc () {

        return this.sanitizer.bypassSecurityTrustUrl('data:' + this.patient._attachments[this.patientForm.value.Photo].content_type + ';base64,' + this.patient._attachments[this.patientForm.value.Photo].data);
    }

    addContact(type) {
        const modal = this.modalService.open(PatientContactModalComponent, {'size':'lg'});
        modal.componentInstance.open(type);

        modal.result.then( res => {
            if(res !== false) {
                let patchObj = {};
                let prefix = "CONTACT_" + type + "_";
                patchObj[type] = res ? res._id.substr(prefix.length) : null;
                console.log('Patching ',type,' in', patchObj);

                this.setNameFor(type, res);
                this.patientForm.patchValue(patchObj);
                this.patientForm.markAsDirty();
            }
        });

    }

    setNameFor(type, obj = null) {
        // console.log('SETTING NAME FOR', type, obj);
        if (obj) {
            this.contactNames[type] = obj.Name;
            return;
        }

        // console.log('OBJ IS NULL, CONTINUING');
        if (+this.patientForm.value[type]) {
            // console.log('VALUE IN PLACE, PULLING');
            this.contactNames[type] = '# Loading...';
            this.pouchService.get('CONTACT_'+type+'_'+this.patientForm.value[type])
                .then(res => this.contactNames[type] = res.Name)
                .catch(err => this.contactNames[type] = '')
        } else {
            // console.log(' --- NO TYPE FOUND, EMPTYING', type);
            this.contactNames[type] = '';
        }
    }

    contactIsNotSet (type) {
        let val = this.patientForm.value[type];
        if (!val || val === '0') {
            return true;
        }
    }

    getContactButtonLabel (type) {
        return this.contactIsNotSet(type) ? 'Add' : 'View / Change';
    }

    openDiagnosisDialogue (i) {
        const modal = this.modalService.open(PatientDiagnosis10ModalComponent, {size: 'lg'});

        modal.result.then(r => {
            let date = 'Date' + i;
            let side = 'Side' + i;
            let code = 'Code' + i;
            let diag = 'Diag' + i;

            let patch = {};

            if (r) {
                patch[code] = r.code;
                patch[diag] = r.diag;
            } else if (r === null) {
                patch[date] = '';
                patch[side] = '';
                patch[code] = '';
                patch[diag] = '';
            }

            this.patientForm.patchValue(patch);
            this.patientForm.markAsDirty();
        });
    }

}
