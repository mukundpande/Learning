// import {Injectable} from "@angular/core";
// import {PouchDBService} from "./pouchdb.service";
// import {FooterContextService} from "./footer-context.service";
// import {promise} from "selenium-webdriver";
// @Injectable()
// export class PatientService {
//     info_sources = {
//         'ARC_airs_AMPUTATIONS': 'amputations',
//         'ARC_airs_BODYCODE': 'bodycodes'
//     }
//
//     private info: any;
//
//     constructor(
//         private footerContext: FooterContextService,
//         private pouchService: PouchDBService
//     ) { }
//
//     save (patient) {
//
//     }
//
//     promiseInfo () {
//         if(this.info) {
//             console.log('Info already loaded', this.info);
//             return new Promise(r => r(this.info));
//         }
//
//         let fulfill, reject;
//         let promise = new Promise((f,r) => { fulfill = f; reject = r;});
//
//         let sources = this.pouchService.allDocs({ include_docs: true, keys: Object.keys(this.info_sources) }).then(res => {
//            let info = {};
//
//            for (let i = 0; i < res.rows.length; i++) {
//                let result = res.rows[i];
//                info[this.info_sources[result.key]] = result.doc.items;
//            }
//
//            console.log('Loading Patient info for first time', this.info);
//
//            fulfill(this.info = info);
//         });
//
//         return promise;
//     }
//
//     search (patient) {
//         let searchTerms = {};
//         let results = [];
//
//         for (let term in patient) {
//             if (patient[term]) {
//                 searchTerms[term] = patient[term];
//             }
//         }
//
//         console.log('Running search with these parameters', searchTerms);
//
//         for (let i = 0; i < this.footerContext.patients.length; i++) {
//             let patientMatches = true;
//
//             for (let term in searchTerms) {
//                 if (searchTerms[term].toLowerCase() !== this.footerContext.patients[i]
//                         [term === 'Id' ? '_id' : term].toLowerCase().substr(term === 'Id' ? 4 : 0, searchTerms[term].length)) {
//                     patientMatches = false;
//                     break;
//                 }
//             }
//
//             if (patientMatches) {
//                 results.push(this.footerContext.patients[i]);
//             }
//         }
//         // this.footerContext.searchPatients = results;
//         this.footerContext.acceptPatientResults(results);
//     }
//
//     getContact (type, id) {
//         return this.pouchService.get('CONTACT_' + type + '_' + id).then(res => {
//             return res;
//         }).catch(err => {console.error('Could not get contact', type, id);});
//     }
// }
