import { Injectable } from "@angular/core";
//import {$http} from 'xhr';
import { Http, Response,BrowserXhr } from '@angular/http';
import { Patient } from './patient.model';
import { appConfig } from '../app.config';
import { Observable } from 'rxjs/Observable';
import { Router } from "@angular/router";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';


@Injectable()
export class PatientService extends BrowserXhr
{
  private PATIENTS_API = 'http://localhost:8080/api/patients/';

  constructor (private http: Http, private router: Router) {
     super();
  }


  build(): any {
    let xhr = super.build();
    xhr.withCredentials = true;             // this is all the magic we need for now
    return <any>(xhr);
  }

  addPatient(patient: Patient):Promise<void | Patient>{
  	return this.http.post(this.PATIENTS_API, patient)
           .toPromise()
           .then(response => response.json() as Patient)
           .catch(this.handleError);
  }

  deletePatient(patientId:String): Promise<void | String> {
    return this.http.delete(this.PATIENTS_API+ patientId)
               .toPromise()
               .then(response => response.json() as String)
               .catch(this.handleError);
  }

  getPatientsForDropDown():Observable<Patient[]>{
    return this.http.get(this.PATIENTS_API+'all')
    .map((response: Response) => <Patient[]> response.json())
    .do(data => console.log('Final JSON' +JSON.stringify(data)));
  }

  getAllPatients():Observable<Patient[]>{
    return this.http.get(this.PATIENTS_API+'getall')
    .map((response: Response) => <Patient[]> response.json())
    .do(data => console.log('Final JSON' +JSON.stringify(data)));
  }


  getPatientById(_id:String):Observable<Patient>{

    return this.http.get(this.PATIENTS_API+_id)
    .map((response: Response) => <Patient> response.json())
    .do(data => console.log('Loading Patient from API ' +JSON.stringify(data)));
  }

  searchPatient(patientId:String):Observable<Patient>{
    return this.http.get(this.PATIENTS_API+'search/'+patientId)
    .map((response: Response) => <Patient> response.json())
    .do(data => console.log('Loading Searched Patient from API ' +JSON.stringify(data)));
  }

  private handleError (error: any) {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
  }

}
