// import {Component, OnInit} from "@angular/core";
// import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
// import {PouchDBService} from "./pouchdb.service";
// import {FormBuilder} from "@angular/forms";
// @Component({
//     template: `
//         <div class="modal-header">
//             <h4 class="modal-title">ICD-10 Code Selection &hellip;</h4>
//             <button type="button" class="close" aria-label="Close" (click)="close()">
//                 <span aria-hidden="true">&times;</span>
//             </button>
//         </div>
//         <div class="modal-body">
//             <div class="row">
//                 <div class="col-6">
//                     <label>ICD-10 Code:</label>
//                     <input type="text" [(ngModel)]="icdCode" (change)="detectAutofill(icdCode)" />
//                 </div>
//                 <div class="col-6">
//                     <ul class="inline-list">
//                         <li>
//                             <button class="btn btn-primary" (click)="finish()">Done</button>
//                         </li>
//                         <li>
//                             <button class="btn btn-secondary" (click)="clear()">Clear</button>
//                         </li>
//                         <li>
//                             <button class="btn btn-secondary" (click)="close()">Cancel</button>
//                         </li>
//                     </ul>
//                 </div>
//             </div>
//
//             <div class="row">
//                 <label class="col-3">Section:</label>
//                 <md-select class="col-9" [(ngModel)]="category" (change)="categoryChanged()">
//                     <md-option *ngFor="let cat of categories" [value]="cat">{{cat.Name}}</md-option>
//                 </md-select>
//             </div>
//             <div class="row" *ngIf="category">
//                 <label class="col-3">Category:</label>
//                 <md-select class="col-9" [(ngModel)]="subcategory" (change)="subcategoryChanged()">
//                     <md-option *ngFor="let cat of subcategories" [value]="cat">{{cat.Code}} - {{cat.Diag}}</md-option>
//                 </md-select>
//             </div>
//             <div class="row" *ngIf="subcategory">
//                 <label class="col-3">Subcategory:</label>
//                 <md-select class="col-9" [(ngModel)]="code" (change)="codeChanged()">
//                     <md-option *ngFor="let cod of codes" [value]="cod">{{cod.Code}} - {{cod.Diag}}</md-option>
//                 </md-select>
//             </div>
//             <div class="row" *ngIf="code && subcodes.length">
//                 <label class="col-3">Subclass:</label>
//                 <md-select class="col-9" [(ngModel)]="subcode" (change)="subcodeChanged()">
//                     <md-option *ngFor="let sub of subcodes" [value]="sub">{{sub.Code}} - {{sub.Diag}}</md-option>
//                 </md-select>
//             </div>
//
//         </div>
//         <div class="modal-footer">
//             <!--<button type="submit" class="btn btn-primary" (click)="close()">Done</button>-->
//         </div>
//     `
// })
// export class PatientDiagnosisModalComponent implements OnInit {
//     test;
//     info: any = {};
//     icdCode = '';
//     icdDiag = '';
//
//     category;
//     subcategory;
//     code;
//     subcode;
//
//     categories = [];
//     subcategories = [];
//     codes = [];
//     subcodes = [];
//
//     sources: any = {
//         'ARC_ICD_Category': 'categories',
//         'ARC_ICD_ICDCodes': 'codes'
//     }
//
//     private categories_key = '';
//     private codes_key = '';
//
//     constructor (
//         private activeModal: NgbActiveModal,
//         private fb: FormBuilder,
//         private pouchService: PouchDBService
//     ) { }
//
//     ngOnInit () {
//         this.pouchService.allDocs({include_docs:true, keys: Object.keys(this.sources)}).then(docs => {
//             console.log('loaded documents', docs);
//             for (let i = 0; i < docs.rows.length; i++) {
//                 let doc = docs.rows[i].doc;
//                 this.info[this.sources[doc._id]] = doc.items;
//             }
//
//             console.log('loaded info', this.info);
//
//             for (let i = 0; i < this.info.categories.length; i++) {
//                 let category = this.info.categories[i];
//                 if (+category.Status) {
//                     this.categories.push(category);
//                 }
//             }
//         });
//     }
//
//     detectAutofill(value) {
//         console.log('autofilling', value);
//         let cat;
//         if (cat = this.findCategoryFor(value)) {
//             console.log('Found category', cat);
//
//             this.category = cat;
//             this.categoryChanged(value);
//
//         } else {
//             console.error('Could not match category find for', value);
//         }
//     }
//
//     findCategoryFor (value) {
//         for (let i = 0; i < this.categories.length; i++) {
//             let cat = this.categories[i];
//             console.log('COMPARING WITH', cat);
//
//             if (+cat.StartRange <= +value && +cat.EndRange >= +value) {
//                 return cat;
//             }
//         }
//         return false;
//     }
//
//     categoryChanged (value = null) {
//         this.subcategory = null;
//         //  Table	Name	StartRange	EndRange	Status
//         this.subcategories = [];
//
//         let searchIndex = null;
//
//         console.log('CATEGORY SWITCHED', value);
//
//         for (let i = 0; i < this.info.codes.length; i++) {
//             let code = this.info.codes[i];
//             //code.Code >= this.category.StartRange && code.Code <= this.category.EndRange
//             if(code.Table === this.category.Table && +code.Level === 0 && +code.Status) {
//                 let nextIndex = this.subcategories.push(code);
//
//                 // console.log('ADDING CATEGORY', code, nextIndex);
//
//                 if (value && value.indexOf(code.Code) === 0) {
//                     console.log('SETTING CODE at INDEX', nextIndex);
//                     searchIndex = nextIndex - 1;
//                     this.subcategory = this.subcategories[searchIndex];
//                     this.icdCode = this.subcategories[searchIndex].Code;
//                     this.icdDiag = this.subcategories[searchIndex].Diag;
//                     this.subcategoryChanged(value);
//                     //break;
//                 }
//
//             }
//         }
//
//         if(searchIndex === null) {
//             this.icdCode = this.subcategories[0].Code;
//             this.icdDiag = this.subcategories[0].Diag;
//         }
//
//         // Code	Table	Diag	Status	Level
//
//     }
//
//     subcategoryChanged (value = null) {
//         this.code = null;
//         this.codes = [];
//         this.icdCode = this.subcategory.Code;
//         this.icdDiag = this.subcategory.Diag;
//         console.log('subcat changed', this.subcategory);
//         for (let i = 0; i < this.info.codes.length; i++) {
//             let code = this.info.codes[i];
//             if(code.Code >= this.subcategory.Code && code.Code < this.subcategory.Code + 1 && +code.Level === 1 && +code.Status) {
//                 let nextIndex = this.codes.push(code);
//
//                 if (value && value.indexOf(code.Code) === 0) {
//                     console.log('SETTING CODE at INDEX', nextIndex);
//                     this.code = this.codes[nextIndex - 1];
//                     this.icdCode = this.codes[nextIndex - 1].Code;
//                     this.icdDiag = this.codes[nextIndex - 1].Diag;
//                     this.codeChanged(value);
//                     //break;
//                 }
//             }
//         }
//
//         // Code	Table	Diag	Status	Level
//
//     }
//
//     codeChanged (value) {
//         this.subcodes = [];
//         this.subcode = null;
//         this.icdCode = this.code.Code;
//         this.icdDiag = this.code.Diag;
//
//         for (let i = 0; i < this.info.codes.length; i++) {
//             let code = this.info.codes[i];
//             if(code.Code >= this.code.Code && code.Code < this.code.Code + 0.1 && +code.Level === 2 && +code.Status) {
//                 let nextIndex = this.subcodes.push(code);
//
//                 if (value && value.indexOf(code.Code) === 0) {
//                     console.log('SETTING CODE at INDEX', nextIndex);
//                     this.subcode = this.subcodes[nextIndex - 1];
//                     this.icdCode = this.subcodes[nextIndex - 1].Code;
//                     this.icdDiag = this.subcodes[nextIndex - 1].Diag;
//                     this.subcodeChanged();
//                     //break;
//                 }
//             }
//         }
//
//         // if (this.subcodes.length) {
//         //     console.log('subcodes exist!', this.subcodes);
//         //     this.subcode = this.codes[0];
//         //     this.subcodeChanged();
//         // } else {
//         // }
//     }
//
//     subcodeChanged () {
//         this.icdCode = this.subcode.Code;
//         this.icdDiag = this.subcode.Diag;
//
//         // console.log('setting icdC');
//
//     }
//
//     finish () {
//         this.activeModal.close({code: this.icdCode, diag: this.icdDiag});
//     }
//
//     clear () {
//         this.activeModal.close(null);
//     }
//
//     close () {
//         this.activeModal.close(false);
//     }
//
// }
