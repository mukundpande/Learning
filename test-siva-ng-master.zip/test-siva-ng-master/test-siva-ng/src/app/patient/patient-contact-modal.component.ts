import {Component} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import {FormBuilder} from "@angular/forms";
@Component({
    templateUrl: './patient-contact-modal.component.html',
    styles: [`
        .graybox {
            background: #ccc;
            border:1px outset #ccc;
        }
        .act-button-list li button {
            font-size:12px;
        }
        label {
            text-align:right;
            font-weight:bold;
            font-size:12px;
        }
    `]
})
export class PatientContactModalComponent {
    contactType;
    contactIndex = 0;
    contact;
    contacts = [];

    searchContacts;

    searchMode = false;
    addMode = false;

    constructor (
        private activeModal: NgbActiveModal,
        private fb: FormBuilder,
        private pouchService: PouchDBService
    ) { }

    contactForm = this.fb.group({
        Address: [''],
        City: [''],
        Comment: [''],
        Fax: [''],
        FedTaxID: [''],
        Name: [''],
        OtherInfo: [''],
        OtherName: [''],
        Phone: [''],
        Representative: [''],
        State: [''],
        Type: [''],
        Zip: [''],
    });

    getContacts () {
        return this.searchContacts ? this.searchContacts : this.contacts;
    }

    outOfNormalMode () {
        return this.searchMode || this.addMode;
    }

    checkForChanges () {
        if (this.contactForm.dirty && confirm('Save changes?')) {
            for (let x in this.contactForm.value) {
                if (true) {
                   this.contact[x] = this.contactForm.value[x];
                }
            }

            this.pouchService.put(this.contact._id, this.contact).then(res => {
                console.log('EDITS SAVED -- ', this.contact);
            })
        }
    }

    open (type, id = null) {
        this.contactType = type;
        let prefix = 'CONTACT_' + type + '_';

        let time = new Date().getTime();

        console.log('Requesting key', prefix, time);

        this.pouchService.allDocs({
            include_docs:true,
            startkey: prefix,
            endkey: prefix + '\uffff'
        }).then(res => {
            console.log('loading contacts', res, new Date().getTime());
            this.contacts = [];
            for(let i = 0; i < res.rows.length; i++) {
                this.contacts.push(res.rows[i].doc);

                if (res.rows[i].doc._id.substr(prefix.length) === id) {
                    this.contactIndex = i;
                }
            }
            this.loadContact();
        }).catch(err => { console.error('CONTACT MODAL -- could not pull ', type, err);});
    }

    gotoFirst () {
        this.contactIndex = 0;
        this.checkForChanges();
        this.loadContact();
    }

    gotoLast () {
        this.contactIndex = this.contacts.length-1;
        this.checkForChanges();
        this.loadContact();
    }

    stepBack () {
        this.contactIndex = Math.max(this.contactIndex-1, 0);
        this.checkForChanges();
        this.loadContact();
    }

    stepForward () {
        this.contactIndex = Math.min(this.contactIndex+1, this.contacts.length-1);
        this.checkForChanges();
        this.loadContact();
    }

    loadContact () {
        if (!this.contacts.length) {
            return;
        }

        this.contact = this.contacts[this.contactIndex];
        this.contactForm.reset(this.contact);
        // this.contactForm.patchValue();
    }

    cancel () {
        if(this.searchMode) {
            this.searchMode = false;
            this.loadContact();
        } else if(this.addMode) {
            this.addMode = false;
            this.loadContact();
        } else {
            this.activeModal.close(false);
        }
    }


    populateCustomField () {
        this.contactForm.patchValue({
            Employer: 'Work Comp. Carrier', Physician: 'Prof. License #', Insurance: 'Insurer ID#',
            Attorney: 'Prof. License #', Spare: ''
        }[this.contactType]);
    }

    confirm () {

        if(this.searchMode) {
            this.searchContacts = [];
            let searchTerms = {};

            console.log('grabbing parameters from', this.contactForm.value);

            for (let x in this.contactForm.value) {
                if (this.contactForm.value[x] && this.contactForm.value[x].length) {
                    searchTerms[x] = this.contactForm.value[x];
                }
            }
            console.log('searching for', searchTerms);

            for (let i = 0; i < this.contacts.length; i++) {
                let passes = true;

                console.log('testing', this.contacts[i]);

                for (let x in searchTerms) {
                    if(searchTerms[x] !== this.contacts[i][x].substr(0,searchTerms[x].length)) {
                        console.log('search failed for ', this.contacts[i].Name,
                            'because', searchTerms[x], 'does not match',
                            this.contacts[i][x].substr(0,searchTerms[x].length));
                        passes = false;
                        break;
                    }
                }

                if (passes) {
                    this.searchContacts.push(this.contacts[i]);
                }

            }
            this.contactIndex = 0;

            this.searchMode = false;
            this.loadContact();
        } else if(this.addMode) {
            let nextId = 0;
            let prefix = 'CONTACT_' + this.contactType + '_';
            //add to index?
            for (let i = 0; i < this.contacts.length; i++) {
                let number = this.contacts[i]._id.substr(prefix.length);
                if (number > nextId) {
                    nextId = number;
                }
            }

            this.contact = this.contactForm.value;

            this.contact._id = prefix + (nextId+1);

            console.log('Adding contact ', this.contact);

            this.pouchService.put(this.contact._id, this.contact).then( res => {
                console.log('NEW CONTACT ADDED', res);
                let newLength = this.contacts.push(this.contact);
                this.searchContacts = null;
                this.contactIndex = newLength - 1;
                this.loadContact();
            }).catch(err => {
                console.error('CANNOT ADD CONTACT', err);
            })

            this.addMode = false;


            //this.loadContact();
        } else {

            this.pouchService.put(this.contact._id, this.contact).then( () => {
                console.log('CONTACT SAVED -- ', this.contact);
            });
            this.checkForChanges();

            this.activeModal.close(this.contact);
        }
    }

    add () {
        this.addMode = true;
        this.contactForm.reset({});
        this.populateCustomField();
    }

    search () {
        this.searchMode = true;
        this.contactForm.reset({});
        this.populateCustomField();
    }

    delete (contact) {

    }

    removeRecord (contact) {

    }

    close () {
        this.activeModal.close(true);
    }

}
