import {Component, OnInit} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import * as JSZip from 'jszip';
import * as Docxtemplater from 'docxtemplater';
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ErrorDisplayModalComponent} from "../utils/error-display-modal.component";

import * as FileSaver from 'file-saver';

@Component({
    template: `
        <div class="container white" *ngIf="reports">
            <h2>Change Report Templates</h2>
            <div class="row" *ngIf="reports">
                <div class="col-6" align="center" *ngFor="let i of ['main', 'tech']">
                    Replace {{ i.toUpperCase() }}
                    <br/>
                    {{ reports[i].file }}
                    <input type="file" (change)="readWordUpload($event, i)" style="width:100%;" />

                    <button (click)="save(i)" class="btn btn-block btn-success">

                        Save
                    </button>
                    <button (click)="test(i)" class="btn btn-block btn-primary">
                        Test
                    </button>
                    <button (click)="download(i)" class="btn btn-block btn-success">

                        Download
                    </button>
                </div>
            </div>


            <br/><hr/><br/>

        </div>
    `
})
export class MainReportEditorComponent implements OnInit {
    reportSources = {
        'ARC_REPORTS_MainReport' : 'main',
        'ARC_REPORTS_TechReport' : 'tech',
    }

    reports;

    constructor (private pouchService: PouchDBService, private modalService: NgbModal) {}

    ngOnInit () {


        this.pouchService.allDocs({keys: Object.keys(this.reportSources), include_docs: true, attachments: true}).then(res => {
            let reports = {};
            for(let i = 0; i < res.rows.length; i++) {
                let row = res.rows[i];
                console.log('row', row);
                reports[this.reportSources[row.key]] = row.doc || {_id: row.key};
            }
            this.reports = reports;
        }).catch(err => {
            console.error('Cannot open because', err);
        });
    }

    download (type) {
        let attachment = this.reports[type]._attachments[this.reports[type].file];
        let blob = new Blob([this.attachmentToBlob(attachment)], {type: attachment.content_type});
        // console.log('saving blob', {blob: blob, attachment: attachment});
        FileSaver.saveAs(blob,"report-" + type + ".docx");
    }

    test (type) {
        let attachment = this.reports[type]._attachments[this.reports[type].file];
        let zip = new JSZip(this.attachmentToBlob(attachment));

        let doc = new Docxtemplater();
        doc.loadZip(zip);

        doc.setData({
            name: 'Test',
            a: [
                {b: 'A', c: '1'},
                {b: 'B', c: '2'},
                {b: 'C', c: '3'},
            ]
        });

        try {
            // render the document (replace all occurences of {first_name} by John, {last_name} by Doe, ...)
            doc.render()
        }
        catch (error) {
            let e = {
                message: error.message,
                name: error.name,
                stack: error.stack,
                properties: error.properties,
            }
            console.log({error: e});

            let errors = [];

            if (error.properties.errors) {

                for(let i = 0; i < error.properties.errors.length; i++) {
                    let err = error.properties.errors[i];
                    errors.push(err.properties.explanation);
                }
            } else {
                let thing:any = error.properties.parsed[error.properties.index];
                errors.push(error.properties.explanation + ' (at '+thing.type+' '+thing.module+' '+thing.location+' '+thing.value+')');
            }


            const modal = this.modalService.open(ErrorDisplayModalComponent);

            modal.componentInstance.setError('Could not run template. Please check the tags and try again.');
            modal.componentInstance.setReasons(errors);
            // The error thrown here contains additional information when logged with JSON.stringify (it contains a property object).
            throw error;
        }

        let buf = doc.getZip()
            .generate({type: 'nodebuffer'});


        console.log('buffer returned', buf);

        let blob = new Blob([buf], {type: attachment.content_type});
        FileSaver.saveAs(blob,"report.docx");

    }


    attachmentToBlob (a) {
        //data, content_type

        let byteString = atob(a.data);
        let mimeString = a.content_type;
        let ab = new ArrayBuffer(byteString.length);
        let ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        return ia;
        // let blob = new Blob([ab], {type: mimeString});
        // console.log('new blob', mimeString, blob);
        // return blob;
    }

    dataURItoBlob(dataURI) {
        // convert base64 to raw binary data held in a string
        // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
        let byteString = atob(dataURI.split(',')[1]);

        // separate out the mime component
        let mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
        let ab = new ArrayBuffer(byteString.length);
        let ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        let blob = new Blob([ab], {type: mimeString});
        return blob;

    }

    readWordUpload($event, type) {
        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        // let fileType = $event.target.parentElement.id;
        if(!file) {
            return;
        }

        fr.onloadend = (end) => {
            let result = fr.result.split('base64,')[1];
            console.log('FINISHED', fr.result.split('base64,')[0] + 'base64,', file, result.length);
            this.reports[type]._attachments = {};
            delete this.reports[type].template;
            // this.patientForm.patchValue({'Photo':file.name});
            this.reports[type]._attachments[file.name] = {
                content_type: file.type,
                data: result
            };

            this.reports[type].file = file.name;
        };
        // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        fr.readAsDataURL(file);
    }

    save(type) {
        console.log('saving', this.reports[type]);
        let keys = Object.keys(this.reportSources);
        for (let i = 0; i < keys.length; i++) {
            if (this.reportSources[keys[i]] === type) {
                // alert('Saving ' + keys[i]);
                this.pouchService.put(keys[i], this.reports[type]).then(res => {
                    console.log('Saved', res);
                    alert('Updated ' + type + ' report template.');
                });
            }
        }


    }
}
