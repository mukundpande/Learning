import {Component, ViewChild} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import * as jsPDF from 'jspdf';
import * as htmlDocx from 'html-docx-js/dist/html-docx.js';
import * as FileSaver from 'file-saver';
import * as html2pdf from "assets/scripts/html2pdf.js"
import * as html2canvas from "html2canvas/dist/html2canvas"
import {WpiService} from "../services/wpi.service";
import {Http, ResponseContentType} from "@angular/http";
import 'rxjs/add/operator/toPromise';
import {FooterContextService} from "../services/footer-context.service";

// this should be fine now

@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Preparing Graph Images</h4>
            <!--<button type="button" class="close" aria-label="Close" (click)="close()">-->
                <!--<span aria-hidden="true">&times;</span>-->
            <!--</button>-->
        </div>
        <div class="modal-body">
            <canvas #canvas width="380" height="380"></canvas>
            <div  style="height:100px; overflow-y: scroll;" *ngIf="reportService">
                <div *ngFor="let chart of charts; let i = index;" [style.height]="chart.height + 'px'" [style.width]="chart.width + 'px'">
                    <canvas baseChart
                            [datasets]="chart.data"
                            [labels]="chart.labels"
                            [options]="chart.options"
                            [colors]="chart.colors"
                            [legend]="chart.legend"
                            [chartType]="chart.type"></canvas>
                </div>


                <!--(chartHover)="chartHovered($event)"-->
                <!--(chartClick)="chartClicked($event)"-->

            </div>
        </div>
        <div class="modal-footer">
            Please wait while graphs are prepared for your report.
            <!--<button type="submit" [disabled]="loading" class="btn btn-secondary" (click)="close()">Done</button>-->
        </div>
    `,
    styles: [`
        .top-header-row {
            background: dodgerblue;
            font-size:16px;
        }
        .header-row,
        .top-header-row {
            font-weight:bold;
            text-align:center;
        }
    `]
})
export class ReportGraphPrepComponent {
    type;
    selected;
    loading;
    reportService;
    charts = [];
    finished = 0;

    @ViewChild('content') content: any;
    @ViewChild('canvas') canvas;
    constructor (
        private activeModal: NgbActiveModal,
        private http: Http,
        private pouchService: PouchDBService,
        private wpiService: WpiService,
        // private footerContext: FooterContextService
    ) { }

    done (tag, a, isArray = false, name = '') {
        let obj = {
            data: atob(a.chart.canvas.toDataURL('image/png').split(',')[1]),
            width: a.chart.width,
            height: a.chart.height
        };


        if(isArray) {
            if (this.reportService.info[tag] === undefined) {
                console.error('Missing Graphs item', tag);
            }
            this.reportService.info[tag].push({
                title: name,
                chart: obj
            });
        } else {
            this.reportService.info[tag] = obj;
        }

        this.finished++;
        if (this.finished >= this.charts.length) {
            this.activeModal.close(true);
        }
    }

    promisePainImageGenerated () {
        let res, rej;
        let prom = new Promise((r,j)=>{res=r;rej=j})

        let context: CanvasRenderingContext2D  = this.canvas.nativeElement.getContext('2d');
        let imageObj = new Image();
        imageObj.onload = () => {
            context.drawImage(imageObj, 0, 0);
            context.font = '12px Arial';
            context.fillStyle = 'red';

            for (let i = 0; i < this.reportService.info.painPoints.length; i++) {
                let pt = this.reportService.info.painPoints[i];
                context.font = '12px Arial';
                context.fillStyle = 'red';
                context.fillText(pt.type, pt.x, pt.y);
            }

            let image = this.canvas.nativeElement.toDataURL('image/gif').split(',');

            console.log('CREATED CANVAS IMAGE', image);

            this.reportService.info.pain = {
                data: atob(image[1]),
                width: 300,
                height: 300
            };
            res(true);
        };
        imageObj.src = '/assets/images/pain.png';

        return prom;
    }

    load (reportService, type = 'main') {
        this.finished = 0;
        this.reportService = reportService;

        this.type = type;

        // alert('PREPARATION WAS CALLED FOR TYPE : ' + type);
        console.log('-- reportService loaded', reportService, 'TYPE OF REPORT', type);

        let isMain = type === 'main';

        this.promisePainImageGenerated().then( () => {
            for (let i = 0; i < this.reportService.info.st_table.length; i++) {
                let st = this.reportService.info.st_table[i];
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [st.n1] : [st.n1, st.n2, st.n3],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('st_graphs', a, true, st.name)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }

            for (let i = 0; i < this.reportService.info.hd_table.length; i++) {
                let hd = this.reportService.info.hd_table[i];
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [hd.n1] :[hd.n1, hd.n2, hd.n3],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('hd_graphs', a, true, hd.name)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }

            for (let i = 0; i < this.reportService.info.pg_table.length; i++) {
                let pg = this.reportService.info.pg_table[i];
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [pg.n1] :[pg.n1, pg.n2, pg.n3],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('pg_graphs', a, true, pg.name)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }

            for (let i = 0; i < this.reportService.info.cx_table.length; i++) {
                let cx = this.reportService.info.cx_table[i];
                if (!cx.notBilateral) {
                    this.charts.push({
                        width: 150,
                        height: 100,
                        data: [{
                            label: 'Trials',
                            data: isMain ? [cx.n1L] :[cx.n1L, cx.n2L, cx.n3L],
                            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                        }],
                        labels: isMain ? ['1'] : ['1','2','3'],
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            bezierCurve : false,
                            animation: {
                                duration: 0,
                                onComplete: (a) => {
                                    this.done('cx_graphs', a, true, cx.name)
                                }
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    }
                                }]
                            }
                        },
                        colors: [{
                            // backgroundColor: 'rgba(0,255,255,1)',
                            // borderColor: 'rbga(0,255,25,1)'
                        }],
                        legend: false,
                        type: 'bar'
                    });
                } else {
                    this.charts.push({
                        width: 150,
                        height: 100,
                        data: [{
                            label: 'Trials',
                            data: isMain ? [cx.n1L] :[cx.n1L, cx.n2L, cx.n3L],
                            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                        }],
                        labels: isMain ? ['1'] : ['1','2','3'],
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            bezierCurve : false,
                            animation: {
                                duration: 0,
                                onComplete: (a) => {
                                    this.done('cx_graphs', a, true, cx.name + ' (L)')
                                }
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    }
                                }]
                            }
                        },
                        colors: [{
                            // backgroundColor: 'rgba(0,255,255,1)',
                            // borderColor: 'rbga(0,255,25,1)'
                        }],
                        legend: false,
                        type: 'bar'
                    });

                    this.charts.push({
                        width: 150,
                        height: 100,
                        data: [{
                            label: 'Trials',
                            data: isMain ? [cx.n1R] :[cx.n1R, cx.n2R, cx.n3R],
                            backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                        }],
                        labels: isMain ? ['1'] : ['1','2','3'],
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            bezierCurve : false,
                            animation: {
                                duration: 0,
                                onComplete: (a) => {
                                    this.done('cx_graphs', a, true, cx.name + ' (R)')
                                }
                            },
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    }
                                }]
                            }
                        },
                        colors: [{
                            // backgroundColor: 'rgba(0,255,255,1)',
                            // borderColor: 'rbga(0,255,25,1)'
                        }],
                        legend: false,
                        type: 'bar'
                    });
                }
            }

            for (let i = 0; i < this.reportService.info.rm_table.length; i++) {
                let rm = this.reportService.info.rm_table[i];
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [rm.n1] :[rm.n1, rm.n2, rm.n3],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('rm_graphs', a, true, rm.name)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }

            for (let i = 0; i < this.reportService.info.eg_table.length; i++) {
                let eg = this.reportService.info.eg_table[i];
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [eg.n1L] :[eg.n1L, eg.n2L, eg.n3L],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('eg_graphs', a, true, eg.name + ' (L)')
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
                this.charts.push({
                    width: 150,
                    height: 100,
                    data: [{
                        label: 'Trials',
                        data: isMain ? [eg.n1R] :[eg.n1R, eg.n2R, eg.n3R],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: isMain ? ['1'] : ['1','2','3'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('eg_graphs', a, true, eg.name + ' (R)')
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }

            this.charts.push({
                width: 400,
                height: 300,
                data: [{
                    label: 'Trial 1',
                    data: [100, 100],
                },{
                    label: 'Trial 2',
                    data: [150, 150],
                },{
                    label: 'Trial 3',
                    data: [125, 125],
                }],
                labels: ['Trial', 'Trial'],
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    bezierCurve : false,
                    animation: {
                        duration: 0,
                        onComplete: (a) => {
                            this.done('image', a)
                        }
                    }
                },
                colors: [{
                    backgroundColor: 'rgba(255,0,255,.1)',
                    borderColor: 'rbga(255,0,255,1)',
                }, {
                    backgroundColor: 'rgba(255,255,0,.1)',
                    borderColor: 'rbga(255,255,0,1)'
                }, {
                    backgroundColor: 'rgba(0,255,255,.1)',
                    borderColor: 'rbga(0,255,25,1)'
                }],
                legend: true,
                type: 'line'
            });

            if(this.reportService.info.hd.P1L &&
                this.reportService.info.hd.SL &&
                this.reportService.info.hd.P3L &&
                this.reportService.info.hd.P4L &&
                this.reportService.info.hd.P5L ) {

                this.charts.push({
                    width: 200,
                    height: 105,
                    data: [{
                        label: 'Strengths',
                        data: [
                            this.reportService.info.hd.P1L.n,
                            this.reportService.info.hd.SL.n,
                            this.reportService.info.hd.P3L.n,
                            this.reportService.info.hd.P4L.n,
                            this.reportService.info.hd.P5L.n
                        ],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: ['1', '2', '3', '4', '5'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('hdlh', a)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });

                this.charts.push({
                    width: 200,
                    height: 105,
                    data: [{
                        label: 'Strengths',
                        data: [
                            this.reportService.info.hd.P1R.n,
                            this.reportService.info.hd.SL.n,
                            this.reportService.info.hd.P3R.n,
                            this.reportService.info.hd.P4R.n,
                            this.reportService.info.hd.P5R.n
                        ],
                        backgroundColor: ['#f0f','#ff0','#0ff','#f00','#0f0','#00f']
                    }],
                    labels: ['1', '2', '3', '4', '5'],
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        bezierCurve : false,
                        animation: {
                            duration: 0,
                            onComplete: (a) => {
                                this.done('hdrh', a)
                            }
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    },
                    colors: [{
                        // backgroundColor: 'rgba(0,255,255,1)',
                        // borderColor: 'rbga(0,255,25,1)'
                    }],
                    legend: false,
                    type: 'bar'
                });
            }
        })
    }

    close () {
        this.activeModal.close(true);
    }

}
