import {ApplicationRef, Component, OnDestroy, OnInit} from "@angular/core";
import {FooterContextService} from "../services/footer-context.service";
import {PouchDBService} from "../services/pouchdb.service";
import {Router} from "@angular/router";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ReportExportModalComponent} from "./report-export-modal.component";
import {ReportService} from "./report.service";

@Component({
    template: `
        <div class="container white">
            <h3>Select Test to Report <small>(* indicates incomplete test)</small></h3>

            <ngx-datatable
                    [rows]="series"
                    class="material"
                    [limit]="20"
                    [columnMode]="'force'"
                    [headerHeight]="50"
                    [footerHeight]="50"
                    [rowHeight]="'auto'"
                    [selected]="selected"
                    [selectionType]="'multiClick'"
                    (activate)="onActivate($event)"
                    (select)='onSelect($event)'
                    [reorderable]="false">
                <ngx-datatable-column name="Patient ID #" prop="patientId"></ngx-datatable-column>
                <ngx-datatable-column name="Test Date - Time" prop="datetime">
                    <ng-template ngx-datatable-cell-template let-value="value" let-row="row">
                        {{ value | date : 'MM/dd/yy - HH:mm' }}
                    </ng-template>
                </ngx-datatable-column>
                <ngx-datatable-column name="*">
                    <ng-template ngx-datatable-cell-template let-value="value" let-row="row">
                        <span *ngIf="row.testsAvailable > row.testsCompleted">*</span>
                    </ng-template>
                </ngx-datatable-column>
                <ngx-datatable-column name="Test Name" prop="protocol.Name"></ngx-datatable-column>
                <ngx-datatable-footer>

                    <div class="row">
                        <div class="col-4">
                            Results for Patient:
                        </div>
                        <input type="text" class="form-control col-4" [value]="" readonly />

                    </div>

                </ngx-datatable-footer>
            </ngx-datatable>
        </div>
    `
})
export class ReportsComponent implements OnInit, OnDestroy {
    series = [];
    selected = [];
    listener;

    constructor (
        private footerContext: FooterContextService,
        private modalService: NgbModal,
        private pouchService: PouchDBService,
        private router: Router,
        private reportService: ReportService,
        private appRef: ApplicationRef
    ) {}

    ngOnDestroy () {
        console.log('should destroy', this.listener);
        // this.listener();
        //getFooterContext().patient.Id
    }

    getFooterContext() {
        return this.footerContext;
    }

    ngOnInit () {

        // console.log('activating reports view');
        // this.listener = this.footerContext.activateReports().subscribe( call => {
        //
        //     if (!this.selected.length) {
        //         alert('Please select at least one test before continuing.');
        //         return;
        //     }
        //
        //     if(['main','tech','custom'].indexOf(call) === -1) {
        //         throw 'Invalid call: ' + call;
        //     }
        //
        //     this.footerContext.freezeReports();
        //     this.appRef.tick();
        //     this.reportService.generateReportFile(call, this.selected, this.footerContext.patient).then( res => {
        //         this.footerContext.unfreezeReports();
        //     });
        // });
        this.loadSeries();
    }

    loadSeries () {
        this.series = [];
        var protocol={
          patientId:'1234',
          datetime:'03/04/2018',
          protocol:{
            Name:'Sample Test'
          }
        }
        this.series.push(protocol);
        // this.pouchService.allDocs({
        //     include_docs: true,
        //     startkey: 'PATSERIES_' + this.footerContext.patient._id + '_',
        //     endkey: 'PATSERIES_' + this.footerContext.patient._id + '_\uFFFF'
        // }).then( res => {
        //     console.log('returned series', res);
        //     for (let i = 0; i < res.rows.length; i++) {
        //         res.rows[i].doc.testsAvailable = Object.keys(res.rows[i].doc.tests).length;
        //         this.series.push(res.rows[i].doc);
        //     }
        // });
    }

    onSelect({ selected }) {
        console.log('Select Event', selected, this.selected);

        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);

        //this.activateMainButtons();
    }

    onActivate(event) {
        console.log('Activate Event', event);
    }
}
