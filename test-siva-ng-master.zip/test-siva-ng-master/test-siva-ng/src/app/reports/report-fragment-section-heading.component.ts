import {Component} from "@angular/core";
@Component({
    selector: 'report-header',
    template: `
        <div align="center">
            <table width="100%">
                <tr>
                    <td style="background-color: #ff7f00; border: 1px solid #000000; text-align: center; 
            border-width: 1px 1px 1px 1px; font-size: 10px; font-family: Arial; font-weight: bold; 
  color: black; vertical-align: middle">
                        <ng-content></ng-content>
                    </td>
                </tr>
            </table>
        </div>
    `
})
export class ReportFragmentSectionHeadingComponent {}