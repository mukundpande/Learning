import {Component} from "@angular/core";
@Component({
    selector: 'explanation-static-strength',
    template: `
        <report-header>Functional Evaluation Testing of FL - Static Strength Report</report-header>

        <p>
            The patient was evaluated using the Functional Evaluation Testing of FL static strength testing system.
            This system is designed to quantify an individual’s ability to lift, push, or pull in various postures and to
            compare strength to norms adopted by the U. S. Dept. of Health and Human Services,
            National Institute for Occupational Safety and Health (NIOSH).
        </p>

        <p>
            The results of this test will unequivocally give an indication of the patient’s performance deficiencies.
            With the objective information provided in the report, the treating physician can assess, upgrade and/or
            monitor the patient’s rehabilitation goals. The results of the later testing will document any progress or
            continued deficiencies in the patient's lifting capabilities. A Coefficient of Variation (CV) and/or difference
            between successive reps of 15% or less indicates validity, reproducibility, and consistency of effort.
        </p>

        <p>
            The report compares the patients test results with normative standards to compute an impairment percentage.
            This information is used to help establish the patients impairment rating which is expressed as a percentage
            of whole person impairment/improvement. Follow-up testing is clinically recommended for patients whose results
            show a deficit between the normal and abnormal side.
            The results of the later test will documents any progress or continued deficiencies.
        </p>

        <table border="0">
            <tr>
                <td>Arm Lift:</td>
                <td>This test primarily stresses the elbows and upper back musculature.</td>
            </tr>
            <tr>
                <td>Leg Lift:</td>
                <td>This test primarily stresses the knees and the upper thigh musculature.</td>
            </tr>
            <tr>
                <td>Torso Lift:</td>
                <td>This test primarily stresses the lower back musculature. </td>
            </tr>
            <tr>
                <td>Floor Lift:</td>
                <td>This test primarily stresses the hip, back, and leg extensor musculature.</td>
            </tr>
            <tr>
                <td>High Near Lift:</td>
                <td>This test primarily stresses the shoulder & lower cervical spine musculature.</td>
            </tr>
            <tr>
                <td>High Far Lift:</td>
                <td>This test primarily stresses the shoulder and upper back musculature.</td>
            </tr>
        </table>
    `
})
export class ReportFragmentExplanationStaticStrengthComponent {}