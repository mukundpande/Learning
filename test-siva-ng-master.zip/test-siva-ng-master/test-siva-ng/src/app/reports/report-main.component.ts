import {Component, Input, OnInit, ViewChild} from "@angular/core";
import {DomSanitizer} from "@angular/platform-browser";
import {Http, ResponseContentType} from "@angular/http";
import 'rxjs/add/operator/toPromise';
import {ReportService} from "./report.service";
import {WpiService} from "../services/wpi.service";

@Component({
    selector: 'report-main',
    templateUrl: './report-main.component.html',
    styleUrls: ['./report-main.component.css']
})
export class ReportMainComponent implements OnInit {
    constructor (private dom: DomSanitizer, private http: Http, private reportService: ReportService, private wpiService: WpiService) { }
    css = {
        tableContainer: `margin-bottom: 16px;`,
        table: `
            margin: 0px; padding: 0px; box-shadow: 10px 10px 5px #888888; border: 1px solid #000000;

        `, // width: 100%;
//         -moz-border-radius-bottomleft: 0px; -webkit-border-bottom-left-radius: 0px; border-bottom-left-radius: 0px;
// -moz-border-radius-bottomright: 0px; webkit-border-bottom-right-radius: 0px; border-bottom-right-radius: 0px;
// -moz-border-radius-topright: 0px; -webkit-border-top-right-radius: 0px; border-top-right-radius': 0px;
// -moz-border-radius-topleft: 0px; -webkit-border-top-left-radius: 0px; border-top-left-radius: 0px
        header_cell: `
            background-color: #ff7f00; border: 1px solid #000000; text-align: center;
            border-width: 1px 1px 1px 1px; font-size: 14px; font-family: Arial; font-weight: bold;
            color: black; vertical-align: middle;
            ` //line-height: 15px;padding: 3px;
        ,
        table_cell: `
            vertical-align: middle;
            border: 1px solid #000;
            text-align: left;
            font-size: 11px;
            font-family: Arial;
            font-weight: normal;
            color: black;
            padding-left:3px;
        `,
        table_row_odd: `
            background-color: #ffaa56;
        `,
        table_row_even: `
            background-color: #fff;
        `,
        test: 'width:45%;',
        section_header: `width:100%;padding:5px; border:1px solid black; background: #ff7f00; font-weight:bold;`
    }

    pat = {
        name: 'Example Name'
    }
    tests = {
        taken: 0,
        total: 0
    }
    taken = {
        tests: 5
    };
    total = {
        tests: 6
    }
    lname = {
        doc: 'Dr. Fumbles'
    }
    doc = {
        name: 'Dr. Filler'
    }

    template;

    info: any = {};
    @Input() test;

    ngOnInit () {
        // this.reportService.promiseDataLoaded(this.test).then(info => this.info=info);
    }

    images = {}

    @ViewChild('content') content: any;
    //
    // getTemplate () {
    //     if(this.template) {
    //         return this.template;
    //     }
    //
    //     this.template = '';
    //
    //     this.reportService.promiseMainTemplate().then(template => {
    //         this.template = this.dom.bypassSecurityTrustHtml(template);
    //     })
    //
    // }

    getContent () {
        return this.content.nativeElement.innerHtml;
    }

    getCss(x) {
        // console.log('aaaa', this.dom.bypassSecurityTrustStyle(x));
        return this.dom.bypassSecurityTrustStyle(x);
    }

    getUrl(x){
        if(this.images[x]) {
           return this.dom.bypassSecurityTrustResourceUrl(this.images[x]);
        }

        this.images[x] = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

        this.http.get(x, {
            responseType: ResponseContentType.Blob
        }).toPromise().then(res => {
            // console.log('response given for img', res);
            var a = new FileReader();
            a.onload = (e:any) => {
                // console.log('FR', e.target.result);
                this.images[x] = e.target.result;
            }
            a.readAsDataURL(res.blob());
        })

        return this.dom.bypassSecurityTrustResourceUrl(this.images[x]);
    }
    generateImageSrc () {
        return this.dom.bypassSecurityTrustUrl('data:' + this.info.patient._attachments[this.info.patient.Photo].content_type + ';base64,' + this.info.patient._attachments[this.info.patient.Photo].data);
    }
}
