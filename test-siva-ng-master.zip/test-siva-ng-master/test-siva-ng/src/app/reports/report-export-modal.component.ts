import {Component, ViewChild} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "../services/pouchdb.service";
import * as jsPDF from 'jspdf';
import * as htmlDocx from 'html-docx-js/dist/html-docx.js';
import * as FileSaver from 'file-saver';
import * as html2pdf from "assets/scripts/html2pdf.js"
import * as html2canvas from "html2canvas/dist/html2canvas"
import {WpiService} from "../services/wpi.service";
import {Http, ResponseContentType} from "@angular/http";
import 'rxjs/add/operator/toPromise';

// this should be fine now

@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">Save Report as Document / PDF</h4>
            <button type="button" class="close" aria-label="Close" (click)="close()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div  style="height:400px; overflow-y: scroll;">

                <ng-container [ngSwitch]="type">
                    <report-tech #content [test]="selected" *ngSwitchCase="'tech'"></report-tech>
                    <report-main #content [test]="selected" *ngSwitchDefault></report-main>
                </ng-container>
            </div>
        </div>
        <div class="modal-footer">
            <small>
                Online connection required to export files.
            </small>


            <span *ngIf="loading">Processing... Please wait...</span>

            <button type="button" [disabled]="loading" (click)="saveAsWord()" class="btn btn-primary">
              
                    Save as Word Document
            </button>
            <button type="button" [disabled]="loading" (click)="saveAsPdf()" class="btn btn-primary">
                 PDF
            </button>


            <button type="submit" [disabled]="loading" class="btn btn-secondary" (click)="close()">Done</button>
        </div>
    `,
    styles: [`
        .top-header-row {
            background: dodgerblue;
            font-size:16px;
        }
        .header-row,
        .top-header-row {
            font-weight:bold;
            text-align:center;
        }
    `]
})
export class ReportExportModalComponent {
    type;
    selected;
    loading;

    @ViewChild('content') content: any;
    constructor (
        private activeModal: NgbActiveModal,
        private http: Http,
        private pouchService: PouchDBService,
        private wpiService: WpiService
    ) { }

    close () {
        this.activeModal.close(true);
    }

    loadTests (type = 'main', selected = []) {
        this.type = type;
        this.selected = selected;
        this.wpiService.restartWpi();
        for (let i = 0; i < selected.length; i++) {
            let series = selected[i];
            for(let x in series.tests) {
                if (true) {
                    this.wpiService.evaluateResults(series.protocol.tests[x], series.tests[x].test);
                }
            }
        }
    }

    saveAsWord () {
        let source = this.content.content.nativeElement.innerHTML;
        this.loading = true;
        this.http.post('http://html2file.devns.com/', {type:'docx',html:source}, {
            responseType: ResponseContentType.Blob
        }).toPromise().then( res => {
            this.loading = false;
            FileSaver.saveAs(res.blob(),"report.docx");
        }, err => {
            alert('Unexpected error -- please try again.');
            this.loading = false;
        });
    }

    saveAsPdf () {
        let source = this.content.content.nativeElement.innerHTML;
        this.loading = true;
        this.http.post('http://html2file.devns.com/', {type:'pdf',html:source}, {
            responseType: ResponseContentType.Blob
        }).toPromise().then( res => {
            this.loading = false;
            FileSaver.saveAs(res.blob(),"report.pdf");
        }, err => {
            alert('Unexpected error -- please try again.');
            this.loading = false;
        });
    }

}
