import {Component, Input, ViewChild} from "@angular/core";
import {DomSanitizer} from "@angular/platform-browser";
import {Http, ResponseContentType} from "@angular/http";
import {ReportService} from "./report.service";
import {WpiService} from "../services/wpi.service";
@Component({
    selector: 'report-tech',
    templateUrl: './report-tech.component.html',
    styleUrls: ['./report-tech.component.css']
})
export class ReportTechComponent {
    css = {
        delivery_line: `
            font-size:16px;
            font-weight:bold;
        `,
        table: `
            margin: 0px; padding: 0px;  border: 1px solid #000000;

        `, // width: 100%;
        header_cell: `
            background-color: #ff7f00; border: 1px solid #000000; text-align: center;
            border-width: 1px 1px 1px 1px; font-size: 10px; font-family: Arial; font-weight: bold;
            color: black; vertical-align: middle;
            ` //line-height: 15px;padding: 3px;
//         box-shadow: 10px 10px 5px #888888;-moz-border-radius-bottomleft: 0px; -webkit-border-bottom-left-radius: 0px; border-bottom-left-radius: 0px;
// -moz-border-radius-bottomright: 0px; webkit-border-bottom-right-radius: 0px; border-bottom-right-radius: 0px;
// -moz-border-radius-topright: 0px; -webkit-border-top-right-radius: 0px; border-top-right-radius': 0px;
// -moz-border-radius-topleft: 0px; -webkit-border-top-left-radius: 0px; border-top-left-radius: 0px
        ,
        table_cell: `
            vertical-align: middle;
            border: 1px solid #000;
            border-width: 1px 1px 1px 1px;
            text-align: left;
            font-size: 11px;
            font-family: Arial;
            font-weight: normal;
            color: black;
        `,
        table_row_odd: `
            background-color: #ffaa56;
        `,
        table_row_even: `
            background-color: #fff;
        `,
        test: 'width:45%;',
        section_header: `width:100%; padding:5px; border:1px solid black; display:block; background: #ff7f00; font-weight:bold;`
    }


    pat = {
        name: 'Example Name'
    }
    taken = {
        tests: 5
    };
    total = {
        tests: 6
    }
    lname = {
        doc: 'Fumbles'
    }
    doc = {
        name: 'Filler'
    }

    images = {}

    @Input() test;
    info: any = {};

    @ViewChild('content') content: any;
    constructor (
        private dom: DomSanitizer, private http: Http,
        private reportService: ReportService, private wpiService: WpiService
    ) { }

    ngOnInit () {
        // this.reportService.promiseDataLoaded(this.test).then(info => this.info=info);
    }

    getContent () {
        return this.content.nativeElement.innerHtml;
    }

    getCss(x) {
        // console.log('aaaa', this.dom.bypassSecurityTrustStyle(x));
        return this.dom.bypassSecurityTrustStyle(x);
    }

    getUrl(x){
        if(this.images[x]) {
            return this.dom.bypassSecurityTrustResourceUrl(this.images[x]);
        }

        this.images[x] = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

        this.http.get(x, {
            responseType: ResponseContentType.Blob
        }).toPromise().then(res => {
            // console.log('response given for img', res);
            var a = new FileReader();
            a.onload = (e:any) => {
                // console.log('FR', e.target.result);
                this.images[x] = e.target.result;
            }
            a.readAsDataURL(res.blob());
        })

        return this.dom.bypassSecurityTrustResourceUrl(this.images[x]);
    }
    generateImageSrc () {
        return this.dom.bypassSecurityTrustUrl('data:' + this.info.patient._attachments[this.info.patient.Photo].content_type + ';base64,' + this.info.patient._attachments[this.info.patient.Photo].data);
    }
}
