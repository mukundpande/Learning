import {Injectable} from "@angular/core";
import {FooterContextService} from "../services/footer-context.service";
import {PouchDBService} from "../services/pouchdb.service";
import {CalculationsService} from "../services/calculations.service";
import {DatePipe} from "@angular/common";
import {WpiService} from "../services/wpi.service";

import * as JSZip from 'jszip';
import * as Docxtemplater from 'docxtemplater';
import * as ImageModule from 'docxtemplater-image-module/build/imagemodule';
import * as FileSaver from 'file-saver';
import {Http, ResponseContentType} from "@angular/http";
import {DomSanitizer} from "@angular/platform-browser";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {ReportGraphPrepComponent} from "./report-graph-prep.component";
import {ErrorDisplayModalComponent} from "../utils/error-display-modal.component";

declare function escape(s:string): string;

@Injectable()
export class ReportService {
    selectedSeries = [];
    info: any = {}

    hosts: any = {
        '': ''
    }

    images: any = {}

    private sources;

    private test_sources = {
        'ARC_REPORTS_MainReport' : 'main',
        'ARC_REPORTS_TechReport' : 'tech',
    }

    // 'AirsTest': {
    //     devices: ['AI']
    // },
    // 'DexTest': {
    //     devices: ['DX']
    // },
    // 'DynamicTest': {
    //     devices: ['SP','LC']
    // },
    // 'NadepTest': {
    //     devices: ['NA','MT','PE']
    // },
    // 'RomTest': {
    //     devices: ['EG','RM']
    // },
    // 'StaticTest': {
    //     devices: ['CX','HD','PG','ST']
    // },

    private info_sources = {
        'ARC_norms_RM': 'RM',
        'ARC_norms_HD': 'HD',
        'ARC_norms_PG': 'PG',
        'ARC_PROTOCOL_StaticTest' : 'statics',
        'ARC_PROTOCOL_RomTest' : 'roms',
        'ARC_PROTOCOL_Protocol': 'protocols',
    }
    resolve;
    reject;


    private occasional_lifts = {
        0: 'Sedentary',
        11: 'Light',
        21: 'Medium',
        51: 'Heavy',
        100: 'Very Heavy'
    };

    // wpiService: any = {};

    constructor (
        // private footerContext: FooterContextService,
        private pouchService: PouchDBService,
        private calc:CalculationsService,
        private datePipe: DatePipe,
        private wpiService: WpiService,
        private http: Http,
        private dom: DomSanitizer,
        private modalService: NgbModal
    ) {}

    promiseNormInfoLoaded () {
        if (this.sources) {
            let kis = Object.keys(this.test_sources);
            return this.pouchService.allDocs({ include_docs: true, keys: kis, attachments: true}).then(res => {
                for (let i = 0; i < res.rows.length; i++ ) {
                    let row = res.rows[i];

                    if(this.test_sources[row.key]){
                        this.sources[this.test_sources[row.key]] = row.doc;
                    } else {
                        console.error('missing test source', row.key);
                    }

                }

                return this.sources;
            });
        }
        let keys = Object.keys(this.info_sources);

        return this.pouchService.allDocs({ include_docs: true, keys: keys }).then( res => {

            this.sources = {};
            for (let i = 0; i < res.rows.length; i++ ) {
                let row = res.rows[i];

                if (this.info_sources[row.doc._id]) {
                    this.sources[this.info_sources[row.doc._id]] = row.doc.items;
                } else {
                    console.error('could not match source', row.doc._id);
                }
            }

            let kis = Object.keys(this.test_sources);
            return this.pouchService.allDocs({ include_docs: true, keys: kis, attachments: true}).then(res => {
                for (let i = 0; i < res.rows.length; i++ ) {
                    let row = res.rows[i];

                    if(this.test_sources[row.key]){
                        this.sources[this.test_sources[row.key]] = row.doc;
                    } else {
                        console.error('missing test source', row.key);
                    }

                }

                return this.sources;
            });
        })
    }

    acceptCustomFile (file, result) {
        return this.promiseNormInfoLoaded().then(info => {
            let attachments = {};
            attachments[file.name] = {
                content_type: file.type,
                data: result
            };
            this.sources['custom'] = {
                file: file.name,
                _attachments: attachments
            }

            return this.sources['custom'];
        })
    }

    public promiseDataLoaded (patient, series) {

        let promise = new Promise((r,e)=> {
           this.resolve = r;
           this.reject = e;
        })

        console.log('[*report::promiseDataLoaded] Loading with WPI Information', this.wpiService, patient, series);

        this.info = {
            cx_table: [],
            eg_table: [],
            rm_table: [],
            hd_table: [],
            hd_both_table: [],
            st_table: [],
            pg_table: [],
            pg_both_table: [],
            st_graphs: [],
            hd_graphs: [],
            rm_graphs: [],
            cx_graphs: [],
            eg_graphs: [],
            pg_graphs: [],
            st_repeats: [],
            hd_repeats: [],
            rm_repeats: [],
            cx_repeats: [],
            eg_repeats: [],
            pg_repeats: [],
            repeated_tests: {},
            cx: {},
            eg: {},
            rm: {CRM: 0, LRM: 0},
            hd: {},
            st: {},
            pg: {},
            errors_hd_pg: [],
            errors_st: [],
            errors_rm: [],
            tests: series,
            painPoints: [],
            diag: [],
            howmany: '7 of 7',
            impairments: this.wpiService.bodySections,
            impdetails: this.wpiService.details,
            airsdetails: this.wpiService.airsdetails,
            i: this.wpiService.shortsum,
            name: patient.FirstName,
            full_name: patient.FirstName + ' ' + (patient.Initial && patient.Initial.length ? patient.Initial + ' ':'') + patient.LastName,
            id: patient._id,
            address: patient.Address,
            city: patient.City,
            state: patient.State,
            zip: patient.Zip,
            date: this.datePipe.transform(new Date(),'shortDate'),
            validity_table: [],
            image: '/assets/images/bodyPic.png',
            // rawXML: '<w:p><w:pPr><w:rPr><w:color w:val="FF0000"/></w:rPr></w:pPr><w:r><w:rPr><w:color w:val="000000"/></w:rPr><w:t>My custom</w:t></w:r><w:r><w:rPr><w:color w:val="00FF00"/></w:rPr><w:t>XML</w:t></w:r></w:p>'
        };
        this.pouchService.get('PAT_' + patient._id, {attachments: true}).then(res => {
            this.info.patient = res;
            this.info.age = this.calc.getAge(this.info.patient.DateofBirth);

            this.info.formal_name = this.getFormalName();
            this.info.referred = this.info.patient.Referred;
            this.info.series = [];
            this.info.height = this.info.patient.Height;
            this.info.weight = this.info.patient.Weight;
            this.info.dob = this.info.patient.DateofBirth;
            this.info.side = this.info.patient.DominantHand;
            this.info.sex = this.info.patient.Sex;
            this.info.weight_ms = this.getWeightMeasurement();
            this.info.height_ms = this.getHeightMeasurement();

            this.info.diag1 = this.info.patient.Diag1;
            this.info.diag2 = this.info.patient.Diag2;
            this.info.diag3 = this.info.patient.Diag3;

            this.info.pronoun = this.info.sex === 'F' ? 'She' : 'He';
            this.info.possessive = this.info.sex === 'F' ? 'Her' : 'His';


            for(let i = 0; i < series.length; i++) {
                this.info.series.push(series[i].protocol.Name);
            }

            this.info.series = this.info.series.join(', ');

            for(let i = 0; i < 3; i++) {
                if(this.info.patient['Side' + i] || this.info.patient['Code' + i] || this.info.patient['Diag' + i] || this.info.patient['Date' + i] ) {
                    this.info.diag.push({
                        side: this.info.patient['Side' + i],
                        code: this.info.patient['Code' + i],
                        diag: this.info.patient['Diag' + i],
                        date: this.info.patient['Date' + i],
                    });
                }
            }

            if(!this.info.diag.length) {
                this.info.diag.push({side: 'n/a', code: 'n/a', diag: 'n/a', date: 'n/a'});
            }

            this.promiseNormInfoLoaded().then(norms => {
                this.parseSelectedSeries(series);
                this.resolve(this.info);
            })
        })
        return promise;
    }

    promiseLoadedImage (infoTag) {
        let img = this.info[infoTag];
        console.log('aaa', img);

        let resolve: any;

        this.http.get(img, {
            responseType: ResponseContentType.Blob
        }).toPromise().then(res => {
            // console.log('response given for img', res);
            var a = new FileReader();
            a.onload = (e:any) => {
                let result = atob(e.target.result.split(',')[1]);
                console.log('FR', result);
                this.info[infoTag] = result;
                resolve(result);
            }
            a.readAsDataURL(res.blob());
        })

        return new Promise((rs, rej) => { resolve = rs; });

        // console.log('LOADING IMAGE', tagValue, tagName);
        //
        // // return tagValue;
        //
        // if(this.images[tagValue]) {
        //     return this.dom.bypassSecurityTrustResourceUrl(this.images[tagValue]);
        // }
        //
        // this.images[tagValue] = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
        //
        // this.http.get(tagValue, {
        //     responseType: ResponseContentType.Blob
        // }).toPromise().then(res => {
        //     // console.log('response given for img', res);
        //     var a = new FileReader();
        //     a.onload = (e:any) => {
        //         // console.log('FR', e.target.result);
        //         this.images[tagValue] = e.target.result;
        //     }
        //     a.readAsDataURL(res.blob());
        // })
        //
        // return this.dom.bypassSecurityTrustResourceUrl(this.images[tagValue]);
    }

    generateReportFile (type, selected, patient) {
        return this.wpiService.restartWpi(patient).then(wpi => {

            return this.wpiService.promiseSelectedEvaluated(selected).then(res => {
                return this.promiseDataLoaded(patient, selected).then(info => {
                    console.log('this modal will prepare with', info);
                    const modal = this.modalService.open(ReportGraphPrepComponent, {backdrop:'static'});
                    modal.componentInstance.load(this, type);

                    modal.result.then(r=>{

                        let chunk = 4;
                        let st_chunks = this.info.st_graphs.length / chunk;

                        let st_rows = [];
                        for (let i = 0; i < st_chunks; i++) {
                            st_rows.push({
                                row: this.info.st_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        this.info.st_graphs = st_rows;

                        // console.log('ST ROWS REPLACING', st_rows);

                        let hd_chunks = this.info.hd_graphs.length / chunk;
                        let hd_rows = [];
                        for (let i = 0; i < hd_chunks; i++) {
                            hd_rows.push({
                                row: this.info.hd_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        // console.log('HD ROWS REPLACING', hd_rows);
                        this.info.hd_graphs = hd_rows;


                        let pg_chunks = this.info.pg_graphs.length / chunk;
                        let pg_rows = [];
                        for (let i = 0; i < pg_chunks; i++) {
                            pg_rows.push({
                                row: this.info.pg_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        // console.log('PG ROWS REPLACING', pg_rows);
                        this.info.pg_graphs = pg_rows;


                        let cx_chunks = this.info.cx_graphs.length / chunk;
                        let cx_rows = [];
                        for (let i = 0; i < cx_chunks; i++) {
                            cx_rows.push({
                                row: this.info.cx_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        // console.log('CX ROWS REPLACING', cx_rows);
                        this.info.cx_graphs = cx_rows;


                        let rm_chunks = this.info.rm_graphs.length / chunk;
                        let rm_rows = [];
                        for (let i = 0; i < rm_chunks; i++) {
                            rm_rows.push({
                                row: this.info.rm_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        // console.log('RM ROWS REPLACING', rm_rows);
                        this.info.rm_graphs = rm_rows;

                        let eg_chunks = this.info.eg_graphs.length / chunk;
                        let eg_rows = [];
                        for (let i = 0; i < eg_chunks; i++) {
                            eg_rows.push({
                                row: this.info.eg_graphs.slice(i*chunk, i*chunk + chunk)
                            });
                        }

                        // console.log('EG ROWS REPLACING', eg_rows);
                        this.info.eg_graphs = eg_rows;



                        //     console.log('DONE LOADING IMAGE',r);

                        let attachment = this.sources[type]._attachments[this.sources[type].file];
                        let zip = new JSZip(this.base64ToIntArray(attachment));
                        let doc = new Docxtemplater();

                        let imageModule = new ImageModule({
                            getImage: (tagValue, tagName) => {
                                // console.log('grabbing ', tagName, 'which is', tagValue);
                                return tagValue.data;
                            },
                            getSize: (img, other) => {
                                // console.log('getSize', other);
                                return [other.width, other.height]
                            }
                        });

                        let expressions = require('angular-expressions');
                        // define your filter functions here, for example, to be able to write {clientname | lower}
                        expressions.filters.lower = function(input) {
                            // This condition should be used to make sure that if your input is undefined, your output will be undefined as well and will not throw an error
                            if(!input) return input;
                            return input.toLowerCase();
                        }
                        let angularParser = function(tag) {
                            return {
                                get: tag === '.' ? function(s){ return s;} : expressions.compile(tag.replace(/’/g, "'"))
                            };
                        }

                        doc.attachModule(imageModule).loadZip(zip).setOptions({parser: angularParser, nullGetter: () => { return '--'; }});

                        doc.setData(this.info);
                        try {
                            doc.render()
                        }
                        catch (error) {
                            let e = {
                                message: error.message,
                                name: error.name,
                                stack: error.stack,
                                properties: error.properties,
                            }
                            console.log('ERROR: ', {error: e});

                            let errors = [];

                            if (error.properties.errors) {
                                for(let i = 0; i < error.properties.errors.length; i++) {
                                    let err = error.properties.errors[i];
                                    errors.push(err.properties.explanation);
                                }
                            } else {
                                let thing:any = error.properties.parsed[error.properties.index];
                                errors.push(error.properties.explanation + ' (at '+thing.type+' '+thing.module+' '+thing.location+' '+thing.value+')');
                            }


                            const modal = this.modalService.open(ErrorDisplayModalComponent);

                            modal.componentInstance.setError('This report\'s template has errors. Please contact the database administrator with the following details: ');
                            modal.componentInstance.setReasons(errors);
                            // The error thrown here contains additional information when logged with JSON.stringify (it contains a property object).
                            throw error;
                        }
                        let buf = doc.getZip().generate({type: 'nodebuffer'});
                        let blob = new Blob([buf], {type: attachment.content_type});
                        FileSaver.saveAs(blob,"report.docx");
                        return true;
                    })
                });
            })

        });

    }

    base64ToIntArray (a) {
        let byteString = atob(a.data);
        let mimeString = a.content_type;
        let ab = new ArrayBuffer(byteString.length);
        let ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return ia;
    }

    getName () {
        return this.info.patient.FirstName + ' ' + (this.info.patient.Initial?this.info.patient.Initial + ' ' :'') + this.info.patient.LastName;
    }
    getHeightMeasurement () {
        return [null, 'in','cm'][+this.info.patient.Units];
    }
    getWeightMeasurement () {
        return [null, 'lb','kg'][+this.info.patient.Units];
    }

    getFormalPrefix () {
        return this.info.patient.Sex === "F" ? 'Ms.' : 'Mr.';
    }
    getPatientPossessive () {
        return this.info.patient.Sex === "F" ? 'her' : 'his';
    }

    getFormalName () {
        return this.getFormalPrefix() + ' ' + this.info.patient.LastName;
    }


    registerError (device, name, reason) {
        switch (device) {
            case 'ST':
                this.info.errors_st.push({
                    name: this.htmlSpecialChars(name),
                    description: this.htmlSpecialChars(reason)
                });
                break;
            case 'RM':
                this.info.errors_rm.push({
                    name: this.htmlSpecialChars(name),
                    description: this.htmlSpecialChars(reason)
                });
                break;
            case 'HD':
            case 'PG':
                this.info.errors_hd_pg.push({
                    name: this.htmlSpecialChars(name),
                    description: this.htmlSpecialChars(reason)
                });
                break;
            default:
                console.error('Unknown Device for registering Validity Error: ' + device);
                break;
        }
    }

    htmlSpecialChars(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    validityTableAddRegularRow (obj) {
        this.validityTableAdd(obj, '<w:p><w:pPr><w:rPr><w:color w:val="FF0000"/></w:rPr></w:pPr><w:r><w:rPr><w:b/><w:color w:val="000000"/></w:rPr><w:t>', '</w:t></w:r></w:p>');
    }
    validityTableAddItalicRow (obj) {
        let pre = '<w:tab/> --- <w:tab/>';
        obj.name = pre + obj.name;
        obj.description = pre + obj.description;

        this.validityTableAdd(obj, `
            <w:p>
                <w:pPr>
                    <w:tabs>
                        <w:tab w:val="start" pos="2160"/>
                    </w:tabs>
                    <w:rPr>
                        <w:i/><w:color w:val="FF0000"/></w:rPr></w:pPr><w:r><w:rPr><w:i/><w:color w:val="000000"/></w:rPr><w:t>`, '</w:t></w:r></w:p>');
    }

    validityTableAdd (obj, preXML, postXML) {
        this.info.validity_table.push({
            name: preXML + obj.name + postXML,
            description: preXML + obj.description + postXML
        });
    }

    compileValidityTable () {
        //static strength count
        let ST_Count = this.info.st_table.length;
        if (ST_Count) {
           this.validityTableAddRegularRow({
               name: 'Static Strength Tests',
               description: (ST_Count - this.info.errors_st.length) + ' of ' + ST_Count + ' criteria valid' + (this.info.errors_st.length?' - exceptions noted below':'')
           });

            for (let i = 0; i < this.info.errors_st.length; i++) {
                this.validityTableAddItalicRow(this.info.errors_st[i]);
            }
        }

        //grip/pinch strength length
        let HD_PG_Count = this.info.hd_table.length + this.info.pg_table.length;
        if (HD_PG_Count) {
            this.validityTableAddRegularRow({
                name: 'Grip/Pinch Strength Tests',
                description: (HD_PG_Count - this.info.errors_hd_pg.length) + ' of ' + HD_PG_Count + ' criteria valid' + (this.info.errors_hd_pg.length?' - exceptions noted below':'')
            });

            for (let i = 0; i < this.info.errors_hd_pg.length; i++) {
                this.validityTableAddItalicRow(this.info.errors_hd_pg[i]);
            }
        }
        //RoM length
        let RM_Count = this.info.rm_table.length;
        if (RM_Count) {
            this.validityTableAddRegularRow({
                name: 'Range of Motion Tests',
                description: (RM_Count - this.info.errors_rm.length) + ' of ' + RM_Count + ' criteria valid' + (this.info.errors_rm.length?' - exceptions noted below':'')
            });

            for (let i = 0; i < this.info.errors_rm.length; i++) {
                this.validityTableAddItalicRow(this.info.errors_rm[i]);
            }
        }

        // let preXML = ;
        // let postXML = ;
        //
        // //wrap all elements for XML
        // for (let i = 0; i < this.info.validity_table.length; i++) {
        //     this.info.validity_table[i].name = preXML + this.info.validity_table[i].name + postXML;
        //     this.info.validity_table[i].description = preXML + this.info.validity_table[i].description + postXML;
        // }
        this.compileReportObjects();
    }

    abbreviateName (x) {
        let chunks = x.split(' ');
        let s = '';

        for (let i = 0; i < chunks.length; i++) {
            if (chunks[i].length && chunks[i].substr(0,1).match(/[a-z0-9]/i)) {
                s += chunks[i].substr(0,1);
            }
        }

        return s;
    }

    compileReportObjects () {
        let tables = ['cx','eg','rm','hd','st','pg'];
        for (let i = 0; i < tables.length; i++) {
            if (this.info[tables[i] + '_table'].length) {
                for (let j = 0; j < this.info[tables[i] + '_table'].length; j++) {
                    let key = this.abbreviateName(this.info[tables[i] + '_table'][j].name);
                    this.info[tables[i]][key] = this.info[tables[i] + '_table'][j];

                    if (tables[i] == 'rm' && key.substr(0,1) == 'L' && this.info[tables[i]][key].imp) {
                        this.info.rm.LRM += this.info[tables[i]][key].imp;
                    } else if (tables[i] == 'rm' && key.substr(0,1) == 'C' && this.info[tables[i]][key].imp) {
                        this.info.rm.CRM += this.info[tables[i]][key].imp;
                    }

                }
            }
        }

        // console.log('DONE COMPILING', this.info);
    }

    registerSeriesForRepeats (srs) {
        //params.code, name

        for (let j = 0; j < srs.protocol.tests.length; j++) {
            let params = srs.protocol.tests[j];
            let data = srs.tests[j];

            if (!this.info.repeated_tests[params.code]) {
                this.info.repeated_tests[params.code] = {}
            }

            //Test Name Keys will be individual dates these tests were performed on -- later sorted and compared
            if (!this.info.repeated_tests[params.code][params.name]) {
                this.info.repeated_tests[params.code][params.name] = {}
            }
            let date = this.datePipe.transform(srs.datetime,'shortDate');
            let dateKey = this.datePipe.transform(srs.datetime,'yMMdd');

            // console.log('Registering Test Repeat for: ', {
            //     series: srs,
            //     params: params,
            //     data: data,
            //     date: date,
            //     key: dateKey
            // });

            this.info.repeated_tests[params.code][params.name][dateKey] = data;
        }

    }

    registerRepeatedTest (date, code, obj) {
        if(!obj.name) {
            console.error('Register Repeated Test: TEST OBJECT has no NAME', {
                date:date, code:code, obj:obj
            });
            return;
        }

        let dateKey = this.datePipe.transform(date,'yMMdd');

        if (!this.info.repeated_tests[code]) {
            this.info.repeated_tests[code] = {}
        }

        //Test Name Keys will be individual dates these tests were performed on -- later sorted and compared
        if (!this.info.repeated_tests[code][obj.name]) {
            this.info.repeated_tests[code][obj.name] = {}
        }
        this.info.repeated_tests[code][obj.name][dateKey] = obj;
        return obj;
    }

    loadTestOptionsByParams (params) {
        switch(params.code) {
            case 'CX':
            case 'HD':
            case 'PG':
            case 'ST':
                for (let i = 0; i < this.sources.statics.length; i++) {
                    let statict = this.sources.statics[i];
                    if(statict.Device == params.code && statict.TestName == params.name) {
                        return statict;
                    }
                }
                break;
            case 'EG':
            case 'RM':
                for (let i = 0; i < this.sources.roms.length; i++) {
                    let rom = this.sources.roms[i];
                    if(rom.Device == params.code && rom.TestName == params.name) {
                        return rom;
                    }
                }
                break;
            default:
                console.error('Cannot load test options for code', params.code);
                break;
        }
    }

    parseSelectedSeries (series) {
        this.selectedSeries = series;

        for (let i = 0; i < series.length; i++) {
            let srs = series[i];
            let date = this.datePipe.transform(srs.datetime,'shortDate');

            console.log('REPORT PARSING SERIES NAMED', {srs: srs, info: this});

            let protocolName = srs.protocol.Name;

            let source;

            for (let x = 0; x < this.sources.protocols.length; x++) {
                let protocol = this.sources.protocols[x];

                if(protocol.Name === protocolName) {
                    source = protocol;
                    break;
                }
            }

            if (source) {
                // console.log('FOUND PROTOCOL FOR', protocolName, source);

            } else {
                // console.error('Could not find protocol for ', protocolName);
            }



            // this.registerSeriesForRepeats(srs);
            for (let j = 0; j < srs.protocol.tests.length; j++) {
                let params = srs.protocol.tests[j];
                let data = srs.tests[j];

                let continueWith = true;
                if (source) {
                    continueWith = false;

                    for(let k = 0; k < source.tests.length; k++) {
                        let findingTest = source.tests[k];
                        // console.log('COMPARING VALUES', {find: findingTest, params: params});
                        if(findingTest.code === params.code && findingTest.name === params.name) {
                            // console.log('FOUND MATCHING TEST IN CURRENT PROTOCOL -- KEEPING');
                            continueWith = true;
                            break;
                        }

                    }

                }

                if(!continueWith) {
                    console.error('Test no longer exists, skipping', params);
                    continue;
                }

                let testOptions = this.loadTestOptionsByParams(params);
                // console.log('Test Options Returned', {testOptions: testOptions, params: params});
                // if(!testOptions || testOptions.Distraction) {   continue; }
                let distraction = !testOptions ? false : testOptions.Distraction;

                let forces: any;
                if (!data || !data.view || !data.test) {
                    continue;

                }
                try {
                    switch (params.code) {
                    case 'NA':
                        console.log('[DETECTED THE NA PAIN DRAWING!!!]', data);
                        this.info.painPoints = data.test.points;
                        break;
                    case 'EG':

                        if (params.name.indexOf('/') !== -1) {

                            let rom: any = 0;
                            let norm: any = 0;
                            let pctL: any = 0;
                            let pctR: any = 0;
                            let namechunks = params.name.split(' ');
                            let lastchunk = namechunks.pop();

                            let lastchunks = lastchunk.split('/');

                            for (let i = 0; i < lastchunks.length; i++) {
                                let letter = ['A','B'][i];
                                let romL = data.test['rom'+letter+'L'];
                                let romR = data.test['rom'+letter+'R'];
                                let name = namechunks.join(' ') + ' ' + lastchunks[i];
                                let norm = this.getRMNorm(name);

                                if (!+norm) {
                                    norm = pctL = pctR = 'N/A';
                                } else {
                                    pctL = Math.round(romL/norm*100) + '%';
                                    pctR = Math.round(romR/norm*100) + '%';
                                    norm = norm + ' deg';
                                }

                                let romLN = romL,
                                    romRN = romR;

                                romL = romL + ' deg';
                                romR = romR + ' deg';

                                this.info.eg_table.push(this.registerRepeatedTest(date, 'EG', {
                                    name: name,
                                    date: this.datePipe.transform(srs.datetime,'shortDate'),
                                    romL: romL,
                                    romR: romR,
                                    romLN: romLN,
                                    romRN: romRN,
                                    valid: 'Yes',
                                    norm: norm,
                                    percentL: pctL,
                                    percentR: pctR,
                                    n1L: data.test['trials'+letter+'L'][0].value,
                                    n2L: data.test['trials'+letter+'L'][1].value,
                                    n3L: data.test['trials'+letter+'L'][2].value,
                                    n1R: data.test['trials'+letter+'L'][0].value,
                                    n2R: data.test['trials'+letter+'L'][1].value,
                                    n3R: data.test['trials'+letter+'L'][2].value,
                                }))
                            }
                        } else {
                            //no splits, probably left & right
                            let pctL: any = 0;
                            let pctR: any = 0;
                            let letter = 'A';
                            let romL = data.test['rom'+letter+'L'];
                            let romR = data.test['rom'+letter+'R'];
                            let norm = this.getRMNorm(params.name);
                            if (!+norm) {
                                norm = pctL = pctR = 'N/A';
                            } else {
                                pctL = Math.round(romL/norm*100) + '%';
                                pctR = Math.round(romR/norm*100) + '%';
                                norm = norm + ' deg';
                            }

                            let romLN = romL,
                                romRN = romR;

                            romL = romL + ' deg';
                            romR = romR + ' deg';

                            this.info.eg_table.push(this.registerRepeatedTest(date, 'EG', {
                                name: params.name,
                                date: this.datePipe.transform(srs.datetime,'shortDate'),
                                romL: romL,
                                romR: romR,
                                romLN: romLN,
                                romRN: romRN,
                                valid: 'Yes',
                                norm: norm,
                                percentL: pctL,
                                percentR: pctR,
                                n1L: data.test['trials'+letter+'L'][0].value,
                                n2L: data.test['trials'+letter+'L'][1].value,
                                n3L: data.test['trials'+letter+'L'][2].value,
                                n1R: data.test['trials'+letter+'L'][0].value,
                                n2R: data.test['trials'+letter+'L'][1].value,
                                n3R: data.test['trials'+letter+'L'][2].value,
                            }))
                        }

                        break;

                    case 'PG':
                        forces = [null, null, 'n/a'];

                        let forcesPG = [0, 0];

                        for (let i = 0; i < 2; i++) {

                            let trials = data.test['trials'+['A','B'][i]];

                            let force = this.calc.generateAverage(trials);
                            let std = this.calc.generateStandardDeviation(trials, force);
                            let cv = this.calc.generateCoefficientOfVariation(std, force);

                            forces[i] = (i && this.info.patient.Dominant === 'R' || !i && this.info.patient.Dominant !== 'R' ?'* ':'') + Math.round(force);
                            forcesPG[i] = +force;

                            let pgNorm;
                            let norm: any = 'n/a';
                            let stdev: any = 'n/a';
                            if(pgNorm = this.getPGNorm(data.view.test.OtherInfo, ['L','R'][i], this.calc.getAge(this.info.patient.DateofBirth), this.info.patient.Sex)) {
                                norm = this.calc.roundTenth(pgNorm.MEAN);
                                stdev = this.calc.roundTenth(pgNorm.SD);
                            }

                            let PGTestName = params.name + ' - ' + ['Left', 'Right'][i];
                            let CVText = this.calc.roundTenth(cv*100);

                            if(cv >= .15) {
                                this.registerError (params.code, PGTestName, 'COV = ' + CVText + ' (expected < 15%)')
                            }

                            let comp;

                            if (norm === 'n/a') {
                                comp = 'n/a';
                            } else if(force < +norm - +stdev) {
                                comp = 'low';
                            } else if (force > +norm + +stdev) {
                                comp = 'high';
                            } else {
                                comp = 'normal';
                            }

                            this.info.pg_table.push(this.registerRepeatedTest(date, 'PG', {
                                name: PGTestName,
                                date: this.datePipe.transform(srs.datetime,'shortDate'),
                                force: Math.round(force) + ' lb',
                                forceN: Math.round(force),
                                cv: CVText,
                                norm: norm,
                                stdev: '-/+ ' + stdev,
                                trial1: trials[0].value + ' lb',
                                trial2: trials[1].value + ' lb',
                                trial3: trials[2].value + ' lb',
                                n1: trials[0].value,
                                n2: trials[1].value,
                                n3: trials[2].value,
                                comp: comp,
                            }));

                        }

                        let sidePG = 'n/a',
                            expectedPG = 'n/a'

                        if (forcesPG[0] > forcesPG[1]) {
                            sidePG = 'Left';
                            expectedPG = forces[1];
                            forces[2] = '-' + Math.round((1-(forcesPG[1]/forcesPG[0]))*100) + '%'
                        } else if(forcesPG[0] < forcesPG[1]) {
                            sidePG = 'Right';
                            expectedPG = forces[0];
                            forces[2] = '-' + Math.round((1-(forcesPG[0]/forcesPG[1]))*100) + '%'
                        } else {
                            sidePG = 'Left';
                            expectedPG = forces[1];
                        }

                        this.info.pg_both_table.push({
                            name: params.name,
                            date: this.datePipe.transform(srs.datetime,'shortDate'),
                            left: forces[0],
                            right: forces[1],
                            weaker: forces[2],
                            side: sidePG,
                            expected: expectedPG,
                            deficit: 'n/a'
                        });

                        break;
                    case 'HD':

                        forces = [null, null, 'n/a'];

                        let forcesHD = [0, 0];


                        for (let i = 0; i < 2; i++) {

                            let trials = data.test['trials'+['A','B'][i]];

                            let force = this.calc.generateAverage(trials);

                            forces[i] = (i && this.info.patient.Dominant === 'R' || !i && this.info.patient.Dominant !== 'R' ?'* ':'') + Math.round(force);
                            forcesHD[i] = +force;

                            let std = this.calc.generateStandardDeviation(trials, force);
                            let cv = this.calc.generateCoefficientOfVariation(std, force);

                            let hdNorm;
                            let norm: any = 'n/a';
                            let stdev: any = 'n/a';
                            if(hdNorm = this.getHDNorm(data.view.test.OtherInfo, ['L','R'][i], this.calc.getAge(this.info.patient.DateofBirth), this.info.patient.Sex)) {
                                norm = this.calc.roundTenth(hdNorm.MEAN);
                                stdev = this.calc.roundTenth(hdNorm.SD);
                            }

                            let HDTestName = params.name + ' - ' + ['Left', 'Right'][i];
                            let CVText = this.calc.roundTenth(cv*100);
                            if(cv >= .15) {
                                this.registerError (params.code, HDTestName, 'COV = ' + CVText + ' (expected < 15%)')
                            }

                            console.log('[HD] COMPARING NORMS!!! ', force, norm, stdev, +norm -+stdev, +norm + +stdev);

                            let comp;
                            if (norm === 'n/a') {
                                comp = 'n/a';
                            } else if(force < +norm - +stdev) {
                                comp = 'low';
                            } else if (force > +norm + +stdev) {
                                comp = 'high';
                            } else {
                                comp = 'normal';
                            }

                            this.info.hd_table.push(this.registerRepeatedTest(date, 'HD', {
                                name: HDTestName,
                                date: this.datePipe.transform(srs.datetime,'shortDate'),
                                force: Math.round(force) + ' lb',
                                forceN: Math.round(force),
                                cv: CVText,
                                norm: norm,
                                trial1: trials[0].value + ' lb',
                                trial2: trials[1].value + ' lb',
                                trial3: trials[2].value + ' lb',
                                n: Math.round(force),
                                n1: trials[0].value,
                                n2: trials[1].value,
                                n3: trials[2].value,
                                stdev: '-/+ ' + stdev,
                                comp: comp,
                            }));
                        }
                        // TASK NAME	DATE	LEFT	RIGHT	Weaker Hand	Injured Side	Expected Strength	Strength Deficit


                        let sideHD = 'n/a',
                            expectedHD = 'n/a'

                        if (forcesHD[0] > forcesHD[1]) {
                            sideHD = 'Left';
                            expectedHD = forces[1];
                            forces[2] = '-' + Math.round((1-(forcesHD[1]/forcesHD[0]))*100) + '%'
                        } else if(forcesHD[0] < forcesHD[1]) {
                            sideHD = 'Right';
                            expectedHD = forces[0];
                            forces[2] = '-' + Math.round((1-(forcesHD[0]/forcesHD[1]))*100) + '%'
                        } else {
                            sideHD = 'Left';
                            expectedHD = forces[1];
                        }

                        this.info.hd_both_table.push({
                            name: params.name,
                            date: this.datePipe.transform(srs.datetime,'shortDate'),
                            left: forces[0],
                            right: forces[1],
                            weaker: forces[2],
                            side: sideHD,
                            expected: expectedHD,
                            deficit: 'n/a'
                        });

                        break;

                    case 'CX':
                        let left;
                        let cvleft;
                        let right;
                        let cvright;
                        let side = 'Left';
                        let expected: any = 0;
                        let deficit;

                        let meanL = null,
                            meanR = null;

                        if(data.view.test.TestMode === "BI") {
                            left = '(bilateral';
                            cvleft = 'test)';
                            let mean = this.calc.generateAverage(data.test.trialsA);
                            let stdev = this.calc.generateStandardDeviation(data.test.trialsA, mean);
                            let co = this.calc.generateCoefficientOfVariation(stdev, mean);
                            right = this.calc.roundTenth(mean) + ' lb';
                            cvright = this.calc.roundTenth(co*100);
                            side = expected = deficit = 'N/A';
                        } else {

                            meanL = this.calc.generateAverage(data.test.trialsA);
                            let stdevL = this.calc.generateStandardDeviation(data.test.trialsA, meanL);
                            let coL = this.calc.generateCoefficientOfVariation(stdevL, meanL);

                            meanR = this.calc.generateAverage(data.test.trialsB);
                            let stdevR = this.calc.generateStandardDeviation(data.test.trialsB, meanR);
                            let coR = this.calc.generateCoefficientOfVariation(stdevR, meanR);

                            left = this.calc.roundTenth(meanL) + ' lb';
                            cvleft = this.calc.roundTenth(coL*100);
                            right = this.calc.roundTenth(meanR) + ' lb';
                            cvright = this.calc.roundTenth(coR*100);

                            if(meanL > meanR) {
                                side = 'Right';
                                expected = this.calc.roundTenth(meanL) + ' lb';
                                deficit = '-' + Math.round((1-(meanR/meanL))*100) + '%'
                            } else if (meanL < meanR) {
                                side = 'Left';
                                expected = this.calc.roundTenth(meanR) + ' lb';
                                deficit = '-' + Math.round((1-(meanL/meanR))*100) + '%'
                            } else {
                                side = 'Left';
                                expected = this.calc.roundTenth(meanL)  + ' lb';
                                deficit = '0%';
                            }


                        }

                        let obj = {
                            name: params.name,
                            date: this.datePipe.transform(srs.datetime,'shortDate'),
                            left: left,
                            leftN: this.calc.roundTenth(meanL),
                            trial1L: data.test.trialsA[0].value,
                            trial2L: data.test.trialsA[1].value,
                            trial3L: data.test.trialsA[2].value,
                            cvleft: cvleft,
                            trial1R: data.test.trialsB && data.test.trialsB[0] ? data.test.trialsB[0].value : null,
                            trial2R: data.test.trialsB && data.test.trialsB[1] ? data.test.trialsB[1].value : null,
                            trial3R: data.test.trialsB && data.test.trialsB[2] ? data.test.trialsB[2].value : null,
                            right: right,
                            rightN: this.calc.roundTenth(meanR),
                            cvright: cvright,


                            n1L: data.test['trialsA'][0].value,
                            n2L: data.test['trialsA'][1].value,
                            n3L: data.test['trialsA'][2].value,
                            n1R: data.test.trialsB && data.test.trialsB[0] ? data.test['trialsB'][0].value : null,
                            n2R: data.test.trialsB && data.test.trialsB[1] ? data.test['trialsB'][1].value : null,
                            n3R: data.test.trialsB && data.test.trialsB[2] ? data.test['trialsB'][2].value : null,

                            side: side,
                            expected: expected,
                            deficit: deficit,
                            notBilateral: data.view.test.TestMode !== "BI"
                        };

                        this.info.cx_table.push(obj);

                        if(data.view.test.TestMode !== "BI") {
                            this.registerRepeatedTest(date, 'CX', obj);
                        }


                        break;

                    case 'ST':


                        let mean = this.calc.generateAverage(data.test.trialsA);
                        let stdev = this.calc.generateStandardDeviation(data.test.trialsA, mean);

                        let label = this.occasional_lifts['0'];

                        let lift = Math.round(mean/2);
                        let labels = Object.keys(this.occasional_lifts);
                        for (let k = 0; k < labels.length; k++) {
                            if (lift > +labels[k]) {
                                label = this.occasional_lifts[labels[k]];
                            } else {
                                break;
                            }
                        }
                        let cv = this.calc.generateCoefficientOfVariation(stdev, mean);
                        let CVText = Math.round(cv*1000)/10;

                        if(cv >= .15) {
                            this.registerError (params.code, params.name, 'COV = ' + CVText + ' (expected < 15%)')
                        }

                        this.info.st_table.push(this.registerRepeatedTest(date, 'ST', {
                            name: params.name,
                            date: this.datePipe.transform(srs.datetime,'shortDate'),
                            weight: Math.round(mean) + ' lb',
                            weightN: Math.round(mean),
                            lift: lift,
                            label: label,
                            occasional: lift + ' lb (' + label + ')',
                            coef: CVText,
                            trial1: data.test.trialsA[0].value + ' lb',
                            trial2: data.test.trialsA[1].value + ' lb',
                            trial3: data.test.trialsA[2].value + ' lb',
                            n1: data.test.trialsA[0].value,
                            n2: data.test.trialsA[1].value,
                            n3: data.test.trialsA[2].value
                        }));

                        break;
                    case 'RM':
                        let rom: any = 0;
                        let norm: any = 0;
                        let pct: any = 0;

                        console.log('[REPORT SERVICE -- EVALUATING RM]', {data: data});

                        if (data.view && +data.view.test.Dual) {
                            console.log('[REPORT SERVICE -- EVALUATING RM AS DUAL]', {data: data});
                            if (params.name.indexOf('/') !== -1) {
                                let namechunks = params.name.split(' ');
                                let lastchunk = namechunks.pop();
                                let lastchunks = lastchunk.split('/');
                                for (let i = 0; i < lastchunks.length; i++) {
                                    let rom = data.test['rom'+['A','B'][i]];
                                    let name = namechunks.join(' ') + ' ' + lastchunks[i];

                                    let norm = this.getRMNorm(name);
                                    if (!+norm) {
                                        norm = 'N/A';
                                        pct = 'N/A';
                                    } else {
                                        pct = Math.round(rom/norm*100) + '%';
                                        norm = norm + ' deg';
                                    }
                                    let trials = data.test['trials'+['A','B'][i]];

                                    let trialValues = this.calc.pluck(trials);

                                    let max = this.calc.maximum(trialValues);
                                    let maxU = this.calc.maximum(this.calc.pluck(trials, 'upper'));

                                    let avg = this.calc.average(trialValues);
                                    let stdev = this.calc.standardDeviation(trialValues, avg);
                                    let cv = stdev / avg;
                                    let CVText = this.calc.roundTenth(cv);

                                    if(cv >= .15) {
                                        this.registerError (params.code, params.name, 'COV = ' + CVText + ' (expected < 15%)')
                                    }

                                    let obj = {
                                        name: name,
                                        date: this.datePipe.transform(srs.datetime,'shortDate'),
                                        rom: rom + ' deg',
                                        romN: rom,
                                        valid: data.test['failed' + ['A','B'][i]] ? 'No' : 'Yes',
                                        norm: norm,
                                        percent: pct,
                                        max: max,
                                        mup: maxU ? Math.round(max/maxU*100) : null,
                                        n1: trials[0].value,
                                        n2: trials[1].value,
                                        n3: trials[2].value,
                                        imp: this.evaluateRMImpairment(params.name, rom, this.calc.average(this.calc.pluck(trials,'lower')), i),
                                    };
                                    for (let t = 0; t < trials.length; t++) {
                                        obj['u'+(t+1)] = trials[t].upper;
                                        obj['l'+(t+1)] = trials[t].lower;
                                        obj['v'+(t+1)] = trials[t].value;
                                    }
                                    this.info.rm_table.push(this.registerRepeatedTest(date, 'RM', obj))
                                }

                            } else {
                                //no splits, probably left & right

                                for (let i = 0; i < 2; i++) {
                                    let rom = data.test['rom'+['A','B'][i]];
                                    console.log('Searching for norm for', params.name);
                                    let norm = this.getRMNorm(params.name);
                                    console.log('norm result', {name: params.name, norm: norm});
                                    if (!+norm) {
                                        norm = 'N/A';
                                        pct = 'N/A';
                                    } else {
                                        pct = Math.round(rom/norm*100) + '%';
                                        norm = norm + ' deg';
                                    }

                                    let trials = data.test['trials'+['A','B'][i]];
                                    let trialValues = this.calc.pluck(trials);
                                    let max = this.calc.maximum(trialValues);
                                    let maxU = this.calc.maximum(this.calc.pluck(trials, 'upper'));
                                    let nameE = params.name + ' - ' + ['Left','Right'][i];

                                    if (data.view.test.TestMode == 'BI') {
                                        nameE = params.name;
                                        console.log('Report RM -- updated test name to be bilateral');
                                    }

                                    let avg = this.calc.average(trialValues);
                                    let stdev = this.calc.standardDeviation(trialValues, avg);
                                    let cv = stdev / avg;
                                    let CVText = this.calc.roundTenth(cv);
                                    if(cv >= .15) {
                                        this.registerError (params.code, nameE, 'COV = ' + CVText + ' (expected < 15%)')
                                    }

                                    let obj = {
                                        name: nameE,
                                        date: this.datePipe.transform(srs.datetime,'shortDate'),
                                        rom: rom + ' deg',
                                        romN: rom,
                                        valid: data.test['failed' + ['A','B'][i]] ? 'No' : 'Yes',
                                        norm: norm,
                                        percent: pct,
                                        n1: trials[0].value,
                                        n2: trials[1].value,
                                        n3: trials[2].value,
                                        max: this.calc.maximum(this.calc.pluck(trials)),
                                        mup: maxU ? Math.round(max/maxU*100) : null,
                                        imp: this.evaluateRMImpairment(params.name, rom, this.calc.average(this.calc.pluck(trials,'lower'))),
                                    };


                                    for (let t = 0; t < trials.length; t++) {
                                        obj['u'+(t+1)] = trials[t].upper;
                                        obj['l'+(t+1)] = trials[t].lower;
                                        obj['v'+(t+1)] = trials[t].value;
                                    }

                                    this.info.rm_table.push(this.registerRepeatedTest(date, 'RM', obj))
                                }


                            }
                        } else {
                            console.log('[REPORT SERVICE -- EVALUATING RM AS NON-DUAL, SINGULAR]', {data: data});
                            rom = data.test.romA;

                            norm = this.getRMNorm(params.name);

                            if (!+norm) {
                                norm = 'N/A';
                                pct = 'N/A';
                            } else {
                                pct = Math.round(rom/norm*100) + '%';
                                norm = norm + ' deg';
                            }

                            let trials = data.test['trialsA'];
                            let trialValues = this.calc.pluck(trials);
                            let max = this.calc.maximum(trialValues);
                            let maxU = this.calc.maximum(this.calc.pluck(trials, 'upper'));

                            let avg = this.calc.average(trialValues);
                            let stdev = this.calc.standardDeviation(trialValues, avg);
                            let cv = stdev / avg;
                            let CVText = this.calc.roundTenth(cv);
                            if(cv >= .15) {
                                this.registerError (params.code, params.name, 'COV = ' + CVText + ' (expected < 15%)')
                            }


                            let obj = {
                                name: params.name,
                                date: this.datePipe.transform(srs.datetime,'shortDate'),
                                rom: rom + ' deg',
                                romN: rom,
                                valid: data.test['failedA'] ? 'No' : 'Yes',
                                norm: norm,
                                percent: pct,
                                n1: trials[0].value,
                                n2: trials[1].value,
                                n3: trials[2].value,
                                max: this.calc.maximum(this.calc.pluck(trials)),
                                mup: maxU ? Math.round(max/maxU*100) : null,
                                imp: this.evaluateRMImpairment(params.name, rom, this.calc.average(this.calc.pluck(trials,'lower'))),
                            }

                            for (let t = 0; t < trials.length; t++) {
                                obj['u'+(t+1)] = trials[t].upper;
                                obj['l'+(t+1)] = trials[t].lower;
                                obj['v'+(t+1)] = trials[t].value;
                            }


                            this.info.rm_table.push(this.registerRepeatedTest(date, 'RM', obj))
                        }

                        break;
                    default:
                        console.log('UNKNOWN DATA FROM ', srs.protocol.tests[j], srs.tests[j]);
                        break;
                }
                } catch (e) {
                    console.error('problem with rendering a test', params, data, e);
                }
            }
        }

        this.compileValidityTable();
        this.compileRepeatedTestTables();

    }

    compileRepeatedTestTables () {

        let keys = Object.keys(this.info.repeated_tests);

        for (let i = 0; i < keys.length; i++) {
            let code = keys[i];
            let repeatSection = this.info.repeated_tests[code];

            let tests = Object.keys(repeatSection);
            console.log('Parsing Table to ', keys[i], repeatSection, tests);

            if(!this.info[code + '_repeats']) {
                this.info[code + '_repeats'] = [];
            }

            for (let j = 0; j < tests.length; j++) {
                let test = repeatSection[tests[j]];
                let dates = Object.keys(test);
                if (dates.length > 1) {
                    dates.sort();

                    let lastDate = dates.pop();

                    for (let k = 0; k < dates.length; k++) {
                        let orig = test[dates[k]],
                            last = test[lastDate];

                        console.log('Compare Orig to Last', orig, last);

                        switch(code) {
                            case 'CX':
                                let origN = (orig.leftN+orig.rightN)/2,
                                    lastN = (last.leftN+last.rightN)/2;

                                this.info.cx_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvg: origN + ' lb',
                                    rAvg: lastN + ' lb',
                                    change: Math.round((lastN/origN-1)*100) + '%'
                                });
                                break;
                            case 'EG':
                                // console.error('[EG Handler]', code, tests[j]);
                                this.info.eg_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvgL: orig.romLN + ' deg',
                                    oAvgR: orig.romRN + ' deg',
                                    rAvgL: last.romLN + ' deg',
                                    rAvgR: last.romRN + ' deg',
                                    changeL: Math.round((last.romLN/orig.romLN-1)*100) + '%',
                                    changeR: Math.round((last.romRN/orig.romRN-1)*100) + '%'
                                });
                                break;
                            case 'HD':
                                // console.error('[HD Handler]', code, tests[j]);
                                this.info.hd_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvg: orig.forceN + ' lb',
                                    rAvg: last.forceN + ' lb',
                                    change: Math.round((last.forceN/orig.forceN-1)*100) + '%'
                                });
                                break;
                            case 'PG':
                                // console.error('[PG Handler]', code, tests[j]);

                                this.info.pg_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvg: orig.forceN + ' lb',
                                    rAvg: last.forceN + ' lb',
                                    change: Math.round((last.forceN/orig.forceN-1)*100) + '%'
                                });
                                break;
                            case 'RM':

                                this.info.rm_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvg: orig.romN + ' deg',
                                    rAvg: last.romN + ' deg',
                                    change: Math.round((last.romN/orig.romN-1)*100) + '%'
                                });

                                break;
                            case 'ST':
                                // console.error('[ST Handler]', code, tests[j]);
                                this.info.st_repeats.push({
                                    name: orig.name,
                                    oDate: orig.date,
                                    rDate: last.date,
                                    oAvg: orig.weightN + ' lb',
                                    rAvg: last.weightN + ' lb',
                                    change: Math.round((last.weightN/orig.weightN-1)*100) + '%'
                                });
                                break;
                            default:
                                console.error('Could not handle repeated test for', code, test);
                                break;
                        }

                    }
                }
            }


        }

    }

    evaluateRMImpairment(name, rom, lower, second = 0) {
        // console.log('EVALUATING RM Impairment ', name, rom, lower);
        let testInfo;
        if (!(testInfo = this.wpiService.locateTestImpairmentInfo(name))) {
            // console.log('Failed to find Test Impairment Information for', name);
            return;
        }
        let result = this.wpiService.generateAirsSpineImpairment(
            testInfo.LOCATION, testInfo['TESTCODE' + (second+1)], testInfo.IMPAIRMENTCODE,
            testInfo.EDITION, rom, lower
        );
        // console.log('WPI RETURNED', result, 'FOR', name);
        return result;
    }

    locateImpairment (name) {
        // console.log('searching for ', name, ' within ', this.wpiService.summary);

        let keys = Object.keys(this.wpiService.summary);
        for (let i = 0; i < keys.length; i++) {
            let section = this.wpiService.summary[keys[i]];
            let testKeys = Object.keys(section.tests);
            // console.log('searching for', name, ' under', testKeys);
            if(testKeys.indexOf(name) !== -1) {
                return section.tests[name];
            }
        }
        return 0;
    }

    getHDNorm (position, side, age, sex) {
        let foundHD;
        for (let i = 0; i < this.sources.HD.length; i++) {
            let HD = this.sources.HD[i];

            if(HD.POSITION === position && HD.HAND === side && +HD.AGE >= age && HD.SEX === sex) {
                return HD;
            }
        }
        return foundHD;
    }
    getPGNorm (position, side, age, sex) {
        let foundPG;
        for (let i = 0; i < this.sources.PG.length; i++) {
            let PG = this.sources.PG[i];

            if(PG.POSITION === position && PG.HAND === side && +PG.AGE >= age && PG.SEX === sex) {
                return PG;
            }
        }
        return foundPG;
    }

    getRMNorm (name) {
        for (let i = 0; i < this.sources.RM.length; i++) {
            let RM = this.sources.RM[i];
            if(RM.TaskName === name) {
                return RM.Norm;
            }
        }
        return null;
    }

    renderSummary () {
        this.info.summary = {};
    }


}
