import { Component, OnInit } from '@angular/core';
import {AuthService} from "../admin/auth.service";
import {FormBuilder} from "@angular/forms";

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {

  users: any = [];


  newUserName = '';
  newUserPass = '';

  roles=[
   {name: "USER"},
   {name: "ADMIN"}
  ];

  userForm = this.fb.group({
      name: '',
      pass: '',
      roles : [this.roles]
  });

  constructor (private authService: AuthService, private fb: FormBuilder) {}

  addUser (form) {
      console.log('saving this user');
      form._id= form.name +'_id';
      this.authService.addUser(form).then(res => {
          console.log('user added', res);
          this.getUsers();
          this.userForm.reset({});
      }, err => {
          console.error('could not add user because', err);
      })

  }

  ngOnInit () {
      this.getUsers();
  }

  getUsers () {
       this.authService.getUsers().then(users => {
          console.log('[Admin/Users] Loading Users', users);
          this.users=users;
      });

      // this.users.push(
      //   {
      //     name:'Siva',
      //     impairment:'Test'
      //   },
      //   {
      //     name:'Sony',
      //     impairment:'Test'
      //   }
      //   );

        console.log(this.users);

  }

  deleteUser(_id) {
      if(!confirm('Really delete this user? This is NOT REVERSIBLE!')) {
          return;
      }

      this.authService.deleteUser(_id).then(res => this.getUsers());

      for(let user of this.users){
        if(user._id===_id){
            delete this.users[_id];
        }
          }
  }

}
