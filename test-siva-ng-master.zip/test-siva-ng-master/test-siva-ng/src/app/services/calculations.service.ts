import {Injectable} from "@angular/core";
@Injectable()
export class CalculationsService {
    generateMaximum (myArray, key = 'value') {
        let max = 0;
        for (let i = 0; i < myArray.length; i++) {
            max = Math.max(max, myArray[i][key]);
        }
        return max;
    }

    generateAverage (myArray, key = 'value') {
        return this.average(this.pluck(myArray,key));
        // let total = 0;
        // for (let i = 0; i < myArray.length; i++) {
        //     total += myArray[i][key];
        // }
        // return total / myArray.length;
    }

    pluck(array, key = 'value') {
        try {
            return array.map(v => v[key]);
        } catch (e) {
            console.error('Could not pluck because ', e);
            console.log('Tried plucking from: ', array);
        }
    }

    maximum (myArray) {
        let max = 0;
        for (let i = 0; i < myArray.length; i++) {
            max = Math.max(max, myArray[i]);
        }
        return max;
    }

    average(data, length = 0){
        if (!length) {
            length = data.length;
        }

        var sum = data.reduce(function(sum, value){
            return sum + value;
        }, 0);

        var avg = sum / length;
        return avg;
    }

    standardDeviation(values, avg = null, length = 0){
         if (avg === undefined || avg === null) {
             avg = this.average(values);
         }
        let squareDiffs = values.map(function(value, index){
            let diff = value - avg;
            let sqrDiff = diff * diff;
            return sqrDiff;
        });

        let avgSquareDiff = this.average(squareDiffs, length);

        // console.log('CALCULATING STANDARD OF DEVIATION FOR', values, ' with average', avg, ' and square diffs', squareDiffs, 'and average square diff', avgSquareDiff);

        let stdDev = Math.sqrt(avgSquareDiff);
        return stdDev;
    }

    generateStandardDeviation (myArray, mean = null, length = 0) {
        return this.standardDeviation(this.pluck(myArray), mean, length);
        //
        // console.log('[EXPERIMENTAL LETS PLUCK ]', this.pluck(myArray,'value'), );
        //
        // if (!mean) {
        //     mean = this.generateAverage(myArray);
        // }
        //
        // let total = 0;
        // for (let j = 0; j < myArray.length; j++) {
        //     total += Math.pow((myArray[j].value - mean), 2);
        // }
        // return Math.sqrt(total / (myArray.length - 1));
    }

    generateCoefficientOfVariation(stDev, mean) {
        if(mean===0) return mean;
        return stDev / mean;
    }

    roundTenth (x) {
        return Math.round(x*10)/10;
    }

    getAge (dateOfBirth) {
        let dob = new Date(dateOfBirth);
        let date = new Date();

        let age = date.getFullYear() - dob.getFullYear() - 1;

        if (date.getMonth() > dob.getMonth() ||
            date.getMonth() === dob.getMonth() && date.getDate() > dob.getDate() ) { age++; }

        return age;
    }
}