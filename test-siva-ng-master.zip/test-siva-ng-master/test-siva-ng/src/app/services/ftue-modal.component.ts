import {Component, OnInit} from "@angular/core";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {PouchDBService} from "./pouchdb.service";
import {FormBuilder, Validators} from "@angular/forms";
@Component({
    template: `
        <div class="modal-header">
            <h4 class="modal-title">First-Time User?</h4>
        </div>
        <div class="modal-body">
            <p>
                An internet connection is required to be able to download all necessary data. Operating this application
                offline will be possible but requires an internet connection to sync with the remote database.
                <br/>
                <br/>Please wait for downloading to complete before using the app.
            </p>

            <form *ngIf="!getPouch().currentUser" [formGroup]="loginForm" (ngSubmit)="loginFormSubmit()">
                <p>Log in to sync with the online database</p>

                <input type="text" class="form-control" formControlName="username" placeholder="Username">
                <input type="password" class="form-control" formControlName="password" placeholder="Password">

                <button type="submit" class="btn btn-primary" (disabled)="attemptingLogin">Login</button>
            </form>

            <div *ngIf="getPouch().currentUser">
                <p>You are logged in as: <b>{{ getPouch().currentUser.name }}</b></p>
                <p *ngIf="getPouch().hasRole('_admin')">
                    <b>This is an administrator account!</b> You will be able to modify all information.
                </p>
                <button class="btn btn-danger" (click)="logout()"> Logout</button>


                <md-select *ngIf="dbs" [(ngModel)]="selectedDB" (change)="dbChanged($event,selectedDB)" style="width: 100%; border-radius:5px; padding:5px;">
                    <md-option [value]="null">--Select a Database to Begin--</md-option>
                    <md-option *ngFor="let db of dbs" [value]="db">{{ db }}</md-option>
                </md-select>
            </div>

            <p *ngIf="selectedDB">
                <b>Database Status: </b> <span *ngIf="getStatus()">{{ getStatus() }}</span>
                <span *ngIf="!getStatus()">Attempting to connect...</span>
                <span *ngIf="getStatus() === 'Sync Paused'" style="color:green; font-weight:bold;">You can now continue!</span>
            </p>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" (click)="close()">Done</button>
        </div>
    `
})
export class FtueModalComponent implements OnInit {
    attemptingLogin = false;
    dbs;
    selectedDB = null;
    loginForm = this.fb.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
    });
    constructor (private activeModal: NgbActiveModal, private pouchService: PouchDBService, private fb: FormBuilder) { }

    ngOnInit () {
        this.pouchService.allDbs().then(dbs => {
            console.log('LOADING THESE DBS', dbs);
           this.dbs = dbs;
        });
        this.selectedDB = this.pouchService.selectedDB;
    }

    getPouch () {
        return this.pouchService;
    }

    dbChanged ($event, selectedDB) {
        console.log('changes', $event, selectedDB);

        if (!confirm('Are you sure? Database will start syncing with ' + selectedDB)) {
            this.selectedDB = null;
            return false;
        }

        this.pouchService.selectDatabase(selectedDB);
    }

    getStatus () {
        return this.pouchService.status;
    }

    close () {
        this.activeModal.close(true);
    }

    loginFormSubmit () {
        this.attemptingLogin = true;
        console.log('attempting to login');
        this.login(this.loginForm.value.username, this.loginForm.value.password).then(
            res => { console.log('LOGIN SUCCESS', res); this.attemptingLogin = false; },
            err => { console.error('LOGIN FAILURE', err); this.attemptingLogin = false; },
            fff => { console.log('Huh?'); }
        );
    }

    login(username, password) {
        return this.pouchService.login(username, password);
    }

    logout () {
        return this.pouchService.logout();
    }

}
