import {Injectable, Input, OnInit} from "@angular/core";
import {ProtocolService} from "../protocol/protocol.service";
import {PouchDBService} from "../services/pouchdb.service";
import {Observable} from "rxjs/Observable";
import {ReportService} from "../reports/report.service";
@Injectable()
export class FooterContextService {
    buttons = [];
    view = 'main';

    patients = [];
    patientsByDate = [];
    searchPatients = null;

    patientIndex = 0;
    testIndex = 0;
    protocols = [];

    patient: any;
    protocol: any = ''; // empty string needed for selection default value
    test: any;
    retestMode = false;

    retestObservable;
    retestObserver;

    reportObservable;
    reportObserver;

    testObservable;
    testObserver;

    patientObservable;
    patientObserver;

    protocolObservable;
    protocolObserver;

    customProtocol;
    reportsFrozen = false;

    protocolLoadFailed = false;

    constructor(
        private protocolService: ProtocolService,
        private pouchService: PouchDBService,
        private reportService: ReportService
    ) {}

    activateMain () { this.view = 'main'; }
    activateButtons (btns) { this.view = 'buttons'; this.buttons = btns; }

    // @todo: consider removing if the button isn't needed
    activateRetestMode () { this.retestMode = true; return this.retestObservable; }
    deactivateRetestMode () { this.retestMode = false; }

    activateReports () {
        this.view = 'report';
        return this.reportObservable;
    }

    freezeReports () {
        this.reportsFrozen = true;
    }

    unfreezeReports () {
        this.reportsFrozen = false;
    }

    generateMainReport () {
        this.reportObserver.next('main');
    }

    generateTechnicalReport () {
        this.reportObserver.next('tech');
    }

    customReport ($event) {

        let fr: FileReader = new FileReader();
        let file: File = $event.target.files[0];
        // let fileType = $event.target.parentElement.id;
        if(!file) {
            return;
        }

        fr.onloadend = (end) => {
            let result = fr.result.split('base64,')[1];
            // console.log('FINISHED', fr.result.split('base64,')[0] + 'base64,', file, result.length);

            this.reportService.acceptCustomFile(file, result).then(()=> {
                this.reportObserver.next('custom');
            });
            //
            // this.reports[type]._attachments = {};
            // // this.patientForm.patchValue({'Photo':file.name});
            // this.reports[type]._attachments[file.name] = {
            //     content_type: file.type,
            //     data: result
            // };
            //
            // this.reports[type].file = file.name;


        };
        // ((end:ProgressEvent, aah)=>{ console.log('FINISHED', end); });
        fr.readAsDataURL(file);

        $event.target.value = null;
        // console.log('find a way to remove this report from the input value', $event);
        // return false;
    }

    activateReportOptions () {
        console.log('Not yet implemented');
        return;
    }


    loadReviewProtocol(protocol) {
        this.protocol = this.customProtocol = protocol;
        this.test = protocol.tests[0];
        this.testChanged();
    }

    ngOnInit () {
        console.log('CONTEXT SERVICE INITIALIZING');
        this.patientObservable = new Observable(obs => this.patientObserver = obs);
        this.reportObservable = new Observable(obs => this.reportObserver = obs);
        this.retestObservable = new Observable(obs => this.retestObserver = obs);
        this.protocolObservable = new Observable(obs => this.protocolObserver = obs);
        this.testObservable = new Observable(obs => {this.testObserver = obs;});

        this.patient = this.remember('patient') || this.patient;
        this.protocol = this.remember('protocol') || this.protocol;
        this.test = this.remember('test') || this.test;
        let obj={
          FirstName:'SIVA',
          LastName:'KUMAR'
        }
        //this.patients.push(obj);
        this.patients.push(obj);
        // this.pouchService.allDocs({
        //     include_docs: true,
        //     startkey: 'PAT_',
        //     endkey: 'PAT_\uFFFF'
        // }).then(res => {
        //     res.rows.map(item => {
        //         //let obj = this.condensePatientForDropdownMenu(item.doc);
        //         let obj={
        //           FirstName:'SIVA',
        //           LastName:'KUMAR'
        //         }
        //         //this.patients.push(obj);
        //         this.patients.push(obj);
        //         this.patientsByDate.push(obj);
        //     });
        //     this.patients.sort((a, b) => {
        //         if (a.LastName < b.LastName) { return -1; }
        //         if (a.LastName > b.LastName) { return 1; }
        //         if (a.FirstName < b.FirstName) { return -1; }
        //         if (a.FirstName > b.FirstName) { return 1; }
        //         return 0;
        //     });
        //     this.patientsByDate.sort((a, b) => {
        //         return b.LastTestDate - a.LastTestDate;
        //     });
        //     for (let i = 0; i < this.patients.length; i++) {
        //         if (this.patient && this.patient._id === this.patients[i]._id) {
        //             this.patient = this.patients[i];
        //             this.patientIndex = i;
        //             break;
        //         }
        //     }
        // });
        //
        // //this.updateProtocols();
        //
        // console.log('footer-context.service::init() -- Loaded information', {
        //     patient: this.patient,
        //     protocol: this.protocol,
        //     test: this.test
        // });
    }

    clearCustomProtocol () {
        this.customProtocol = null;
    }

    updateProtocols () {
        return this.protocolService.promiseFormInfoLoaded().then(info => {
            this.protocolLoadFailed = false;
            let protocol;
            let test;
            this.protocols = [];
            info.protocols.map(item => {
                let obj = this.protocolService.populateTests(item);
                if (this.protocol.Name === obj.Name) {
                    protocol = obj;

                    // console.log('footer-context.service::updateProtocols() -- Protocol found, now searching for test:', this.test);
                    if (this.test) {
                        obj.tests.map((objTest, i) => {
                            if (objTest.name === this.test.name && objTest.code === this.test.code) {
                                test = objTest;
                                this.testIndex = i;

                                // console.log('footer-context.service::updateProtocols() -- Test found, updating index:', test, i);
                            }
                        });
                    }
                }
                this.protocols.push(obj);
            });

            if(!this.customProtocol) {
                this.protocol = protocol;
                this.test = test;
            }
        }).catch(err => {

            this.protocolLoadFailed = true;
            console.error('[CRITICAL] Could not load main protocols because', err);


            // this.protocol = this.customProtocol = {
            //     Name: '[ERROR] Protocols not available',
            //     tests: [{code: '...', name: 'Database may need to sync first.'}]
            // };
            // this.test = this.protocol.tests[0];
        });
    }

    remember(storageKey) {
        let item;
        if (item = localStorage.getItem(storageKey)) {
            try {
                return JSON.parse(item);
            } catch (e) {
                localStorage.removeItem(storageKey);
                return null;
            }
        }
    }

    condensePatientForDropdownMenu (doc) {
        doc._id = doc._id.substr(4);
        if (doc.LastTestDate) {
           doc.LastTestDate = new Date(doc.LastTestDate);
        }
        return doc;
        //
        // return {
        //     _id: doc._id.substr(4),
        //     LastName: doc.LastName,
        //     FirstName: doc.FirstName,
        //     LastTestDate: doc.LastTestDate ? new Date(doc.LastTestDate) : null
        // };
    }

    patientChanged ($event) {
        console.log('PATIENT CHANGED', $event, this.patient);

        // localStorage.setItem('patient', JSON.stringify());
        this.rememberCurrentPatient($event.value);

        for(let i = 0; i < this.patients.length; i++) {
            if(this.patient._id === this.patients[i]._id) {
                this.patientIndex = i;
                break;
            }
        }
        if(this.patientObserver) {

            this.patientObserver.next(this.patient);
        }
    }

    rememberCurrentPatient (data = null) {
        localStorage.setItem('patient', JSON.stringify(data ? data : this.patient));
    }

    protocolChanged ($event) {
        console.log('PROTOCOL CHANGED', $event, this.protocol);
        this.protocol = this.protocolService.populateTests(this.protocol);
        localStorage.setItem('protocol', JSON.stringify(this.protocol));

        this.test = this.protocol.tests[0];
        this.testChanged();
    }

    testChanged () {
        console.log('footer-context.service::testChanged() -- Saving the test as ', this.test);
        localStorage.setItem('test', JSON.stringify(this.test));

        if (this.test) {
            this.protocol.tests.map((objTest, i) => {

                if (objTest.name === this.test.name && objTest.code === this.test.code) {
                    // test = objTest;
                    console.log('TEST CHANGED::UPDATING TEST INDEX TO ', i);
                    this.testIndex = i;
                }
            });
        }
        if (this.testObserver) {
            this.testObserver.next(this.test);
        }
    }

    nextTest () {
        console.log(this.test);

        let nextTestFound = false;

        for (let i = 0; i < this.protocol.tests.length; i++) {
            if (this.test === this.protocol.tests[i]) {
                console.log('FOUND', this.protocol.tests[i]);
                nextTestFound = true;

                this.test = i + 1 !== this.protocol.tests.length ? this.protocol.tests[i + 1] : null;
                this.testIndex = i + 1;
                break;
            }
        }

        if (!nextTestFound) {
           console.error('Did not find current test');
        }

        this.testChanged();
    }


    goToPatientIndex (i) {
        i = Math.min(Math.max(0, i), this.getPatients().length - 1);
        this.patientIndex = i;
        this.patient = this.getPatients()[i];
    }

    getPatients () {
        return this.searchPatients || this.patients;
    }

    acceptPatientResults (results) {
        this.searchPatients = results;
        this.patientIndex = 0;
        this.patient = results[0] || {};
    }

    retest () {
        if (!confirm('You are about to PERMANENTLY DISCARD the RESULTS of the Current Test. Are you ABSOLUTELY SURE you want to do this?')) {
            return;
        }

        this.retestObserver.next(true);
    }
}
