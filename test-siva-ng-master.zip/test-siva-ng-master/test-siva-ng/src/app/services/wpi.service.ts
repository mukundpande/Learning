import {Injectable} from "@angular/core";
import {PouchDBService} from "../services/pouchdb.service";
import {TestService} from "../test/test.service";
import {CalculationsService} from "../services/calculations.service";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/do';
@Injectable()
export class WpiService {
    bodySections = [];
    sections = [];
    summary = {};
    shortsum = {};
    numbers = {};
    details = [];
    airsdetails: any = {};

    impDetails = {};
    cxTracking = {};
    lumbarCustom = {};

    private ABNORMAL_MOTION = 'ARC_airs_ABNORMALMOTION';
    private RANGES_SPINE = 'ARC_airs_RANGES SPINE';
    private RANGES_V4 = 'ARC_airs_RANGES V4';
    private RANGES = 'ARC_airs_RANGES';
    private STRENGTH_NORMS = 'ARC_airs_StrengthNorms';
    private TESTNAMES = 'ARC_airs_TESTNAMES';
    private BODYCODE = 'ARC_airs_BODYCODE';
    private CXDEF = 'ARC_airs_CXDEF';
    private RomTest = 'ARC_PROTOCOL_RomTest';
    private normsRM = 'ARC_norms_RM';
    private StaticTest = 'ARC_PROTOCOL_StaticTest';
    private AMPUTATIONS = 'ARC_airs_AMPUTATIONS';
    private AIRSNERVES = 'ARC_airs_NERVES';
    private AIRSTESTS = 'ARC_airs_TESTS';

    private abnormalmotions = [];
    private spineranges = [];
    private v4ranges = [];
    private ranges = [];
    private testnames = [];
    private bodycodes = [];
    private romtests = [];
    private statictests = [];
    private normsrm = [];
    private strengthnorms = [];
    private cxdefs = [];
    private amputations = [];
    private airsnerves = [];
    private airstests = [];


    private loaded = false;
    private promisedDocuments: any;

    private impairments = {};

    private patient;

    constructor (
      //private pouchService: PouchDBService,
      private testService: TestService,
      private calc: CalculationsService
    ) { }

init(){}
    // init () {
    //     this.promisedDocuments = this.pouchService.allDocs({
    //         keys: [this.RANGES_SPINE, this.TESTNAMES, this.BODYCODE, this.RomTest, this.normsRM, this.RANGES, this.RANGES_V4,
    //             this.ABNORMAL_MOTION, this.StaticTest, this.STRENGTH_NORMS, this.CXDEF, this.AMPUTATIONS, this.AIRSNERVES, this.AIRSTESTS],
    //         include_docs: true
    //     }).then(res => {
    //         res.rows.map(item => {
    //             switch (item.id) {
    //                 case this.ABNORMAL_MOTION:
    //                     this.abnormalmotions = item.doc.items;
    //                     break;
    //                 case this.RANGES_SPINE:
    //                     this.spineranges = item.doc.items;
    //                     break;
    //                 case this.RANGES_V4:
    //                     this.v4ranges = item.doc.items;
    //                     break;
    //                 case this.RANGES:
    //                     this.ranges = item.doc.items;
    //                     break;
    //                 case this.TESTNAMES:
    //                     this.testnames = item.doc.items;
    //                     break;
    //                 case this.BODYCODE:
    //                     this.bodycodes = item.doc.items;
    //                     break;
    //                 case this.RomTest:
    //                     this.romtests = item.doc.items;
    //                     break;
    //                 case this.normsRM:
    //                     this.normsrm = item.doc.items;
    //                     break;
    //                 case this.StaticTest:
    //                     this.statictests = item.doc.items;
    //                     break;
    //                 case this.STRENGTH_NORMS:
    //                     this.strengthnorms = item.doc.items;
    //                     break;
    //                 case this.CXDEF:
    //                     this.cxdefs = item.doc.items;
    //                     break;
    //                 case this.AMPUTATIONS:
    //                     this.amputations = item.doc.items;
    //                     break;
    //                 case this.AIRSNERVES:
    //                     this.airsnerves = item.doc.items;
    //                     break;
    //                 case this.AIRSTESTS:
    //                     this.airstests = item.doc.items;
    //                     break;
    //             }
    //         });
    //
    //         this.loaded = true;
    //     }, () => {
    //         console.error('COULD NOT GET THE AIRS BODY LOCATIONS');
    //     });
    // }

    promiseDocuments () {
        return this.promisedDocuments;
    }

    promiseSelectedEvaluated (selected) {
        let testsRendering = 0,
            testsCompleted = 0,
            resolve,
            promise = new Promise(r => resolve = r)
        for (let i = 0; i < selected.length; i++) {
            let series = selected[i];
            for(let x in series.tests) {
                if (true) {
                    testsRendering++;
                    this.evaluateResults(series.protocol.tests[x], series.tests[x].test).then(r => {
                        testsCompleted++;
                        // console.log('Finished Rendering Test', testsCompleted, '/',testsRendering);
                        if(testsCompleted == testsRendering) {
                            resolve();
                        }
                    });
                }
            }
        }
        return promise;
    }

    restartWpi (patient = null) {

        console.error('WPI has been restarted with', patient);

        this.bodySections = [];
        this.sections = [];
        this.impairments = {};
        this.impDetails = {};
        this.lumbarCustom = {};
        this.patient = patient;
        if(!this.patient) {
            console.error('WARNING: No patient selected.');
        }

        return this.promiseDocuments().then(r => {
            // now find the whole body (code 0) and add it
            for (let i = 0; i < this.bodycodes.length; i++) {
                if (+this.bodycodes[i].LOCATION === 0) {
                    let id = this.sections.push(this.bodycodes[i]);
                    this.sections[id - 1].impairment = 0;
                    break;
                }
            }


            // this.pouchService.get('PAT_' + this.patient._id).then(doc => {
            // this.patient = doc;
            // console.log('[wpi::restartWPI] PULLED PATIENT INFORMATION', this.patient);
            if (this.patient.amputations) {
                console.log('[wpi::restartWPI] AMPUTATIONS', this.patient.amputations);
                for (let i = 0; i < this.patient.amputations.length; i++) {
                    let amputation = this.patient.amputations[i];

                    let ampDef = this.locateAmputation(amputation.AMPUTATION, amputation.LOCATION);
                    // console.log('[wpi::restartWPI] LOADING AMPUTATION', amputation, ampDef);

                    this.registerImpairmentDetail(amputation.LOCATION, amputation.AMPUTATION, +ampDef.IMPAIRMENT, +ampDef.IMPAIRMENT, 'AMP');
                    this.registerImpairment(amputation.LOCATION, amputation.AMPUTATION, +ampDef.IMPAIRMENT);

                }
            } else {
                // console.log('[wpi::restartWPI] NO PATIENT AMPUTATIONS');
            }
        });

        // });

    }

    locateAmputation (name, code) {
        for (let i = 0; i < this.amputations.length; i++) {
            let amputation = this.amputations[i];
            if (amputation.AMPUTATION == name && (+amputation.DUAL && (amputation.LEFTBODYCODE == code || amputation.RIGHTBODYCODE == code) || !+amputation.DUAL && amputation.BODYCODE == code)) {
                return amputation;
            }
        }
        console.error('Could not find amputation for', name, code);
    }

    getStaticTest (test) {
        return this.promisedDocuments.then(() => {
            return this.formatStaticTest(test);
        });
    }

    private formatStaticTest (test) {
        let obj: any = {
            labels: ['LEFT', 'RIGHT']
        }

        obj.test = this.locateStaticTest(test);

        if(obj.test.Device === 'ST' || obj.test.TestMode === "BI") {
            obj.labels = [obj.test.TestName];
        }

        //console.log('Static Test Format Finished', obj);

        return obj;
    }

    private locateStaticTest (test) {
        for (let i = 0; i < this.statictests.length; i++) {
            if (this.statictests[i].Device === test.code && this.statictests[i].TestName === test.name) {
                return this.statictests[i];
            }
        }
        throw 'Could not find Static Test: ' + test.code + ' - ' + test.name;
    }

    getRomTest (test) {
        return this.promisedDocuments.then(() => {
            return this.formatRomTest(test);
        });
    }

    private formatRomTest (test) {
        let obj: any = {
            labels: ['LEFT', 'RIGHT']
        };

        obj.test = this.locateRomTest(test);

        let namechunks, firstchunk, lastchunk, tasknames;
        switch (obj.test.Device) {
            case 'EG':
                namechunks = test.name.split(' ');

                let split = null;

                for (let i = 0; i < namechunks.length; i++) {
                    if (namechunks[i].indexOf('/') !== -1) {
                        split = i;
                        break;
                    }
                }

                let firstchunks = namechunks.splice(0, split !== null ? split : 1);
                lastchunk = namechunks.join(' ');

                console.error('FORMATTING RM TEST');

                if(+obj.test.TwoWay !== 1) {
                    console.log('FORMAT TEST [EG] -- TwoWay not active');
                    obj.labels = [namechunks.join(' ') + ' ' + lastchunk];
                    obj.normA = this.searchNormRM(test.name);
                } else if (test.name.indexOf('/') !== -1) {
                    console.log('FORMAT TEST [EG] -- Slash in Test Name found');
                    tasknames = lastchunk.split('/');
                    obj.labels = this.testService.slashsplit(test.name);
                    for (let i = 0; i < obj.labels.length; i++) {
                        let label = obj.labels[i];
                        obj['norm' + ['A','B'][i]] = this.searchNormRM(firstchunks.join(' ') + ' ' + label);
                    }
                } else {
                    console.log('FORMAT TEST [EG] -- TwoWay, No Slash DEFAULT');
                    obj.labels = [namechunks.join(' ') + ' ' + lastchunk];
                    obj.normA = obj.normB = this.searchNormRM(test.name);
                }

                break;
            case 'RM':

                namechunks = test.name.split(' ');
                lastchunk = namechunks.pop();

                if (['LO','RO','BI'].indexOf(obj.test.TestMode) !== -1 && lastchunk.indexOf('/') === -1) {
                    obj.labels = [obj.test.OtherInfo];
                    obj.normA = this.searchNormRM(test.name);
                } else if (lastchunk.indexOf('/') !== -1) {
                    tasknames = lastchunk.split('/');
                    obj.labels = tasknames;
                    let prefix = namechunks.join(' ');
                    obj.normA = this.searchNormRM(prefix + ' ' + tasknames[0]);
                    obj.normB = this.searchNormRM(prefix + ' ' + tasknames[1]);
                } else {
                    obj.normA = obj.normB = this.searchNormRM(test.name);
                }
                break;
            default:
                throw 'Invalid device type: ' + obj.test.Device;
        }




        return obj;
    }

    private locateRomTest (test) {
        for (let i = 0; i < this.romtests.length; i++) {
            if (this.romtests[i].Device === test.code && this.romtests[i].TestName === test.name) {
                return this.romtests[i];
            }
        }
        throw 'Could not find ROM Test: ' + test.code + ' - ' + test.name;
    }

    private searchNormRM (name) {
        for (let i = 0; i < this.normsrm.length; i++) {
            if (this.normsrm[i].TaskName === name) {
                return this.normsrm[i];
            }
        }

        console.error('Could not find Norm for ', name);
    }

    isSecondCode(code, location) {
        // console.log(this.abnormalmotions[217], this.abnormalmotions[218]);

        for(let i = 0; i < this.abnormalmotions.length; i++) {
            let am = this.abnormalmotions[i];
            if(am.SECONDCODE === code && am.LOCATION === location) {
                // console.log('SECOND CODE MATCHED FOR', code, location, am);
                return true;
            }
        }
        // console.log('FAILED SECOND CODE MATCH', code, location);
        return false;
    }

    // Test	Occupation	Sex	MinAge	MaxAge	Major	Force
    findStrengthNorm (patient, code, isRight = false) {
        if(!patient) {
            return false;
        }

        if(!patient.DominantHand) {
            patient.DominantHand = "R";
        }

        // console.log('COMPARING PATIENT FOR NORM STRENGTH FIND', patient);

        let lbConversionRatio = +patient.Units === 1 ? 2.20462 : 1;

        let age = this.calc.getAge(patient.DateofBirth);

        let major = patient.DominantHand.toLowerCase() == 'r' && isRight || patient.DominantHand.toLowerCase() != 'r' && !isRight ? 1 : 0;

        for (let i = 0; i < this.strengthnorms.length; i++) {
            let norm = this.strengthnorms[i];
            //
            // if (patient.Sex.toLowerCase() == norm.Sex.toLowerCase() && norm.Test.toLowerCase() == code.toLowerCase()) {
            //     console.log('?YY?', patient, norm, age, patient.Sex, code);
            // }

            if (+norm.MinAge <= age && +norm.MaxAge >= age &&
                patient.Sex.toLowerCase() == norm.Sex.toLowerCase() &&
                norm.Test.toLowerCase() == code.toLowerCase() && [0,9].indexOf(+norm.Occupation) !== -1 &&
                +norm.Major == major) {
                // console.log('[FIND STRENGTH NORM] MATCH FOUND', norm);
                return +norm.Force * lbConversionRatio;
            }

        }

        return false;
    }

    findCXTest (name) {
        // console.log('[wpi::findCXTest] Searching for: ', name);
        for (let i = 0; i < this.cxdefs.length; i++) {
            let cxdef = this.cxdefs[i];
            if (cxdef.TESTNAME === name) {
                // console.log('[wpi::findCXTest]Found CX Def: ', {cxdef: cxdef, name: name});
                return cxdef;
            }
        }
        console.error('Could not find CX Definition for ', name);
    }

    loadTestOptionsByParams (params) {

        // 'RomTest': {
        //     devices: ['EG','RM']
        // },
        // 'StaticTest': {
        //     devices: ['CX','HD','PG','ST']

        switch(params.code) {
            case 'CX':
            case 'HD':
            case 'PG':
            case 'ST':
                for (let i = 0; i < this.statictests.length; i++) {
                    let statict = this.statictests[i];
                    if(statict.Device == params.code && statict.TestName == params.name) {
                        return statict;
                    }
                }
                break;
            case 'EG':
            case 'RM':
                for (let i = 0; i < this.romtests.length; i++) {
                    let rom = this.romtests[i];
                    if(rom.Device == params.code && rom.TestName == params.name) {
                        return rom;
                    }
                }
                break;
            default:
                console.error('Cannot load test options for code', params.code);
                break;
        }
    }

    evaluateResults (test, data) {
        return this.promiseDocuments ().then( () => {
            // console.log('[WPI::evaluateResults] -- ', test, data);

            let testOptions = this.loadTestOptionsByParams(test);
            // if(!testOptions || testOptions.Distraction && test.code !== 'RM') { return; }
            let distraction = !testOptions ? false : testOptions.Distraction;

            let testInfo, testInfoL, testInfoR, impA, impB, impAR, impAL, impBR, impBL, normL, normR;
            switch (test.code) {
                case 'CX':
                    // console.log('[CX] Received Muscle Test Data!', test, data);

                    let cxdef = this.findCXTest(test.name);
                    // console.log('[CX] Registering Test Details', {cxdef: cxdef, test: test, data: data});
                    if(!cxdef) { console.error('[CX] Missing definition for', test); break; }

                    if (!this.cxTracking[cxdef.FAMILY]) {
                        this.cxTracking[cxdef.FAMILY] = {
                            tests: {},
                            def: cxdef
                        }
                    }

                    let leftM = this.calc.generateAverage(data.trialsA),
                        rightM = this.calc.generateAverage(data.trialsB);

                    let obj = {
                        left: 0,
                        right: 0,
                        deficiency: 0,
                        side: null
                    }

                    if(leftM > rightM) {
                        obj.side = 'R';
                        obj.deficiency = (1 - rightM/leftM)
                    } else if (leftM < rightM) {
                        obj.side = 'L';
                        obj.deficiency = (1 - leftM/rightM)
                    }
                    // TESTNAME	SCALETYPE: GRADE, MOTOR	FAMILY	MAX	GRADE1	GRADE2	GRADE3	GRADE4	FOOT

                    if(obj.side && obj.deficiency >= 0.13) {
                        let useSide = obj.side == 'L' ? 'left' : 'right';
                        if(cxdef.SCALETYPE == "GRADE") {
                            if (obj.deficiency >= 0.01 && obj.deficiency < 0.26) {
                                obj[useSide] = +cxdef.GRADE4;
                            } else if (obj.deficiency >= 0.26 && obj.deficiency < 0.51) {
                                obj[useSide] = +cxdef.GRADE3;
                            } else if (obj.deficiency >= 0.51 && obj.deficiency < 0.76) {
                                obj[useSide] = +cxdef.GRADE2;
                            } else if (obj.deficiency >= 0.76 && obj.deficiency < 1) {
                                obj[useSide] = +cxdef.GRADE1;
                            } else if (obj.deficiency >= 1) {
                                obj[useSide] = +cxdef.MAX;
                            }
                        } else if (cxdef.SCALETYPE == "MOTOR") {
                            obj[useSide] = +cxdef.MAX * obj.deficiency;
                        }
                    }

                    // console.log('[CX] Rendering Object', leftM, rightM, obj);

                    this.cxTracking[cxdef.FAMILY].tests[test.name] = obj;

                    //then render the average for impairment for both sides

                    let trackingFamilies = Object.keys(this.cxTracking);

                    for (let k = 0; k < trackingFamilies.length; k++) {
                        let family = this.cxTracking[trackingFamilies[k]];
                        // console.error('[CX] NOW RENDERING AVERAGES FOR ', family);

                        let familyTests = Object.keys(family.tests);
                        let left = 0, right = 0, deficiencyLeft = 0, deficiencyRight = 0;
                        for (let m = 0; m < familyTests.length; m++) {
                            let famTest = family.tests[familyTests[m]];
                            left += famTest.left;
                            right += famTest.right;

                            deficiencyLeft += famTest.side == 'L' ? famTest.deficiency : 0;
                            deficiencyRight += famTest.side == 'R' ? famTest.deficiency : 0;
                        }
                        if (family.def.FAMILY.length) {
                            this.registerImpairmentDetail(family.def.LEFT, family.def.FAMILY, this.calc.roundTenth(leftM), left / familyTests.length, test.code, deficiencyLeft / familyTests.length, distraction);
                            this.registerImpairmentDetail(family.def.RIGHT, family.def.FAMILY, this.calc.roundTenth(rightM), right / familyTests.length, test.code, deficiencyRight / familyTests.length, distraction);
                            this.registerImpairment(family.def.LEFT, family.def.FAMILY, this.calc.roundTenth(left / familyTests.length), distraction);
                            this.registerImpairment(family.def.RIGHT, family.def.FAMILY, this.calc.roundTenth(right / familyTests.length), distraction);
                        }

                    }

                    break;
                case 'HD':
                case 'PG':
                    // console.log('[wpi::evaluateResults] >> HD/PG Test Found', test, data, this.patient);
                    if (!(testInfoR = this.locateTestImpairmentInfo(test.name, 'Right')) || !(testInfoL = this.locateTestImpairmentInfo(test.name, 'Left'))) {
                        return;
                    }
                    normL = this.findStrengthNorm(this.patient, testInfoL.TESTCODE1)
                    normR = this.findStrengthNorm(this.patient, testInfoL.TESTCODE1, true)

                    if(!normL || !normR) {
                        console.error('ST Norm not found for', this.patient, data);
                        return;
                    }

                    // console.log('HD/PG with norms', normL, normR, data);

                    impA = 0;
                    impB = 0;

                    let averageL = this.calc.generateAverage(data.trialsA),
                        averageR = this.calc.generateAverage(data.trialsB);

                    let ratioL = averageL / normL,
                        ratioR = averageR / normR;

                    // console.log('RATIOS GENERATED: ', ratioL, ratioR);

                    if (ratioL <= 0.395) {
                        impA = 33;
                    } else if (ratioL <= 0.695) {
                        impA = 22;
                    } else if (ratioL <= 0.895) {
                        impA = 11;
                    }

                    if (ratioR <= 0.395) {
                        impB = 33;
                    } else if (ratioR <= 0.695) {
                        impB = 22;
                    } else if (ratioR <= 0.895) {
                        impB = 11;
                    }

                    let useTestNames = {
                        'STANDARD': 'Grip Strength',
                        'KEY': 'Pinch Strength'
                    }

                    let name = useTestNames[test.name] || test.name;

                    this.registerImpairmentDetail(testInfoL.LOCATION, name, this.calc.roundTenth(averageL), impA, test.code, 1 - ratioL, distraction);
                    this.registerImpairmentDetail(testInfoR.LOCATION, name, this.calc.roundTenth(averageR), impB, test.code, 1 - ratioR, distraction);

                    this.registerImpairment(testInfoL.LOCATION, name, impA, distraction);
                    this.registerImpairment(testInfoR.LOCATION, name, impB, distraction);


                    break;
                case 'EG':
                    let testInfoAR, testInfoAL;
                    if (!(testInfoAR = this.locateTestImpairmentInfo(test.name, 'Right')) || !(testInfoAL = this.locateTestImpairmentInfo(test.name, 'Left'))) {
                        return;
                    }
                    let secondCodeAR = this.isSecondCode(testInfoAR.TESTCODE1, testInfoAR.LOCATION),
                        secondCodeAL = this.isSecondCode(testInfoAL.TESTCODE1, testInfoAL.LOCATION),
                        secondCodeBR = this.isSecondCode(testInfoAR.TESTCODE2, testInfoAR.LOCATION),
                        secondCodeBL = this.isSecondCode(testInfoAL.TESTCODE2, testInfoAL.LOCATION);
                    // if (testInfoAR.TESTCODE1 === "B" && testInfoAR.LOCATION === "14") {
                    //     specialRatioAR = -1;
                    // }
                    //
                    // if (testInfoAL.TESTCODE1 === "B" && testInfoAL.LOCATION === "24") {
                    //     specialRatioAL = -1;
                    // }
                    // if (testInfoAR.TESTCODE2 === "B" && testInfoAR.LOCATION === "31") {
                    //     specialRatioBR = -1;
                    // }
                    //
                    // if (testInfoAL.TESTCODE2 === "B" && testInfoAL.LOCATION === "41") {
                    //     specialRatioBL = -1;
                    // }
                    impAR = this.generateAirsRangeImpairment(
                        testInfoAR.LOCATION, testInfoAR.TESTCODE1, testInfoAR.IMPAIRMENTCODE,
                        testInfoAR.EDITION, data.romAR, secondCodeAR
                    );
                    impAL = this.generateAirsRangeImpairment(
                        testInfoAL.LOCATION, testInfoAL.TESTCODE1, testInfoAL.IMPAIRMENTCODE,
                        testInfoAL.EDITION, data.romAL, secondCodeAL
                    );

                    impBR = this.generateAirsRangeImpairment(
                        testInfoAR.LOCATION, testInfoAR.TESTCODE2, testInfoAR.IMPAIRMENTCODE,
                        testInfoAR.EDITION, data.romAR, secondCodeBR
                    );
                    impBL = this.generateAirsRangeImpairment(
                        testInfoAL.LOCATION, testInfoAL.TESTCODE2, testInfoAL.IMPAIRMENTCODE,
                        testInfoAL.EDITION, data.romAL, secondCodeBL
                    );

                    if(test.name.indexOf('/') !== -1) {
                        let names = this.testService.slashsplit(test.name, true);
                        this.registerImpairmentDetail(testInfoAR.LOCATION, names[0], data.romAR, impAR, 'EG',0,distraction);
                        this.registerImpairmentDetail(testInfoAL.LOCATION, names[0], data.romAL, impAL, 'EG',0,distraction);
                        this.registerImpairmentDetail(testInfoAR.LOCATION, names[1], data.romAR, impBR, 'EG',0,distraction);
                        this.registerImpairmentDetail(testInfoAL.LOCATION, names[1], data.romAL, impBL, 'EG',0,distraction);
                    } else {
                        this.registerImpairmentDetail(testInfoAR.LOCATION, test.name, data.romAR, impAR, 'EG',0,distraction);
                        this.registerImpairmentDetail(testInfoAL.LOCATION, test.name, data.romAL, impAL, 'EG',0,distraction);
                    }
                    this.registerImpairment(testInfoAR.LOCATION, test.name, impAR+impBR, distraction);
                    this.registerImpairment(testInfoAL.LOCATION, test.name, impAL+impBL, distraction);
                    break;
                case 'RM':
                    if (test.name.indexOf('Straight Leg Raise') != -1) {
                        console.error('STRAIGHT LEG RAISE, FIND THE THORACIC', test.name);
                        this.registerThoracicCustom(test.name, data.romA);
                    } else if (test.name.indexOf('Lumbar Flexion/Extension') != -1) {
                        console.error('DETECTED LUMBAR FLEXION & EXTENSION', data);
                        this.registerThoracicCustom('Sacral Flexion Angle', data.lowerA);
                        this.registerThoracicCustom('Total Sacral (Hip) Motion', '', data.lowerA - data.lowerB);
                    }
                    if(!testOptions || testOptions.Distraction) {
                        return;
                    }

                    if (!(testInfo = this.locateTestImpairmentInfo(test.name))) {
                        return;
                    }
                    if (test.name.indexOf('Straight Leg Raise') != -1) {
                        console.error('STRAIGHT LEG RAISE, FIND THE THORACIC', test.name, testInfo);
                    }

                    console.log('RUNNING RM TEST IMPAIRMENT', {test: test, data: data});


                    impA = this.generateAirsSpineImpairment(
                        testInfo.LOCATION, testInfo.TESTCODE1, testInfo.IMPAIRMENTCODE,
                        testInfo.EDITION, data.romA, data.lowerA
                    );
                    impB = this.generateAirsSpineImpairment(
                        testInfo.LOCATION, testInfo.TESTCODE2, testInfo.IMPAIRMENTCODE,
                        testInfo.EDITION, data.romB
                    );
                    if(test.name.indexOf('/') !== -1) {
                        let names = this.testService.slashsplit(test.name, true);
                        // this.registerImpairmentDetail(testInfo.LOCATION, names[0], data.romA, impA, 'RM');
                        // this.registerImpairmentDetail(testInfo.LOCATION, names[1], data.romB, impB, 'RM');

                        // this.registerMotionImpairmentDetail(testInfo.LOCATION, test.name, data.romA, impA, data.romB, impB);
                    } else {
                        // console.error('IS THIS A DUAL?', {
                        //     location: testInfo.LOCATION,
                        //     name: test.name,
                        //     romA: data.romA,
                        //     romB: data.romB,
                        //     impA: impA,
                        //     impB: impB
                        // });
                        this.registerImpairmentDetail(testInfo.LOCATION, test.name, data.romA, impA, 'RM', 0, distraction);
                    }
                    this.registerMotionImpairmentDetail(testInfo.LOCATION, test.name, data.romA, impA, data.romB, impB, distraction);
                    console.log('REGISTERING IMPAIRMENT for RM', [testInfo.LOCATION, test.name, impA + impB, distraction]);
                    this.registerImpairment(testInfo.LOCATION, test.name, impA + impB, distraction);
                    break;
                default:
                    break;
            }

            this.renderResults();
        })
    }

    registerThoracicCustom (name, angle:any, rom:any = '') {
        this.lumbarCustom[name] = {
            angle: angle,
            rom: rom
        };
    }

    registerMotionImpairmentDetail (bodycode, testname, resultA, impairmentA, resultB, impairmentB, distraction = false) {
        if (bodycode.length > 1) {
            let maincode = bodycode.substr(0,1);
            let location = this.registerBodyLocation(bodycode);
            let mainlocation = this.registerBodyLocation(maincode);
            if (!this.impDetails[mainlocation.LOCATION]) {
                this.impDetails[mainlocation.LOCATION] = {
                    title: mainlocation.DESCRIP,
                    location: mainlocation.LOCATION,
                    regions: {},
                }
            }
            if (bodycode.length >= 2) {
                let regioncode = bodycode.substr(0,2);
                let regionlocation = this.registerBodyLocation(regioncode);
                if(!this.impDetails[mainlocation.LOCATION].regions[regioncode]) {
                    this.impDetails[mainlocation.LOCATION].regions[regioncode] = {
                        region: regionlocation,
                        code: 'RM',
                        impairments: {},
                        motionimpairments: [],
                        steps: []
                    }
                }
                let obj = {
                    name: testname,
                    resultA: resultA,
                    resultB: resultB,
                    impairmentA: impairmentA,
                    impairmentB: impairmentB,
                    code: 'RM',
                    bodycode: bodycode
                };
                let stepFound = false;
                for (let s = 0; s < this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments.length; s++) {
                    let step = this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments[s];

                    if (step.name === testname && step.code === 'RM') {
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments[s].resultA = resultA;
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments[s].impairmentA = impairmentA;
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments[s].resultB = resultB;
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments[s].impairmentB = impairmentB;
                        // console.log('[wpi::registerImpairmentDetail] replacing step');
                        stepFound = true;
                        break;
                    }
                }
                if(!stepFound) {
                    // console.log('appending step');
                    this.impDetails[mainlocation.LOCATION].regions[regioncode].motionimpairments.push(obj);
                }
                // console.log('[wpi::registerImpairmentDetail] STEPS NOW FOR', mainlocation.LOCATION, '/', regioncode, this.impDetails[mainlocation.LOCATION].regions[regioncode].steps);
            } else {
                // console.log('[wpi::registerImpairmentDetail] Code is too short (>=2), not adding...');
            }
        } else {
            // console.log('[wpi::registerImpairmentDetail] Code is too short (>1), skipping...');
        }

        if(testname.indexOf('/') !== -1) {
            let names = this.testService.slashsplit(testname, true);
            // this.registerImpairmentDetail(testInfo.LOCATION, names[0], data.romA, impA, 'RM');
            // this.registerImpairmentDetail(testInfo.LOCATION, names[1], data.romB, impB, 'RM');
            this.registerImpairmentDetail(bodycode, names[0], resultA, impairmentA, 'RM', 0, distraction);
            this.registerImpairmentDetail(bodycode, names[1], resultB, impairmentB, 'RM', 0, distraction);

            // this.registerMotionImpairmentDetail(testInfo.LOCATION, test.name, data.romA, impA, data.romB, impB);
        } else {
            // console.error('IS THIS A DUAL?', {
            //     location: testInfo.LOCATION,
            //     name: test.name,
            //     romA: data.romA,
            //     romB: data.romB,
            //     impA: impA,
            //     impB: impB
            // });
            this.registerImpairmentDetail(bodycode, testname, (resultA+resultB)/2, (impairmentA+impairmentB)/2, 'RM', 0, distraction);
        }
    }

    registerImpairmentDetail(bodycode, testname, result, impairment, code = '?', deficiency = 0, distraction = false) {
        // console.error('[wpi::registerImpairmentDetail] Register Impairment Detail', {bodycode: bodycode, name: testname, result: result, impairment: impairment, code: code});
        if (bodycode.length > 1) {
            let maincode = bodycode.substr(0,1);
            let location = this.registerBodyLocation(bodycode);
            let mainlocation = this.registerBodyLocation(maincode);
            if (!this.impDetails[mainlocation.LOCATION]) {
                this.impDetails[mainlocation.LOCATION] = {
                    title: mainlocation.DESCRIP,
                    location: mainlocation.LOCATION,
                    regions: {},
                }
            }
            if (bodycode.length >= 2) {
                let regioncode = bodycode.substr(0,2);
                let regionlocation = this.registerBodyLocation(regioncode);
                if(!this.impDetails[mainlocation.LOCATION].regions[regioncode]) {
                    this.impDetails[mainlocation.LOCATION].regions[regioncode] = {
                        region: regionlocation,
                        code: code,
                        impairments: {},
                        motionimpairments: [],
                        steps: []
                    }
                }

                let impairmentCodes = {
                    'HD': 8,
                    'PG': 8,
                    'CX': 3,
                    'EG': 2,
                    'RM': 2,
                    'AMP': '0',
                }

                if(impairmentCodes[code] !== undefined && !this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]]) {
                    this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]] = [];
                } else if (!impairmentCodes[code] !== undefined) {
                    // console.log('[wpi::registerImpairmentDetail] -- no impairments code match');
                }
                let distractionRatio = distraction ? 0 : 1;
                    impairment = Math.round(impairment*100*distractionRatio)/100;

                let obj = {
                    name: testname,
                    result: result,
                    impairment: impairment,
                    code: code,
                    deficiency: deficiency,
                    distraction: distraction
                };

                let stepFound = false;

                for (let s = 0; s < this.impDetails[mainlocation.LOCATION].regions[regioncode].steps.length; s++) {
                    let step = this.impDetails[mainlocation.LOCATION].regions[regioncode].steps[s];

                    if (step.name === testname && step.code === code) {
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].steps[s].result = result;
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].steps[s].impairment = impairment;
                        // console.log('[wpi::registerImpairmentDetail] replacing step');
                        stepFound = true;
                        break;
                    }
                }

                if(!stepFound) {
                    // console.log('appending step');
                    this.impDetails[mainlocation.LOCATION].regions[regioncode].steps.push(obj);
                }

                // console.log('[wpi::registerImpairmentDetail] STEPS NOW FOR', mainlocation.LOCATION, '/', regioncode, this.impDetails[mainlocation.LOCATION].regions[regioncode].steps);

                if(impairmentCodes[code]) {

                    stepFound = false;

                    for (let s = 0; s < this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]].length; s++) {
                        let step = this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]][s];

                        if (step.name === testname && step.code === code) {
                            this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]][s].result = result;
                            this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]][s].impairment = impairment;
                            // console.log('[wpi::registerImpairmentDetail] replacing step');
                            stepFound = true;
                            break;
                        }
                    }

                    if(!stepFound) {
                        // console.log('appending step');
                        this.impDetails[mainlocation.LOCATION].regions[regioncode].impairments[impairmentCodes[code]].push(obj);
                    }

                }


            } else {
                // console.log('[wpi::registerImpairmentDetail] Code is too short (>=2), not adding...');
            }
        } else {
            // console.log('[wpi::registerImpairmentDetail] Code is too short (>1), skipping...');
        }
    }

    generateAirsV4RangeImpairment (location, testcode, impairmentcode, edition, value, isSecondCode = false) {

         //console.log('comparing v4', location, testcode, value, isSecondCode ? 'Second' : 'First');

        let matches = [];
        let maxMatch;

        for (let i = 0; i < this.v4ranges.length; i++) {
            // LOCATION	TESTCODE	LOWER	UPPER	IMPAIRMENT	EDITION	IMPAIRMENTCODE
            let range = this.v4ranges[i];
            //find the least distance

            if(range.LOCATION === location && range.TESTCODE === testcode && range.IMPAIRMENTCODE === impairmentcode && range.EDITION === edition) {
                if (!isSecondCode && range.LOWER <= value && range.UPPER >= value) {
                    // console.log('Found the v4 result (reversal OFF) -- ', range);
                    return +range.IMPAIRMENT;
                }

                matches.push(range);
                //console.log('location and range match @ row ', i, range);

                if(!maxMatch || range.LOWER > maxMatch.LOWER) {
                    //console.log('LOWER is higher, switching to ', range.LOWER, range);
                    maxMatch = range;
                }

            }


        }

        if (!matches.length) {
            //console.log('NO MATCHES IN v4 FOUND');
            return;
        }

        for (let i = 0; i < matches.length; i++) {
            let range = matches[i];
            //console.log('matches -- ', matches[i]);
            let result = +maxMatch.LOWER - value;

            if (range.LOWER <= result && range.UPPER >= result) {
                // console.log('FOUND THE v4 RESULT', +maxMatch.LOWER, '-', value, '=' , result, range);
                return +range.IMPAIRMENT;
            }
        }
        // console.log('COULD NOT FIND v4 RECORDs');
        return 0;
    }

    generateAirsRangeImpairment (location, testcode, impairmentcode, edition, value, isSecondCode = false) {
        let closestMin, closestMax;

        let v4outcome = this.generateAirsV4RangeImpairment(location, testcode, impairmentcode, edition, value, isSecondCode);

        if (v4outcome !== undefined && v4outcome !== null) {
            // console.log('V4 outcome is ', v4outcome);
            return v4outcome;
        }

        if (isSecondCode) {
            value *= -1;
        }

        // console.log('comparing', location, testcode, edition, value);
        for (let i = 0; i < this.ranges.length; i++) {
            // LOCATION	TESTCODE	RESULT	IMPAIRMENT	EDITION
            let range = this.ranges[i];
            //find the least distance

            if (range.LOCATION === location && range.TESTCODE === testcode && range.EDITION === edition) {
                //console.log('valid, now compare the values', range);

                if (+range.RESULT >= value && (!closestMax || +range.RESULT < +closestMax.RESULT)) {
                    closestMax = range;
                    //console.log(range, 'is now the maximum');
                }
                if (+range.RESULT <= value && (!closestMin || +range.RESULT > +closestMin.RESULT)) {
                    closestMin = range;
                    //console.log(range, 'is now the minimum');
                }
            }
        }

        //should have
        if (!closestMin || !closestMax){
            // console.log('COULD NOT FIND ANY RECORDS HERE -- PERHAPS TRY V4?');
            return 0;
        }
        // console.log('Airs Range Impairment for ', location, testcode, value, 'resolves to', closestMin, 'and', closestMax);

        let min = +closestMin.RESULT;
        let max = +closestMax.RESULT;

        let midway = min + ((max > min ? max - min : min - max)/2);
        // console.log(value, 'is between', min, 'and', max, 'must be >= ', midway, ' to go to the max result');

        if(value >= midway) {
            // console.log('using max impairment', closestMax.IMPAIRMENT);
            return +closestMax.IMPAIRMENT;
        } else {
            // console.log('using min impairment', closestMin.IMPAIRMENT);
            return +closestMin.IMPAIRMENT;
        }
    }

    generateAirsSpineImpairment (location, testcode, impairmentcode, edition, value, lower = 0) {

        for (let i = 0; i < this.spineranges.length; i++) {
            let range = this.spineranges[i];

            let lumbarFlexionException = true;
            if(+location === 53 && testcode === 'A')
            {
                lumbarFlexionException = +range['LOW SACRAL'] <= lower && +range['HIGH SACRAL'] >= lower;
            }

            if (
                range.LOCATION === location && range.TESTCODE === testcode && range.IMPAIRMENTCODE === impairmentcode
                && range.EDITION === edition && range.MINIMUM <= value && range.MAXIMUM >= value && lumbarFlexionException
            ) {
                // console.log('FOUND THE RESULT', range);
                let max = +range.MAXIMUM;
                let min = +range.MINIMUM;
                let minimumForMaximum = min + (max - min) / 2;

                // console.log(value, 'must be higher than', minimumForMaximum,
                //     'to render to', +range.MAXIMPAIRMENT, ' otherwise ', +range.MINIMPAIRMENT);

                return value >= minimumForMaximum ? +range.MAXIMPAIRMENT : +range.MINIMPAIRMENT;
            }
        }

        //console.log('found no result');

        return 0;
    }

    locateTestImpairmentInfo (name, location = '') {
        for (let i = 0; i < this.testnames.length; i++) {
            if (+this.testnames[i].EDITION === 4 && this.testnames[i].TESTNAME === name) {

                let bodyRecord = this.findBodyLocation(this.testnames[i].LOCATION);
                let len = location.length;
                if(bodyRecord.DESCRIP.substr(0,len) === location) {
                    return this.testnames[i];
                }
            }
        }
    }

    registerImpairment (location, name, value, distraction = false) {
        if (!this.impairments[location]) {
           this.impairments[location] = {};
        }

        this.impairments[location][name] = {
            value: value,
            distraction: distraction
        };
    }

    registerBodyLocation (x) {
        if(!this.summary[x]) {
            let location = this.findBodyLocation(x);

            if(!location) {
                return false;
            }

            location.impairment = 0;
            location.tests = {};
            this.summary[x] = location;
        }
        return this.summary[x];
    }

    findTestReference (bodycode, impairmentcode, name) {
        // console.log('searching for test reference', {bodycode:bodycode,impairmentcode:impairmentcode,name:name});

        for (let i = 0; i < this.airstests.length; i++) {
        //    LOCATION	TESTNAME	IMPAIRMENTCODE
            let test = this.airstests[i];
            if(bodycode == test.LOCATION && impairmentcode == test.IMPAIRMENTCODE && name == test.TESTNAME && test.EDITION == 4) {
                return 'P.' + test.PAGE + ', ' + test.TABLE;
            }
        }

        console.error('Could not locate test reference for', {bodycode:bodycode,impairmentcode:impairmentcode,name:name});
        return '';
    }
    findNerveReference (bodycode, name) {
        // console.log('searching for nerve reference', {bodycode:bodycode,name:name});

        if(bodycode == '23') {
            bodycode = '24';
        } else if (bodycode == '13') {
            bodycode = '14';
        }

        for (let i = 0; i < this.airsnerves.length; i++) {
            // Location, Nerve
            let test = this.airsnerves[i];
            if(bodycode == test.Location && name == test.Nerve && test.Edition == 4) {
                return 'P.' + test.PAGE + ', ' + test.TABLE;
            }
        }

        // console.error('Could not locate nerve reference for', {bodycode:bodycode,name:name});
        return '';
    }

    filterTestNamePrefixes (x) {
        return x.replace('Cervical ','').replace('Lumbar ','');
    }

    renderResults () {
        this.bodySections = [];
        this.sections = [];
        this.summary = {};
        this.shortsum = {};
        this.details = [];
        this.airsdetails = {
            amputation: [],
            motion: [],
            nerve: [],
            strength: []
        }

        this.registerBodyLocation(0);
        // console.log('[WPI::renderResults] + RENDERING RESULTS', this.impairments);
        for (let x in this.impairments) {
            if (true) {
                for (let y in this.impairments[x]) {
                    if (true) {
                        // console.log('sending impairment data', x, y, this.impairments[x][y]);
                        this.cascadeImpairments(x, y, this.impairments[x][y].value, this.impairments[x][y].distraction);
                    }
                }
            }
        }
        let keys = Object.keys(this.summary);
        keys.sort();

        // console.log('[WPI::renderResults] + summary keys rendering', this.summary, keys);

        for(let i = 0; i < keys.length; i++ ) {
            let x = keys[i];
            let section = this.summary[x];

            // console.log('[wpi::renderResults/for(0..key.length)] executing key', keys[i], 'summary section', section);

            this.shortsum['i'+x] = section.impairment + '%';

            let pushedSection = {
                DESCRIP: section.DESCRIP,
                impairment: section.impairment
            };
            this.bodySections.push(pushedSection);
            this.sections.push(pushedSection);
            for (let j in section.tests) {
                if (true) {
                    this.sections.push({
                        DESCRIP: j,
                        impairment: section.tests[j]
                    });
                }
            }
        }

        // console.log('[wpi::renderResults] -- So by the end of all of this, body sections registered as', this.bodySections, 'and regular sections', this.sections);
        // console.log('[wpi::renderResults()]: impDetails !!! RENDERING THE RESULT DETAILS NOW, GIVEN', this.impDetails, 'Summary: ',  this.summary);

        let detailKeys = Object.keys(this.impDetails);

        let globalObj = {
            title: 'Whole Person Impairment',
            sections: [{
                text: 'Whole Person: ',
                subsections: []
            }],
        }
        let globalImpairment = 0;

        for (let i = 0; i < detailKeys.length; i++) {
            // console.log('[wpi::renderResults()]: --impDetails', this.impDetails[detailKeys[i]]);

            let imp = this.impDetails[detailKeys[i]];

            let impairmentSection = {
                title: imp.title + ' Impairment',
                sections: []
            };

            let totalSubsection = {
                steps: [],
                text: imp.title
            }

            let totalImpairment = 0;

            if(imp.regions){
                let regionKeys = Object.keys(imp.regions);
                for (let j = 0; j < regionKeys.length; j++) {
                    let region = imp.regions[regionKeys[j]];
                    // console.log('--impRegion', region);

                    let regionSection = {
                        subsections: [],
                        text: region.region.DESCRIP
                    }

                    let impairmentKeys = Object.keys(region.impairments);

                    let impairmentStatuses = {
                        "0": "Amputation",
                        "2": "Abnormal Motion",
                        "3": "Nerve Disorder",
                        "8": "Muscle Function"
                    };


                    for (let r = 0; r < region.motionimpairments.length; r++) {
                        //MOTION IMPAIRMENTS
                        let motion = region.motionimpairments[r],
                            sectionName = this.registerBodyLocation(regionKeys[j]),
                            steps = [];

                        let names = this.testService.slashsplit(motion.name);

                        // console.error('REGISTERING DOUBLE MOTION PAIRING', {motion: motion, names: names});

                        let ref = this.findTestReference(regionKeys[j], '2', names.join(' and ').replace('Cervical ','').replace('Lumbar ',''));

                        steps.push({
                            name: sectionName.DESCRIP,
                            movement: '',
                            angle: '',
                            rom: motion.resultA,
                            imp: motion.impairmentA,
                            ref: ref
                        });
                        steps.push({
                            name: '',
                            movement: '',
                            angle: '',
                            rom: motion.resultB,
                            imp: motion.impairmentB,
                            ref: ''
                        });

                        if (names.length > 1) {
                            steps[0].movement = names[0];
                            steps[1].movement = names[1];
                        } else {
                            steps[0].movement = 'Left ' + names[0].replace('Cervical ','').replace('Lumbar ','');
                            steps[1].movement = 'Right ' + names[0].replace('Cervical ','').replace('Lumbar ','');
                        }

                        if(motion.name == 'Lumbar Flexion/Extension') {
                            let lumbarKeys = Object.keys(this.lumbarCustom);
                            for (let m = 0; m < lumbarKeys.length; m++) {
                                let lumline = this.lumbarCustom[lumbarKeys[m]];
                                console.error('Adding Lumbar Key', lumline);

                                steps.push({
                                    name: lumbarKeys[m],
                                    movement: '',
                                    angle: lumline.angle,
                                    rom: lumline.rom,
                                    imp: '',
                                    ref: ''
                                });
                            }

                        }

                        // console.log('ADDING THE MOTION STEPS', steps);

                        this.airsdetails.motion.push({
                            lines: steps
                        });
                    }
                    // console.log('[wpi::renderResults()]: so the keys for this region would be... ', impairmentKeys);
                    for (let m = 0; m < impairmentKeys.length; m++) {
                        // let impairmentSection = region.impairments[impairmentKeys[m]];

                        let impairmentSubsection = {
                            text: impairmentStatuses[impairmentKeys[m]] + ': ',
                            steps: []
                        }

                        let addSteps = [];
                        let total = null;
                        //

                        let regionImpairments = region.impairments[impairmentKeys[m]];
                        for (let k = 0; k < regionImpairments.length; k++) {
                            let step = regionImpairments[k];
                            // console.log('-- step: ', step);

                            let obj = {
                                text: step.name + ' was ' + step.result + ', resulting in an impairment of ' + step.impairment + '%'
                            };

                            if (impairmentKeys[m] == '0') {
                                obj.text = step.name + ' gives an impairment of ' + step.impairment + '%';
                            }

                            //register table details here
                            let sectionName = this.registerBodyLocation(regionKeys[j]),
                                steps = [];

                            switch (impairmentKeys[m]) {
                                case '0':
                                    // console.error('REGISTERING TO AMPUTATIONS TABLE', {step: step, region: region, sectionName: sectionName, regionKey: regionKeys[j]});
                                    this.airsdetails.amputation.push({
                                        name: sectionName.DESCRIP + ' ' + step.name,
                                        imp: step.impairment,
                                        ref: this.findTestReference(regionKeys[j], '0', step.name)
                                    });
                                    break;
                                case '2':
                                    // console.log('REGISTERING TO MOTIONS TABLE', {step: step, region: region, sectionName: sectionName, regionKey: regionKeys[j]});
                                    //
                                    //
                                    //
                                    //
                                    // this.airsdetails.motion.push({
                                    //     steps: steps
                                    // });
                                    break;
                                case '3':
                                    // console.error('REGISTERING TO NERVES TABLE', {step: step, region: region, sectionName: sectionName, regionKey: regionKeys[j]});

                                    steps.push({
                                        name: sectionName.DESCRIP,
                                        deficit: '',
                                        imp: '',
                                        ref: ''
                                    });
                                    steps.push({
                                        name: step.name,
                                        deficit: Math.round(step.deficiency*100),
                                        imp: step.impairment,
                                        ref: this.findNerveReference(regionKeys[j], step.name)
                                    })
                                    steps.push({
                                        name: 'Motor Deficit',
                                        deficit: Math.round(step.deficiency*100),
                                        imp: step.impairment,
                                        ref: ''
                                    })

                                    this.airsdetails.nerve.push({
                                        lines: steps
                                    });
                                    break;
                                case '8':
                                    // console.error('REGISTERING TO STRENGTH TABLE', {step: step, region: region, sectionName: sectionName, regionKey: regionKeys[j]});

                                    let ref;

                                    if (regionKeys[j] == '13') {
                                        // sectionName = this.registerBodyLocation('14');
                                        ref = this.findTestReference('14', '8', 'Loss of ' + step.name)
                                    } else if (regionKeys[j] == '23') {
                                        // sectionName = this.registerBodyLocation('24');
                                        ref = this.findTestReference('24', '8', 'Loss of ' + step.name)
                                    } else {
                                        ref = this.findTestReference(regionKeys[j], '8', 'Loss of ' + step.name)
                                    }

                                    this.airsdetails.strength.push({
                                        name: sectionName.DESCRIP + ' ' + step.name,
                                        strength: step.result + ' lb',
                                        index: Math.round(step.deficiency*100) + '%',
                                        imp: step.impairment,
                                        ref: ref
                                    });
                                    break;
                                default:
                                    console.log('NO SECTION TO REGISTER TO', {step: step, region: region, sectionName: sectionName, regionKey: regionKeys[j]});
                                    break;
                            }


                            impairmentSubsection.steps.push(obj);
                            if(!step.distraction){
                                if(total !== null) {
                                    let impairment = Math.round(step.impairment * ((100 - total)/100));
                                    addSteps.push({
                                        text: 'Add ' + total + '% and ' + step.impairment + '% for a result of ' + (total + impairment) + '%'
                                    });
                                    total += impairment;
                                } else {
                                    total = step.impairment;
                                }
                            }
                        }

                        impairmentSubsection.steps = impairmentSubsection.steps.concat(addSteps);

                        impairmentSubsection.text += this.summary[region.region.LOCATION].impairment + '% (add multiple impairments)';
                        regionSection.text += ': ' + this.summary[region.region.LOCATION].impairment + '% (combine multiple impairments)';
                        totalImpairment += total;

                        regionSection.subsections.push(impairmentSubsection)

                        let totalSubsection = {
                            text: region.region.DESCRIP,
                            steps: []
                        }

                        impairmentSection.sections.push(regionSection);
                    }


                }
            }

            // console.error('DEBUGGING', {summary: this.summary, locationId: imp.location, location: this.summary[imp.location]});

            totalSubsection.text += ': ' + this.summary[imp.location].impairment + '%'
            globalObj.sections[0].subsections.push(totalSubsection);
            this.details.push(impairmentSection);
            globalImpairment += totalImpairment;
        }

        globalObj.sections[0].text += this.summary[0].impairment + '%';
        this.details.push(globalObj);
        // console.log('[wpi::renderResults()] -- final results', this.details, 'body sections', this.bodySections);

    }
    cascadeImpairments(bodycode, testname, y = 0, distraction = false) {
        let ratio = 1;
        let step = 0;
        let distractionStop = false;
        while (bodycode.length > 0) {
            let distractionRatio = distraction && !step ? 0 : 1;
            let location = this.registerBodyLocation(bodycode);
            if(step === 0) {
                location.tests[testname] = y;
            }
            location.impairment += Math.round(y * ratio * ((100 - +location.impairment)/100) * distractionRatio) ;
            if (+location.PARENT) {
                ratio *= location.IMPAIRMENT/100;
            }
            step++;
            bodycode = bodycode.substr(0, bodycode.length-1);
            if(bodycode.length === 0) {
                let whole = this.registerBodyLocation(0);
                whole.impairment += Math.round(y * ratio * ((100 - +whole.impairment)/100) * distractionRatio);
            }
            // distractionStop = distraction;
        }
    }
    findBodyLocation (id) {
        for (let i = 0; i < this.bodycodes.length; i++) {
            if (+this.bodycodes[i].LOCATION === +id) {
                return this.bodycodes[i];
            }
        }


        console.error('COULD NOT FIND BODY LOCATION BY ID', id, this.bodycodes);

        // this.pouchService.get('ARC_airs_BODYCODE').then((r,e) => {
        //     // console.log('BODY CODE MANUAL PULL', r, e);
        // })

        return false;
    }
}
