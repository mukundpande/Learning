import {Injectable, EventEmitter, OnInit} from '@angular/core';
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {Headers, Http} from "@angular/http";
import 'rxjs/add/operator/toPromise';
import {ErrorDisplayModalComponent} from "../utils/error-display-modal.component";
let PouchDB = require('pouchdb');
PouchDB.plugin(require('pouchdb-auth'));
PouchDB.plugin(require('pouchdb-find'));
PouchDB.plugin(require('pouchdb-security'));
PouchDB.plugin({
    getUrl: function(){ return this.name; }
});
// require('pouchdb-all-dbs')(PouchDB);

@Injectable()
export class PouchDBService implements OnInit {
    private isInstantiated: boolean;
    private database: any;
    private mainRemoteDB: any;
    private onlineDB: any;
    private listener: EventEmitter<any> = new EventEmitter();
    public currentUser;
    public status: any = null;
    private syncSetup = false;
    selectedDB = null;

    private hostURL = 'http://mds.siva.test:5984/';
    private userPrefix = 'org.couchdb.user:';

    private config = {};
    private syncs = {};

    public constructor(
        private ngbService: NgbModal,
        private http: Http
    ) { }

    dbInfo (id) {
        let newDB = new PouchDB(this.hostURL + id);
        console.log('PULLING DATABASE', newDB);
        return newDB.info();
    }

    allDbs () {
        return this.http.get(this.hostURL+'_all_dbs').toPromise().then(res => {
            let dbs = [];
            res.json().map((item, index) => {
                if(item.substr(0,1) != '_') {
                    dbs.push(item);
                }
            });
            return dbs;
        });
    }

    getCurrentUser() {
        return this.currentUser;
    }

    getUsers () {
        let userDB = new PouchDB(this.hostURL+'_users/');;
        return userDB.allDocs({
            startkey: this.userPrefix,
            endkey: this.userPrefix + '\uFFFF',
            include_docs: true}).then(res => {
            let users = [];

            for (let i = 0; i < res.rows.length; i++) {
                users.push(res.rows[i].doc);
            }

            return users;
        });
    }

    addUser (name, pass) {

        let userDB = new PouchDB(this.hostURL+'_users/');

        return userDB.put({
            _id: this.userPrefix + name,
            type: 'user',
            roles: [],
            name: name,
            password: pass
        });
    }

    deleteUser (name) {
        let userDB = new PouchDB(this.hostURL+'_users/');

        return this.getUser(name).then(doc => userDB.remove(doc).then(res => {console.log('user deleted', res)}));
    }

    getUser(name) {
        let userDB = new PouchDB(this.hostURL+'_users/');

        return userDB.get(this.userPrefix + name);
    }

    updateUser(obj) {
        let userDB = new PouchDB(this.hostURL+'_users/');
        return userDB.put(obj);
    }

    duplicateDatabase (source, destination) {
        console.log('COPYING DATABASE', source, destination);

        let sourceDB = new PouchDB(this.hostURL + source + '/');

        let headers:Headers = new Headers({
            'Content-Type': 'application/json'
        });

        return this.http.post(this.hostURL + '_replicate', {source: source, target: destination}, {'headers': headers}).toPromise().then(res => {
            console.log('Duplicating DB', res);
            return res;
        }, err => {
            console.error('PouchDB::duplicate -- COULD NOT DUPE BECAUSE', err);
        });
    }

    getDBSecurity (name) {
        let sourceDB = new PouchDB(this.hostURL + name + '/');

        this.onlineDB.session((err,res)=>{
            console.log('source DB session response', err, res, this.onlineDB);
        });

        return sourceDB.get('_security').then(doc => {
            console.log('FOUND SECURITY FOR', name, doc);
            return doc;
        });
    }

    updateSecurity (name, security) {
        let sourceDB = new PouchDB(this.hostURL + name + '/');
        return sourceDB.putSecurity(security);
    }

    public deleteDatabase (database) {
        let sourceDB = new PouchDB(this.hostURL + database + '/');
        return sourceDB.destroy();
    }


    ngOnInit () {
        try {
            let user;
            if (user = localStorage.getItem('currentUser')) {
                console.log('restarting with user', user);
                this.currentUser = JSON.parse(user);
            }
        } catch (e) {
            // don't flip out, just let the session fix it
            this.currentUser = null;
        }

        try {
            let config;
            if (config = localStorage.getItem('config')) {
                console.log('reloading config', config);
                this.config = JSON.parse(config);
            }

        } catch (e) {
            // don't flip out, just let the session fix it
            this.config = {};
        }

        this.startAllSyncs();

        let selectedDB;
        if(selectedDB = localStorage.getItem('db')) {
            this.initiateDatabases(selectedDB);
        }
    }

    startAllSyncs () {
        this.stopAllSyncs();
        let keys = Object.keys(this.config);
        for (let i = 0; i < keys.length; i++) {
            this.startSync(keys[i]);
        }
    }

    stopAllSyncs () {
        let keys = Object.keys(this.syncs);
        for (let i = 0; i < keys.length; i++) {
            this.stopSync(keys[i]);
        }
    }

    getConfig () {
        return this.config;
    }

    activateSync (db) {
        this.config[db] = true;
        this.startSync(db);
        this.saveSyncConfig();
    }

    deactivateSync (db) {
        delete this.config[db];
        this.stopSync(db);
        this.saveSyncConfig();
    }

    getSyncStatus(db) {
        if (this.syncs[db]) {
            return this.syncs[db].status;
        } else {
            return null;
        }
    }

    startSync (db) {
        this.stopSync(db);
        if(this.selectedDB === db) {return;}
        let local;
        try {
            local = new PouchDB(db, {auto_compact: true});
        }
        catch (e) {
            console.error('LOCAL CREATE DB FAILURE FOR ', db);
        }

        let remote = new PouchDB(this.hostURL+db+'/');
        this.syncs[db] = {
            local: local,
            remote: remote,
            sync: null,
            status: 'Sync Paused'
        };
        console.error('BEGINNING SYNC FOR', db);

        if(!local) {
            console.error('Could not start a DB for', db);
            return;
        }

        let dbThing = this;

        try {
            this.syncs[db].sync = this.syncs[db].local.sync(this.syncs[db].remote, {
                live: true,
                retry: true,
                batch_size: 500
            }).on('change', (info) => {
                console.log('[SYNC] Actively Syncing ', info);
                // docs_read, docs_written, last_seq
                // handle change
                dbThing.syncs[db].status = 'Syncing';
            }).on('paused', (err) => {
                dbThing.syncs[db].status = 'Sync Paused';
                // replication paused (e.g. replication up to date, user went offline)
            }).on('active', function () {
                dbThing.syncs[db].status = 'Sync Paused';
                // replicate resumed (e.g. new changes replicating, user went back online)
            }).on('denied', (err) => {
                dbThing.syncs[db].status = 'Transfer Denied';
                // a document failed to replicate (e.g. due to permissions)
            }).on('complete', (info) => {
                dbThing.syncs[db].status = 'Transfer Complete';
                // handle complete
            }).on('error', (err) => {
                // handle error
                dbThing.syncs[db].status = 'Error';
                console.error('DB Connection crashed', err);
            });
        } catch (e) {
            console.log('Could not sync because', e);
        }
    }

    stopSync (db) {
        if(this.syncs[db]) {
            console.error('STOPPING ', this.syncs[db]);
            this.syncs[db].sync.cancel();
            this.syncs[db].status = 'Stopped';
        }
    }


    saveSyncConfig () {
        localStorage.setItem('config', JSON.stringify(this.config));
    }

    public selectDatabase (database) {
        localStorage.setItem('db', database);
        if(this.database) {
            this.isInstantiated = false;

            if(this.config[this.selectedDB]) {
                this.startSync(this.selectedDB);
            }
            // this.database = new PouchDB('offline_fix', {auto_compact: true});
        }
        this.initiateDatabases(database);
    }

    public initiateDatabases (database = null) {
        if(database !== null) {
            this.selectedDB = database;
            this.stopSync(this.database);
        }

        if(!this.selectedDB) {
            return;
        }

        if (!this.isInstantiated) {
            this.database = new PouchDB(this.selectedDB, {auto_compact: true});
            this.onlineDB = new PouchDB(this.hostURL+this.selectedDB+'/');
            this.onlineDB.useAsAuthenticationDB();

            console.log('[pouchDB.service::initDB] => starting');

            this.onlineDB.session((err, res) => {
                if (err) { console.log('[ONLINE CHECK] Failed', err); return; }
                if (!res.userCtx.name) {
                    localStorage.removeItem('currentUser');
                    this.currentUser = null;
                    // return;
                } else {
                    localStorage.setItem('currentUser', JSON.stringify(res.userCtx));
                    this.currentUser = res.userCtx;
                }
                this.activateOnlineSync();
            });

            this.isInstantiated = true;
        } else {
            console.error('[pouchDB.service::initDB] => Databases are already instantiated -- doing nothing');
        }
    }

    public activateOnlineSync () {
        console.log('[SYNC] Setting up Offline Pouch to Online');
        this.database.sync(this.onlineDB, {
            live: true,
            retry: true,
            batch_size: 500
        }).on('change', (info) => {
            console.log('[SYNC] Actively Syncing ', info);
            // docs_read, docs_written, last_seq
            // handle change
            this.status = 'Syncing';
        }).on('paused', (err) => {
            this.status = 'Sync Paused';
            // replication paused (e.g. replication up to date, user went offline)
        }).on('active', function () {
            this.status = 'Sync Paused';
            // replicate resumed (e.g. new changes replicating, user went back online)
        }).on('denied', (err) => {
            this.status = 'Transfer Denied';
            // a document failed to replicate (e.g. due to permissions)
        }).on('complete', (info) => {
            this.status = 'Transfer Complete';
            // handle complete
        }).on('error', (err) => {
            // handle error
            this.status = 'Error';
            console.error('DB Connection crashed', err);
        });
    }

    public getDb() {
        // @todo: disable when testing is done
        return this.database;
    }

    public hasRole(role) { return this.currentUser && this.currentUser.roles.indexOf(role) !== -1; }

    public login (username, password) {
        if(!this.onlineDB) {
            this.onlineDB = new PouchDB(this.hostURL + 'mds/');
            this.onlineDB.useAsAuthenticationDB();
        }
        return this.onlineDB.logIn(username, password).then(
            (res) => {
                console.log('LOGIN SUCCESSFUL', res);
                localStorage.setItem('currentUser', JSON.stringify(this.currentUser = res));
                this.isInstantiated = false;
                this.initiateDatabases(this.selectedDB);
                this.startAllSyncs();
            },
            (err) => {
                const modal = this.ngbService.open(ErrorDisplayModalComponent, { size: 'lg' });
                modal.componentInstance.setError(err.message);
                console.error('COULD NOT LOG IN', err);
            }
        );
    }

    public logout () {
        localStorage.removeItem('currentUser');

        return this.onlineDB.logOut().then( res => {
            this.currentUser = null;
            console.log('LOGGED OUT!');
        }, err => {
            console.error('COULD NOT LOGOUT', err);
        });
    }

    public fetch() {
        return this.database.allDocs({include_docs: true});
    }

    public allDocs(options = {}) {
        if(!this.database) {
            return new Promise(r=>r(false));
        }

        return this.database.allDocs(options);
    }

    public get(id: string, options = {}) {
        return this.database.get(id, options).catch(err => {
            console.error('PouchDB Service:: could not get:', id);
            return err;
        });
    }

    public remove(document:any){
        return this.database.remove(document);
    }

    public put(id: string, document: any) {
        document._id = id;
        return this.get(id).then(result => {
            // console.log('RECORD FOUND, UPDATING', result);
            document._rev = result._rev;
            return this.database.put(document);
        }, error => {
            if (error.status === 404) {
                console.log('404 FOUND, CREATING NEW DOC');
                return this.database.put(document);
            } else {
                console.log('UNKNOWN ERROR--', error, document);
                return new Promise((resolve, reject) => {
                    reject(error);
                });
            }
        });
    }

    public putAll (id: string, document: any, skipExisting = false) {
        return this.allDbs().then(dbs => {
            dbs.map(db => {

                console.log('would be uploading', id, document, 'to', db);

                let database = new PouchDB(this.hostURL + db);
                return database.get(id).then(result => {
                    console.log('RECORD FOUND, UPDATING');
                    document._rev = result._rev;
                    if(!skipExisting) {
                        return database.put(document);
                    } else {
                        console.log('Existing Skip Active, Skipping...');
                    }
                }, error => {
                    if (error.status === 404) {
                        console.log('404 FOUND, CREATING NEW DOC');
                        return database.put(document).then(doc => {
                            console.log('PUT SUCCESS', doc);
                        });
                    } else {
                        console.log('UNKNOWN ERROR--', error, document);
                        return new Promise((resolve, reject) => {
                            reject(error);
                        });
                    }
                });
            })
        });
    }

    public sync(remote: string) {
        const remoteDatabase = new PouchDB(remote);
        this.database.sync(remoteDatabase, {
            live: true
        }).on('change', change => {
            this.listener.emit(change);
        }).on('error', error => {
            console.error(JSON.stringify(error));
        });
    }

    public getChangeListener() {
        return this.listener;
    }

    public destroy () {
        this.database.destroy().then( () => {
            this.activateOnlineSync();
        });
    }

    public initialStartup () {
        //
        // if (false) {
        //     var ddoc = {
        //         _id: '_design/my_index',
        //         views: {
        //             by_name: {
        //                 map: 'function (doc) { emit(doc.name); }'
        //             }
        //         }
        //     };
        // }
    }
}
