import {Injectable} from "@angular/core";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {FtueModalComponent} from "./ftue-modal.component";
import {Observable} from "rxjs/Observable";
@Injectable()
export class FtueService {
    constructor (private modalService: NgbModal) {

    }

    checkForFTUE () {
        // return new Promise(r => r(true));
        return localStorage.getItem('ftue') ? new Promise(r => r(true)) : this.openFTUE();
    }

    openFTUE () {
        return this.modalService.open(FtueModalComponent, {backdrop: 'static'}).result.then(res => {
            console.log('FTUE has been closed.', res);
            localStorage.setItem('ftue', 'done');
            return res;
        });
    }
}
