var express = require('express'),cors = require('cors'), app = express();
var bodyParser = require("body-parser");
var mongodb = require("mongodb");
var ObjectID = mongodb.ObjectID;
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var CONTACTS_COLLECTION = "startup_log";

var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

var originsWhitelist = [
   'http://localhost:8080',      //this is my front-end url for development
   'http://www.myproductionurl.com'
];
var corsOptions = {
  origin: function(origin, callback){
        var isWhitelisted = originsWhitelist.indexOf(origin) !== -1;
        callback(null, isWhitelisted);
  },
  credentials:true
}


//app.use(cors(corsOptions));
app.use(cors({origin: 'http://ec2-54-159-254-28.compute-1.amazonaws.com'}));
// Create link to Angular build directory
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));
// Create a database variable outside of the database connection callback to reuse the connection pool in your app.
//var db;

// var collection;
// var MongoClient = require('mongodb').MongoClient;


//var dbURI = "mongodb://mds_admin:mds_admin@mycluster0-shard-00-00.mongodb.net:27017,mycluster0-shard-00-01.mongodb.net:27017,mycluster0-shard-00-02.mongodb.net:27017/admin?ssl=true&replicaSet=Mycluster0-shard-0&authSource=admin/admin";

//var dbURI ="mongodb://localhost:27017/local";

var dbURI ="mongodb://123.45.67.89:27017/admin";



 mongoose.connect(dbURI);

// When successfully connected
mongoose.connection.on('connected', function () {
  console.log('Mongoose default connection open to ' + dbURI);
  console.log(mongodb);
});

// If the connection throws an error
mongoose.connection.on('error',function (err) {
  console.log('Mongoose default connection error: ' + err);
});

// When the connection is disconnected
mongoose.connection.on('disconnected', function () {
  console.log('Mongoose default connection disconnected');
});

// If the Node process ends, close the Mongoose connection
process.on('SIGINT', function() {
  mongoose.connection.close(function () {
    console.log('Mongoose default connection disconnected through app termination');
    process.exit(0);
  });
});

  console.log("Database connection ready");

  // Initialize the app.
  var server = app.listen(8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
  });

  //Mongo Test URI
  app.get("/", function(req, res) {
  console.log("MDS RESTapi WORKS! ");
  });


  var userScemaClass = new Schema({ _id:String,name: String, pass: String,roles:String });
  var USERMODEL = mongoose.model('User', userScemaClass);



//Add New User
  app.post("/api/users/add", function(req, res) {
      if (req.method === "OPTIONS") {
        res.header('Access-Control-Allow-Origin', req.headers.origin);
      } else {
        res.header('Access-Control-Allow-Origin', '*');
      }
      var data=req.body;

      USERMODEL.create(data, function (err, USERMODEL) {
        console.log('New User Data Saving '+data);
        if (err) return handleError(err);
        console.log("Saved New User data successfully",USERMODEL);
      });
  });



  //get userS
  app.get("/api/users/all", function(req, res) {
    if (req.method === "OPTIONS") {
      res.header('Access-Control-Allow-Origin', req.headers.origin);
    } else {
      res.header('Access-Control-Allow-Origin', '*');
    }
    USERMODEL.find({ }, function (err, Users) {

      if (err) return handleError(err);

      res.send(Users);
      console.log("Returning All User data successfully",Users);
    });
  });

//get single user
app.get("/api/users/:_id", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;

  var _id=req.params._id;
  console.log('Entered Delete function '+_id);
  USERMODEL.findOne({_id:_id }, function (err, User) {
    if (err) return handleError(err);
    console.log('Get User '+_id);
    res.send(User);

  });
});

  //delete userS

  app.delete("/api/users/delete/:_id", function(req, res) {
    if (req.method === "OPTIONS") {
      res.header('Access-Control-Allow-Origin', req.headers.origin);
    } else {
      res.header('Access-Control-Allow-Origin', '*');
    }
    var data=req.body;

    var _id=req.params._id;
    console.log('Entered Delete function '+_id);
    USERMODEL.deleteOne({_id:_id }, function (err, USERMODEL) {
      if (err) return handleError(err);
      console.log('User deleted '+_id);

    });
  });

var patientSchemaClass = new Schema({
  _id: String,
  FirstName: String,
  Initial: String,
  LastName: String,
  Address: String,
  City: String,
  State: String,
  Zip: String,
  HomePhone: String,
  WorkPhone: String,
  DateofBirth: String,
  Sex: String,
  Height: String,
  Weight: String,
  Units: String,
  DominantHand: String,
  Occupation: String,
  LastTestDate: String,
  Side1: String,
  Date1: String,
  Code1: String,
  Diag1: String,
  Side2: String,
  Date2: String,
  Code2: String,
  Diag2: String,
  Side3: String,
  Date3: String,
  Code3: String,
  Diag3: String,
  Employer: String,
  Physician: String,
  Attorney: String,
  Insurance: String,
  Spare: String,
  InDate: String,
  BP: String,
  Pulse: String,
  Referred: String,
  Intake: String,
  GUID: String,
  Photo: String,
  Injury: String,
  Demands: String,
  array:[],
  array:[],
  array:[],
  array:[],
  array:[],
  array:[]
});
patientSchemaClass.index({ 'FirstName': 'text'});


//Getting all patients for dropdown
app.get("/api/patients/all", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);

  MyModel.find({}, { "_id": 1,"FirstName": 1,"LastName": 1,"LastTestDate": 1 }).sort({"LastName": 1 }).exec( function(err, someValue){
     if(err) return next(err);
     res.send(someValue);
   });


   // MyModel.find({}, { "_id": 1,"FirstName": 1,"LastName": 1,"LastTestDate": 1 }, function(err, someValue){
   //    if(err) return next(err);
   //    res.send(someValue);
   //  });

});

//Getting all patients for showing arrows to move to different patient
app.get("/api/patients/getall", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);
   MyModel.find({}, { "_id": 1 }, function(err, someValue){
      if(err) return next(err);
      res.send(someValue);
    });

});


//Getting patient data by its id
app.get("/api/patients/:id", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);
  var _id=req.params.id;
  console.log('Reading Patient by Its ID'+_id);
  MyModel.findOne({_id:_id }, function (err, MyModel) {
    console.log('Patient Searched '+_id);
    if (err) return handleError(err);
    res.send(MyModel);
    console.log("Searched Patient data successfully",MyModel);
  });

});

//Search based on search string

//Search patient
app.get("/api/patients/searchbystring/:term", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
var searchstring=req.params.term;

  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);

  console.log('Searching for patient by search criteria');

//MyModel.find({$text: { $search: searchstring }},{"FirstName": 1}, function (err, searchedResults) {
  MyModel.find({'FirstName': new RegExp(searchstring,'i')}, { "_id": 1, "FirstName": 1}, function (err, searchedResults) {
    console.log('Patient Search Started ');
    if (err) return handleError(err);
    res.send(searchedResults);
    console.log("Searched Patient data successfully by search criteria",searchedResults);
  });

});

//Search patient
app.get("/api/patients/search/:id", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var _id=req.params.id;
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);
  console.log('Searching for patient by search criteria');
  MyModel.findOne({_id:_id }, function (err, MyModel) {
    console.log('Patient Searched '+_id);
    if (err) return handleError(err);
    res.send(MyModel);
    console.log("Searched Patient data successfully",MyModel);
  });

});

app.post("/api/patients", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);
  MyModel.create(data, function (err, MyModel) {
    console.log('Patient Data Saving '+data);
    if (err) return handleError(err);
    console.log("Saved Patient data successfully",MyModel);
  });
});

app.delete("/api/patients/:id", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var MyModel = mongoose.model('PatientSchema', patientSchemaClass);
  var _id=req.params.id;
  console.log('Enetered Delete function '+_id);
  MyModel.deleteOne({_id:_id }, function (err, MyModel) {
    console.log('Patient deleted '+_id);
    if (err) return handleError(err);
      console.log("Patient deleted successfully");
  });
});

//Protocol Rest API's
var protocolSchemaClass = new Schema({
  _id: String,
  Name: String,
  NumTests: Number,
  TestNames: [],
  TestCodes: [],
  tests:[]
});
protocolSchemaClass.index({ 'Name': 'text'});

//Getting all protocols for dropdown
app.get("/api/protocols/all", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var ProtocolModel = mongoose.model('ProtocolSchema', protocolSchemaClass);
   ProtocolModel.find({}, function(err, protocolsList){
      if(err) return next(err);
      res.send(protocolsList);
    });

});

//Add protocol
app.post("/api/protocols/add", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var ProtocolModel = mongoose.model('ProtocolSchema', protocolSchemaClass);
  ProtocolModel.create(data, function (err, protocolModel) {
    console.log('Protocol Data Saving '+data);
    if (err) return handleError(err);
    console.log("Saved Protocol data successfully",protocolModel);
    res.send(protocolModel);
  });
});


//Update protocol
app.post("/api/protocols/update", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  console.log('fun data '+data);
  var ProtocolModel = mongoose.model('ProtocolSchema', protocolSchemaClass);
  ProtocolModel.findOneAndUpdate({_id:data._id }, data, function (err, protocolModelObj) {
    console.log('Protocol Data Saving '+data);
    if (err) return handleError(err);
    res.send(protocolModelObj);
    console.log("Saved Protocol data successfully",protocolModel);
  });
});

app.delete("/api/protocols/:id", function(req, res) {
  if (req.method === "OPTIONS") {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  var data=req.body;
  var ProtocolModel = mongoose.model('ProtocolSchema', protocolSchemaClass);
  var _id=req.params.id;
  console.log('Enetered Delete function '+_id);
  ProtocolModel.deleteOne({_id:_id }, function (err, protocolModel) {
    console.log('Protocol deleted '+_id);
    if (err) return handleError(err);
    console.log("Protocol deleted successfully");
  });
});

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
  console.log("ERROR: " + reason);
  res.status(code || 500).json({"error": message});
}
