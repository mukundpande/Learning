import { MdsNgPage } from './app.po';

describe('mds-ng App', () => {
  let page: MdsNgPage;

  beforeEach(() => {
    page = new MdsNgPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
