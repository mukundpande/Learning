package com.test.ae.sample.client;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.UUID;

import javax.jms.JMSException;
import javax.naming.NamingException;

public class StockQuoteAnlyserJMSClient {

	AEMessageSender messageSender;

	public StockQuoteAnlyserJMSClient() throws NamingException, JMSException {
		messageSender = new AEMessageSender();
	}

	public void sendData() throws IOException, JMSException, ParseException {
		if (StockQuoteDataStreanSimulator.MSG_TEMPL != null) {
			sendStockQuotes();
		}
	}

	private void sendStockQuotes() throws IOException, ParseException, JMSException {
		String symbData = null;
		UUID ctxGuid = UUID.randomUUID();

		String line;
		BufferedReader br = new BufferedReader(new FileReader(StockQuoteDataStreanSimulator.CSV_DATA_FILE));

		while ((line = br.readLine()) != null) {
			String[] valueList = line.split(",");
			symbData = StockQuoteDataStreanSimulator.MSG_TEMPL.replaceAll("#APP_IDENTIFIER#", StockQuoteDataStreanSimulator.APP_ID)
					.replaceAll("#CTX_ID_GUID#", ctxGuid.toString()).replaceAll("#DOMAIN_NAME#", valueList[0]).replaceAll("#USER_ID#", valueList[1])
					.replaceAll("#TRAN_ID#", valueList[2]).replaceAll("#LOG_DURATION#", valueList[4])
					.replaceAll("#LOG_TIMESTAMP#", DateUtil.converDateFormat(valueList[3]));

			messageSender.publishToTopic(symbData);
		}
		if (br != null)
			br.close();
	}
}
