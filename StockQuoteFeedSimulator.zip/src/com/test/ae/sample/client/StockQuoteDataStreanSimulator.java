package com.test.ae.sample.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class StockQuoteDataStreanSimulator {

	public static String CSV_DATA_FILE;
	public static String MSG_TEMPL;
	public static String APP_ID;

	public StockQuoteDataStreanSimulator() throws IOException {
		loadConfig();
	}

	public static void main(String[] args) {
		try {
			int choice = 1;
			StockQuoteDataStreanSimulator simltr = new StockQuoteDataStreanSimulator();
			simltr.startSimulator(choice);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadConfig() throws IOException {
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("StockQuoteFeed.properties");
		Properties stockQuoteFeed = new Properties();
		stockQuoteFeed.load(is);

		String MSG_TMPL_XML_PATH = stockQuoteFeed.getProperty("MSG_TMPL_XML_PATH");
		loadXMLMsgTmpl(MSG_TMPL_XML_PATH);
		CSV_DATA_FILE = stockQuoteFeed.getProperty("CSV_DATA_FILE");
		APP_ID = stockQuoteFeed.getProperty("APP_IDENTIFIER");
	}

	private void loadXMLMsgTmpl(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
		StringBuilder sb = new StringBuilder();
		String line="";
		while ((line = br.readLine()) != null) {
			sb.append(line.trim());
		}
		MSG_TEMPL = line.toString();
	}

	public void startSimulator(int choice) throws IOException {
		switch (choice) {
		case 1:
			StockQuoteDataStreanSimulator simltr = new StockQuoteDataStreanSimulator();
			simltr.startSimulator(choice);
			break;

		case 2:

			break;

		}

	}
}
