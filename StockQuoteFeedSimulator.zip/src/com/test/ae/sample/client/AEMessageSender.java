package com.test.ae.sample.client;

import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class AEMessageSender {
	
	private QueueConnection queueConnection;
	private QueueSession session;
	private QueueSender sender;
	
	public AEMessageSender() throws NamingException, JMSException{
		Properties initialContextProperties = new Properties();
		initialContextProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
		initialContextProperties.put(Context.PROVIDER_URL, "tcp://localhost:61616?wireFormat.maxInactivityDuration=0");

		Context context = new InitialContext(initialContextProperties);
		QueueConnectionFactory queueConnectionFactory = (QueueConnectionFactory)context.lookup("ConnectionFactory");
		
		queueConnection=queueConnectionFactory.createQueueConnection();
		session = queueConnection.createQueueSession(false,Session.AUTO_ACKNOWLEDGE);
		Queue queue = session.createQueue("AE_CONNECT_LOGIN_QUEUE");
		sender = session.createSender(queue);
		queueConnection.start();
	}
	
	public void publishToTopic(String xmlMessage) throws JMSException{
		TextMessage tm = session.createTextMessage(xmlMessage);
		sender.send(tm);
	}
	
	public void closeAll() throws JMSException{
		sender.close();
		session.close();
		queueConnection.stop();
		queueConnection.close();
	}
}
