package com.test.ae.sample.client;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateUtil {
	
	public static String converDateFormat(String input) throws ParseException{
		String outputDate;
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yy hh.mm.ss.S a");
		DateFormat outputDataFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT-4"));
		Date date = dateFormat.parse(input.replaceAll("000000", ""));
		outputDate = outputDataFormat.format(date);
		return outputDate;
	}
}
